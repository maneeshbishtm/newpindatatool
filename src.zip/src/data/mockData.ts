
import type { KeywordData, CategoryInfo } from '../types';
import { RAW_DATA_SOURCE } from './rawSource1';
import { RAW_DATA_SOURCE_2 } from './rawSource2';
import { RAW_DATA_SOURCE_3 } from './rawSource3';
import { RAW_DATA_SOURCE_4 } from './rawSource4';
import { RAW_DATA_SOURCE_5 } from './rawSource5';
import { RAW_DATA_SOURCE_6 } from './rawSource6';
import { RAW_DATA_SOURCE_7 } from './rawSource7';
import { RAW_DATA_SOURCE_8 } from './rawSource8';
import { RAW_DATA_SOURCE_9 } from './rawSource9';
import { RAW_DATA_SOURCE_10 } from './rawSource10';
import { RAW_DATA_SOURCE_11 } from './rawSource11';
import { RAW_DATA_SOURCE_12 } from './rawSource12';
import { RAW_DATA_SOURCE_13 } from './rawSource13';
import { RAW_DATA_SOURCE_14 } from './rawSource14';
import { RAW_DATA_SOURCE_15 } from './rawSource15';
import { RAW_DATA_SOURCE_16 } from './rawSource16';
import { RAW_DATA_SOURCE_17 } from './rawSource17';
import { RAW_DATA_SOURCE_18 } from './rawSource18';
import { RAW_DATA_SOURCE_19 } from './rawSource19';
import { RAW_DATA_SOURCE_20 } from './rawSource20';
import { RAW_DATA_SOURCE_21 } from './rawSource21';
import { RAW_DATA_SOURCE_22 } from './rawSource22';
import { RAW_DATA_SOURCE_23 } from './rawSource23';
import { RAW_DATA_SOURCE_24 } from './rawSource24';
import { RAW_DATA_SOURCE_25 } from './rawSource25';
import { RAW_DATA_SOURCE_26 } from './rawSource26';
import { RAW_DATA_SOURCE_27 } from './rawSource27';
import { RAW_DATA_SOURCE_28 } from './rawSource28';
import { RAW_DATA_SOURCE_29 } from './rawSource29';
import { RAW_DATA_SOURCE_30 } from './rawSource30';
import { RAW_DATA_SOURCE_31 } from './rawSource31';
import { RAW_DATA_SOURCE_32 } from './rawSource32';
import { RAW_DATA_SOURCE_33 } from './rawSource33';
import { RAW_DATA_SOURCE_34 } from './rawSource34';
import { RAW_DATA_SOURCE_35 } from './rawSource35';
import { RAW_DATA_SOURCE_36 } from './rawSource36';
import { RAW_DATA_SOURCE_37 } from './rawSource37';
import { RAW_DATA_SOURCE_38 } from './rawSource38';
import { RAW_DATA_SOURCE_39 } from './rawSource39';
import { RAW_DATA_SOURCE_40 } from './rawSource40';
import { RAW_DATA_SOURCE_41 } from './rawSource41';
import { RAW_DATA_SOURCE_42 } from './rawSource42';
import { RAW_DATA_SOURCE_43 } from './rawSource43';
import { RAW_DATA_SOURCE_44 } from './rawSource44';
import { RAW_DATA_SOURCE_45 } from './rawSource45';
import { RAW_DATA_SOURCE_46 } from './rawSource46';
import { RAW_DATA_SOURCE_47 } from './rawSource47';
import { RAW_DATA_SOURCE_48 } from './rawSource48';
import { RAW_DATA_SOURCE_49 } from './rawSource49';





























// Raw data from user
const rawDataStrings = [
    ...RAW_DATA_SOURCE,
    ...RAW_DATA_SOURCE_2,
    ...RAW_DATA_SOURCE_3,
    ...RAW_DATA_SOURCE_4,
    ...RAW_DATA_SOURCE_5,
    ...RAW_DATA_SOURCE_6,
    ...RAW_DATA_SOURCE_7,
    ...RAW_DATA_SOURCE_8,
    ...RAW_DATA_SOURCE_9,
    ...RAW_DATA_SOURCE_10,
    ...RAW_DATA_SOURCE_11,
    ...RAW_DATA_SOURCE_12,
    ...RAW_DATA_SOURCE_13,
    ...RAW_DATA_SOURCE_14,
    ...RAW_DATA_SOURCE_15,
    ...RAW_DATA_SOURCE_16,
    ...RAW_DATA_SOURCE_17,
    ...RAW_DATA_SOURCE_18,
    ...RAW_DATA_SOURCE_19,
    ...RAW_DATA_SOURCE_20,
    ...RAW_DATA_SOURCE_21,
    ...RAW_DATA_SOURCE_22,
    ...RAW_DATA_SOURCE_23,
    ...RAW_DATA_SOURCE_24,
    ...RAW_DATA_SOURCE_25,
    ...RAW_DATA_SOURCE_26,
    ...RAW_DATA_SOURCE_27,
    ...RAW_DATA_SOURCE_28,
    ...RAW_DATA_SOURCE_29,
    ...RAW_DATA_SOURCE_30,
    ...RAW_DATA_SOURCE_31,
    ...RAW_DATA_SOURCE_32,
    ...RAW_DATA_SOURCE_33,
    ...RAW_DATA_SOURCE_34,
    ...RAW_DATA_SOURCE_35,
    ...RAW_DATA_SOURCE_36,
    ...RAW_DATA_SOURCE_37,
    ...RAW_DATA_SOURCE_38,
    ...RAW_DATA_SOURCE_39,
    ...RAW_DATA_SOURCE_40,
    ...RAW_DATA_SOURCE_41,
    ...RAW_DATA_SOURCE_42,
    ...RAW_DATA_SOURCE_43,
    ...RAW_DATA_SOURCE_44,
    ...RAW_DATA_SOURCE_45,
    ...RAW_DATA_SOURCE_46,
    ...RAW_DATA_SOURCE_47,
    ...RAW_DATA_SOURCE_48,
    ...RAW_DATA_SOURCE_49,
];

// Helper to categorize based on keywords
export const getCategory = (keywordName: string): string => {
    const lower = keywordName.toLowerCase();

    // Priority Categories
    if (lower.includes('blue') || lower.includes('green') || lower.includes('pink') || lower.includes('black') ||
        lower.includes('white') || lower.includes('neutral') || lower.includes('beige') || lower.includes('grey') ||
        lower.includes('gray') || lower.includes('gold') || lower.includes('silver') || lower.includes('red') ||
        lower.includes('colorful') || lower.includes('palette')) {
        // Double check if it fits better in room specific, but for now let's prioritize "Color & Theme" if the user wants that, 
        // OR we can stick to room-based. 
        // Let's stick to room-based as primary, but maybe we need a 'Color' category? 
        // The user asked for "Deck", "Garden", etc.
    }

    if (lower.includes('bed')) return 'bedroom';
    if (lower.includes('bath') || lower.includes('shower') || lower.includes('toilet') || lower.includes('washroom')) return 'bathroom';
    if (lower.includes('living room') || lower.includes('sofa') || lower.includes('couch') || lower.includes('lounge')) return 'living-room';
    if (lower.includes('kitchen') || lower.includes('cooking') || lower.includes('dining')) return 'kitchen';

    // New / Refined Categories
    if (lower.includes('deck') || lower.includes('patio') || lower.includes('porch') || lower.includes('balcony') || lower.includes('terrace')) return 'deck-patio';
    if (lower.includes('garden') || lower.includes('plant') || lower.includes('flower') || lower.includes('landscape') || lower.includes('landscaping')) return 'garden';
    if (lower.includes('pool') || lower.includes('swim')) return 'pool';
    if (lower.includes('garage') || lower.includes('workshop')) return 'garage'; // Garage was in the data

    if (lower.includes('christmas') || lower.includes('halloween') || lower.includes('fall') || lower.includes('winter') || lower.includes('spring') || lower.includes('summer') || lower.includes('holiday') || lower.includes('season')) return 'seasonal';

    if (lower.includes('storage') || lower.includes('organize') || lower.includes('organization') || lower.includes('closet')) return 'organization';

    if (lower.includes('light') || lower.includes('lamp') || lower.includes('chandelier')) return 'lighting';
    if (lower.includes('wall') || lower.includes('decor') || lower.includes('art') || lower.includes('mirror') || lower.includes('rug') || lower.includes('carpet')) return 'decor';

    return 'other';
};

export const MOCK_KEYWORDS: KeywordData[] = rawDataStrings.map((str, index) => {
    // Expected format: "Name\tVolume\tSomething\tRelated, Keywords"
    // But some lines might be different. Let's handle safe splitting.
    const parts = str.split('\t');

    if (parts.length < 2) return null; // Skip invalid lines

    const name = parts[0]?.trim() || "Unknown";
    // Remove commas from strings like "174,132" before parsing int
    const volume = parseInt((parts[1] || '0').replace(/,/g, ''), 10) || 0;

    // The 3rd column in the provided data seems to vary (sometimes missing, sometimes 0). 
    // In "Kleine Geschenke\t174,132\t73", 73 might be difficulty or something else.
    // Let's treat it as generic 'metric' or just 0 if not needed. 
    // The prompt implied we need Volume.

    // If column 3 is numbers, column 4 is keywords.
    // If column 3 is text, it might be the keywords.
    // Let's try to detect if column 2 (index 2) is a number.

    let related: string[] = [];
    if (parts[3]) {
        related = parts[3].split(',').map(s => s.trim()).filter(s => s.length > 0);
    } else if (parts[2] && isNaN(parseInt(parts[2].replace(/,/g, '')))) {
        // If part 2 is NOT a number, assume it's the related keywords list
        related = parts[2].split(',').map(s => s.trim()).filter(s => s.length > 0);
    }

    return {
        id: `kw-${index}`,
        name,
        volume,
        followers: 0, // Placeholder
        hasRelatedInterests: related.length > 0,
        relatedInterests: related,
        relatedSearches: [],
        category: getCategory(name),
        breadcrumbs: ['Home', 'Explorer', getCategory(name)]
    } as KeywordData;
}).filter((item): item is KeywordData => item !== null);

const categoryCounts = MOCK_KEYWORDS.reduce((acc, curr) => {
    const cat = curr.category;
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
}, {} as Record<string, number>);

export const CATEGORIES: CategoryInfo[] = [
    { id: 'all', name: 'All Categories', count: MOCK_KEYWORDS.length.toString() },
    { id: 'bedroom', name: 'Bedroom', count: (categoryCounts['bedroom'] || 0).toString() },
    { id: 'living-room', name: 'Living Room', count: (categoryCounts['living-room'] || 0).toString() },
    { id: 'kitchen', name: 'Kitchen', count: (categoryCounts['kitchen'] || 0).toString() },
    { id: 'bathroom', name: 'Bathroom', count: (categoryCounts['bathroom'] || 0).toString() },
    { id: 'garden', name: 'Garden & Landscaping', count: (categoryCounts['garden'] || 0).toString() },
    { id: 'deck-patio', name: 'Deck & Patio', count: (categoryCounts['deck-patio'] || 0).toString() },
    { id: 'pool', name: 'Pool', count: (categoryCounts['pool'] || 0).toString() },
    { id: 'garage', name: 'Garage', count: (categoryCounts['garage'] || 0).toString() },
    { id: 'seasonal', name: 'Seasonal', count: (categoryCounts['seasonal'] || 0).toString() },
    { id: 'organization', name: 'Organization', count: (categoryCounts['organization'] || 0).toString() },
    { id: 'decor', name: 'Decor & Wall', count: (categoryCounts['decor'] || 0).toString() },
    { id: 'lighting', name: 'Lighting', count: (categoryCounts['lighting'] || 0).toString() },
    { id: 'other', name: 'Other', count: (categoryCounts['other'] || 0).toString() }
];

// Helper to get top keywords for "Boards"
export const getKeywordsForBoard = (_boardId: string, limit = 10) => {
    // This logic can be improved to actually filter by board relevance
    // For now, return random or sorted top volume
    return MOCK_KEYWORDS
        .sort((a, b) => b.volume - a.volume)
        .slice(0, limit);
};
