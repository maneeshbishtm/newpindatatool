
export const BOARD_IDS = {
    BACKYARD: 'board-backyard',
    BARBIE: 'board-barbie',
    BOHEMIAN: 'board-bohemian',
    CREAM: 'board-cream',
    DARK: 'board-dark',
    APOTHECARY: 'board-apothecary',
    JACUZZI: 'board-jacuzzi',
    PURSE: 'board-purse',
    RAISED_BEDS: 'board-raised-beds',
    GYM: 'board-gym',
    TILE_SHOWER: 'board-tile-shower',
    WHIMSICAL_KIDS: 'board-whimsical-kids',
    ACCENT_CEILING: 'board-accent-ceiling',
    BATHROOM_REMODEL: 'board-bathroom-remodel',
    TOWEL_RACK: 'board-towel-rack',
    WALL_COLOR: 'board-wall-color',
    THRIFTED: 'board-thrifted',
    BABY_SHOWER: 'board-baby-shower',
    SMALL_BEDROOM: 'board-small-bedroom',
    DARK_GREY_COUCH: 'board-dark-grey-couch',
    VICTORIAN_LIVING_ROOM: 'board-victorian-living-room',
    VICTORIAN_INTERIOR: 'board-victorian-interior',
    TV_WALL_BEDROOM: 'board-tv-wall-bedroom',
    SMALL_SPACE_LIVING: 'board-small-space-living',
    SMALL_FRONT_YARD_LANDSCAPING: 'board-small-front-yard-landscaping',
    SMALL_KITCHEN_REMODEL: 'board-small-kitchen-remodel',
    SMALL_BATHROOM_IDEAS: 'board-small-bathroom-ideas',
    POWDER_ROOM_IDEAS: 'board-powder-room-ideas',
    ART_DECO_BATHROOM: 'board-art-deco-bathroom',
    BEDROOM_IDEAS_FOR_TEENS: 'board-bedroom-ideas-for-teens',
    BLACK_AND_GOLD_KITCHEN: 'board-black-and-gold-kitchen',
    BEDROOM_IDEAS_WITH_DESK: 'board-bedroom-ideas-with-desk',
    COTTAGE_BATHROOM_IDEAS: 'board-cottage-bathroom-ideas',
    DARK_HALLWAY_IDEAS: 'board-dark-hallway-ideas',
    BEDROOM_IDEAS_WHITE_FURNITURE: 'board-bedroom-ideas-white-furniture',
    FOYER_AREA: 'board-foyer-area',
    STAMPED_CONCRETE_PATIO_IDEAS: 'board-stamped-concrete-patio-ideas',
    SHABBY_CHIC_BEDROOMS: 'board-shabby-chic-bedrooms',
    MUDROOM_IDEAS_ENTRYWAY: 'board-mudroom-ideas-entryway',
    MINT_GREEN_BEDROOM: 'board-mint-green-bedroom',
    SMALL_BACKYARD_LANDSCAPING: 'board-small-backyard-landscaping',
    BEDROOM_IDEAS_WARDROBE: 'board-bedroom-ideas-wardrobe',
    LIMEWASH_WALLS: 'board-limewash-walls',
    HOME_DECOR_IDEAS_LIVING_ROOM: 'board-home-decor-ideas-living-room',
    COFFEE_TABLE_DECOR_IDEAS: 'board-coffee-table-decor-ideas',
    BATHROOM_WALLPAPER_IDEAS: 'board-bathroom-wallpaper-ideas',
    DARK_COTTAGECORE_KITCHEN: 'board-dark-cottagecore-kitchen',
    SMALL_LIVING_ROOM_IDEAS: 'board-small-living-room-ideas',
    FIREPLACE_MANTLE_DECOR: 'board-fireplace-mantle-decor',
    MUD_ROOM: 'board-mud-room',
    MASTER_BEDROOMS_DECOR: 'board-master-bedrooms-decor',
    MUDROOM_IDEA: 'board-mudroom-idea',
    COVERED_PATIO_IDEAS: 'board-covered-patio-ideas',
    CLOSET_ORG_SIZE: 'board-closet-org-size',
    CLOSET_ORG_FEATURES: 'board-closet-org-features',
    CLOSET_ORG_ITEMS: 'board-closet-org-items',
    CLOSET_ORG_USER: 'board-closet-org-user',
    CLOSET_ORG_STYLE: 'board-closet-org-style',
    CLOSET_ORG_BUDGET: 'board-closet-org-budget',
    CLOSET_ORG_SPECIAL: 'board-closet-org-special',
    CLOSET_ORG_METHODS: 'board-closet-org-methods',
    CLOSET_ORGANIZATION_IDEAS: 'board-closet-organization-ideas',
    MODERN_TV_WALL_DESIGN: 'board-modern-tv-wall-design',
    GIRLS_BEDROOM_IDEAS: 'board-girls-bedroom-ideas',
    FARMHOUSE_DECOR_LIVING_ROOM: 'board-farmhouse-decor-living-room',
    COFFEE_BAR_IDEAS: 'board-coffee-bar-ideas',
    COFFEE_BAR_STYLE: 'board-coffee-bar-style',
    COFFEE_BAR_ROOM: 'board-coffee-bar-room',
    COFFEE_BAR_SETUP: 'board-coffee-bar-setup',
    COFFEE_BAR_SIZE: 'board-coffee-bar-size',
    COZY_BEDROOM_IDEAS: 'board-cozy-bedroom-ideas',
    ENTRYWAY_IDEAS: 'board-entryway-ideas',
    SMALL_LR_LAYOUT: 'board-small-lr-layout',
    SMALL_LR_STYLE: 'board-small-lr-style',
    SMALL_LR_FEATURES: 'board-small-lr-features',
    SMALL_LR_DECOR: 'board-small-lr-decor',
    SMALL_BA_LAYOUT: 'board-small-ba-layout',
    SMALL_BA_STYLE: 'board-small-ba-style',
    SMALL_BA_COLOR: 'board-small-ba-color',
    SMALL_BA_FEATURES: 'board-small-ba-features',
    SMALL_BA_DECOR: 'board-small-ba-decor',
    MUD_ROOM_LAYOUT: 'board-mud-room-layout',
    MUD_ROOM_STORAGE: 'board-mud-room-storage',
    MUD_ROOM_PETS: 'board-mud-room-pets',
    MUD_ROOM_DECOR: 'board-mud-room-decor',
    TV_WALL_BED_LAYOUT: 'board-tv-wall-bed-layout',
    TV_WALL_BED_STYLE: 'board-tv-wall-bed-style',
    TV_WALL_BED_STORAGE: 'board-tv-wall-bed-storage',
    TV_WALL_BED_DECOR: 'board-tv-wall-bed-decor',
    MASTER_BED_VIBE: 'board-master-bed-vibe',
    MASTER_BED_STYLE: 'board-master-bed-style',
    MASTER_BED_COLOR: 'board-master-bed-color',
    MASTER_BED_FEATURES: 'board-master-bed-features',
    COVERED_PATIO_LAYOUT: 'board-covered-patio-layout',
    COVERED_PATIO_FEATURES: 'board-covered-patio-features',
    COVERED_PATIO_DECOR: 'board-covered-patio-decor',
    COVERED_PATIO_SIZE: 'board-covered-patio-size',
    POWDER_ROOM_STYLE: 'board-powder-room-style',
    POWDER_ROOM_COLOR: 'board-powder-room-color',
    POWDER_ROOM_FEATURES: 'board-powder-room-features',
    POWDER_ROOM_DECOR: 'board-powder-room-decor',
    VICTORIAN_LR_LAYOUT: 'board-victorian-lr-layout',
    VICTORIAN_LR_STYLE: 'board-victorian-lr-style',
    VICTORIAN_LR_COLOR: 'board-victorian-lr-color',
    VICTORIAN_LR_DECOR: 'board-victorian-lr-decor',
    MUDROOM_IDEA_LAYOUT: 'board-mudroom-idea-layout',
    MUDROOM_IDEA_STORAGE: 'board-mudroom-idea-storage',
    MUDROOM_IDEA_STYLE: 'board-mudroom-idea-style',
    MUDROOM_IDEA_SETTING: 'board-mudroom-idea-setting',
    SMALL_SPACE_LAYOUT: 'board-small-space-layout',
    SMALL_SPACE_ZONES: 'board-small-space-zones',
    SMALL_SPACE_STYLE: 'board-small-space-style',
    SMALL_KITCHEN_LAYOUT: 'board-small-kitchen-layout',
    SMALL_KITCHEN_STYLE: 'board-small-kitchen-style',
    SMALL_KITCHEN_COLOR: 'board-small-kitchen-color',
    ART_DECO_BA_STYLE: 'board-art-deco-ba-style',
    ART_DECO_BA_FEATURES: 'board-art-deco-ba-features',
    ART_DECO_BA_COLOR: 'board-art-deco-ba-color',
    BG_KITCHEN_FIXTURES: 'board-bg-kitchen-fixtures',
    BG_KITCHEN_STYLE: 'board-bg-kitchen-style',
    BG_KITCHEN_COLOR: 'board-bg-kitchen-color',
    MUD_ENTRY_LAYOUT: 'board-mud-entry-layout',
    MUD_ENTRY_STORAGE: 'board-mud-entry-storage',
    MUD_ENTRY_STYLE: 'board-mud-entry-style',
    SMALL_BY_LANDSCAPE_FEAT: 'board-small-by-landscape-feat',
    SMALL_BY_LANDSCAPE_STYLE: 'board-small-by-landscape-style',
    SMALL_BY_LANDSCAPE_LAYOUT: 'board-small-by-landscape-layout',
    BED_WARDROBE_LAYOUT: 'board-bed-wardrobe-layout',
    BED_WARDROBE_USER: 'board-bed-wardrobe-user',
    BED_WARDROBE_STYLE: 'board-bed-wardrobe-style',
    LIMEWASH_COLOR: 'board-limewash-color',
    LIMEWASH_ROOM: 'board-limewash-room',
    LIMEWASH_STYLE: 'board-limewash-style',
    HOME_DECOR_LR_STYLE: 'board-home-decor-lr-style',
    HOME_DECOR_LR_FEATURES: 'board-home-decor-lr-features',
    HOME_DECOR_LR_BUDGET: 'board-home-decor-lr-budget',
    COFFEE_TABLE_VIBE: 'board-coffee-table-vibe',
    COFFEE_TABLE_SEASON: 'board-coffee-table-season',
    COFFEE_TABLE_ELEMENTS: 'board-coffee-table-elements',
    BA_WALLPAPER_STYLE: 'board-ba-wallpaper-style',
    BA_WALLPAPER_COLOR: 'board-ba-wallpaper-color',
    BA_WALLPAPER_ROOM: 'board-ba-wallpaper-room',
    FIREPLACE_MANTLE_STYLE: 'board-fireplace-mantle-style',
    FIREPLACE_MANTLE_HOLIDAY: 'board-fireplace-mantle-holiday',
    FIREPLACE_MANTLE_FEATURE: 'board-fireplace-mantle-feature',
    ENTRYWAY_LAYOUT: 'board-entryway-layout',
    ENTRYWAY_STORAGE: 'board-entryway-storage',
    ENTRYWAY_STYLE: 'board-entryway-style',
    ENTRYWAY_OUTDOOR: 'board-entryway-outdoor',
    MODERN_TV_WALL_STYLE: 'board-modern-tv-wall-style',
    MODERN_TV_WALL_FEATURE: 'board-modern-tv-wall-feature',
    MODERN_TV_WALL_ROOM: 'board-modern-tv-wall-room',
    GIRLS_BED_THEME: 'board-girls-bed-theme',
    GIRLS_BED_STYLE: 'board-girls-bed-style',
    GIRLS_BED_USER: 'board-girls-bed-user',
    GIRLS_BED_STORAGE: 'board-girls-bed-storage',
    FARMHOUSE_LR_WALL: 'board-farmhouse-lr-wall',
    FARMHOUSE_LR_STYLE: 'board-farmhouse-lr-style',
    FARMHOUSE_LR_FEAT: 'board-farmhouse-lr-feat',
};

export const BOARD_DATA: Record<string, string[]> = {
    [BOARD_IDS.BACKYARD]: ["Backyard Walkway Ideas", "Backyard Walkway Ideas Pathways", "Backyard Paver Walkway Ideas", "Backyard Walkway Ideas Cheap", "Backyard Garden Path Walkway Ideas", "Small Backyard Walkway Ideas", "Backyard Concrete Walkway Ideas", "Backyard Wedding Walkway Ideas", "Backyard Garden Walkway Ideas"],
    [BOARD_IDS.BARBIE]: ["Barbie Storage Ideas", "Barbie Doll Storage Ideas", "Barbie Storage Ideas Organizations", "Barbie Accessories Storage Ideas", "Barbie Clothes Storage Ideas", "Organize Barbie Stuff Storage Ideas", "Barbie Car Storage Ideas", "Barbie Storage Ideas Kids Rooms", "Barbie Organization Ideas Storage", "Barbie House Storage Ideas"],
    [BOARD_IDS.BOHEMIAN]: ["Bohemian Bedroom Colors", "White Bohemian Bedroom", "Bohemian Bedroom Plants", "Bohemian Bedroom Paint Ideas", "Bohemian Bedroom Curtains", "Bohemian Bedroom Furniture", "Natural Bedroom Decor Bohemian Style", "Bohemian Bedroom Rug", "Bohemian Bedroom Green", "Bohemian Bedroom Curtain Ideas", "Bohemian Bedroom Mood Board", "Boho Bedroom Orange Bohemian Style", "Bohemian Bedroom Paint Colors", "Bohemian Bedroom Wall Color", "Bohemian Bedroom Diy", "Bohemian Bedroom Lighting", "Jewel Toned Bedroom Decor Bohemian", "Jewel Tone Bohemian Bedroom", "Sims 4 Bohemian Bedroom", "Bohemian Bedroom Nightstand", "Bohemian Bedroom Accent Wall", "Bohemian Bedroom Green Walls", "Bohemian Bedroom Decor Boho", "Bohemian Bedroom Decor Moroccan Style", "Bohemian Chic Bedroom", "Bohemian Bedrooms", "Bohemian Bedroom Aesthetic", "Bohemian Bedroom Decor Chic", "Hippie Bedroom Decor Bohemian Style", "Bohemian Bedroom Ideas", "Bohemian Bedroom Inspiration", "Modern Bohemian Bedroom", "Bedroom Bohemian", "Bohemian Style Bedroom", "Bohemian Bedroom Design", "Bohemian Bedroom Decor Ideas"],
    [BOARD_IDS.CREAM]: ["White And Cream Bedroom", "Black White And Cream Bedroom", "Cream And White Bedroom Ideas", "Cream And White Bedroom Neutral Tones", "Black White Grey Cream Bedroom", "Blue White And Cream Bedroom", "White Cream And Sage Bedroom", "Black And White And Cream Bedroom Ideas", "Cream Walls With White Trim Bedroom", "Navy White Cream Bedroom"],
    [BOARD_IDS.DARK]: ["Dark Elegant Bedroom", "Elegant Dark Bedroom", "Dark Elegant Bedroom Ideas", "Dark Elegant Bedroom Cozy", "Elegant Dark Bedroom Ideas", "Bedroom Luxury Elegant Modern Dark", "Dark Elegant Bedroom Bohemian", "Elegant Dark Blue Bedroom", "Luxury Bedroom Master Elegant Dark", "Elegant Dark Bedroom Design", "Elegant Bedroom With Dark Wood Furniture", "Dark Elegant Bedroom Modern", "Elegant Dark Blue Bedroom Decor", "Elegant Bedroom With Dark Accent Wall"],
    [BOARD_IDS.APOTHECARY]: ["Home Apothecary", "Home Apothecary Room", "Forgotten Home Apothecary", "Home Apothecary Ideas", "At Home Apothecary", "Home Apothecary Cabinet", "Home Apothecary Storage", "Apothecary Home Decor", "Home Apothecary Room Decorating Ideas"],
    [BOARD_IDS.JACUZZI]: ["Jacuzzi Outdoor", "Jacuzzi Outdoor Ideas", "Outdoor Jacuzzi Ideas", "Outdoor Jacuzzi", "Small Jacuzzi Outdoor", "Jacuzzi Outdoor Ideas Small Backyards", "Diy Jacuzzi Outdoor", "Jacuzzi Outdoor Ideas Patio", "Inflatable Jacuzzi Outdoor Ideas", "Outdoor Jacuzzi Design", "Jacuzzi Outdoor Aesthetic", "In Ground Jacuzzi Outdoor", "Jacuzzi Outdoor Ideas Spa Design", "Sauna And Jacuzzi Outdoor", "Jacuzzi Outdoor Deck", "Jacuzzi Design Outdoor", "Home Jacuzzi Outdoor", "Build In Jacuzzi Outdoor", "Big Jacuzzi Outdoor", "Round Jacuzzi Outdoor", "Luxury Jacuzzi Outdoor", "Inground Jacuzzi Outdoor", "Portable Jacuzzi Outdoor", "Jacuzzi And Fire Pit Outdoor Ideas", "Covered Jacuzzi Outdoor Ideas", "Modern Jacuzzi Outdoor"],
    [BOARD_IDS.PURSE]: ["Purse Storage Ideas", "Purse Storage Ideas Closet", "Purse Storage Ideas Small Spaces", "Purse And Bag Storage Ideas", "Ikea Purse Storage Ideas", "Diy Purse Storage Ideas", "Ideas For Purse Storage", "Purse Storage Ideas Closet Small Spaces", "Bag And Purse Storage Organization Ideas", "Purse And Handbag Storage Ideas", "Hat And Purse Storage Ideas", "Cute Purse Storage Ideas", "Purse And Backpack Storage Ideas"],
    [BOARD_IDS.RAISED_BEDS]: ["Raised Garden Beds Along Fence", "Raised Garden Beds Along Fence Backyards", "Raised Garden Beds Along Fence Retaining Walls", "Stone Raised Garden Beds Along Fence", "Raised Garden Beds Along Fence With Seat"],
    [BOARD_IDS.GYM]: ["Stylish Home Gym", "Stylish Home Gym Interior Design", "Stylish Home Gym Equipment", "Stylish Home Gym Setup", "Stylish Home Gym Decor", "Stylish Home Gym Inspiration"],
    [BOARD_IDS.TILE_SHOWER]: ["Shower Tile Ideas", "Tile Shower Ideas Walk In", "Bathroom Shower Tile Ideas", "Tile Shower Ideas With Tub", "Tile Shower Ideas Walk In With Seat", "Bathroom Tile Ideas Shower Tub Surround Half Walls", "Walk In Shower Tile Ideas Color Schemes", "Stand Up Shower Tile Ideas", "Shower Ceiling Tile Ideas", "Mosaic Tile Shower Wall Bathroom Ideas", "Wood Looking Tile Shower Ideas", "Walk In Shower Tile Ideas Pebble Floor", "Primary Bathroom Shower Tile Ideas", "Tile Shower Ideas Farmhouse", "White Shower Tile Ideas With Blue Accent", "Tile Shower Ideas Green"],
    [BOARD_IDS.WHIMSICAL_KIDS]: ["Whimsical Kids Room", "Whimsical Kids Room Ideas", "Whimsical Kids Room Decor", "Whimsical Fabric For Kids Room"],
    [BOARD_IDS.ACCENT_CEILING]: ["Accent Ceiling Ideas Paint Colors", "Vaulted Ceiling Accent Wall Ideas", "Wood Accent Ceiling Ideas", "Wood Ceiling Accent Ideas", "Accent Wall Ideas Vaulted Ceiling", "Bedroom Accent Wall Ideas Vaulted Ceiling", "Accent Ceiling Ideas", "Tray Ceiling Accent Ideas", "Cathedral Ceiling Accent Wall Ideas", "Living Room Accent Wall Ideas High Ceiling", "Blue Accent Ceiling Ideas", "Bedroom Accent Ceiling Ideas"],
    [BOARD_IDS.BATHROOM_REMODEL]: ["Small Bathroom Ideas Remodel", "Large Bathroom Remodel Ideas", "Bathroom Tub Remodel Ideas", "Half Bathroom Remodel Ideas", "Small Bathroom Remodel Walk In Shower Tile Ideas", "Bathroom Remodel Ideas Farmhouse", "Bathroom Wall Remodel Ideas", "Tiny Bathroom Remodel Ideas", "Remodel Bathroom Ideas", "Kids Bathroom Remodel Ideas", "Farmhouse Bathroom Remodel Ideas", "Bathroom Remodel Walk In Shower Ideas", "Simple Bathroom Remodel Ideas", "Small Bathroom Remodel Ideas On A Budget", "Ideas For Bathroom Remodel", "Small Half Bathroom Remodel Ideas", "Bathroom Remodel Design Ideas", "Bathroom Shower Remodel Ideas", "Rustic Bathroom Remodel Ideas", "Small Bathroom Remodel Ideas 2024", "Vintage Bathroom Remodel Ideas", "Diy Bathroom Remodel Ideas", "Smaller Bathroom Remodel Ideas", "Bathroom Remodel Tile Ideas", "Boho Bathroom Remodel Ideas", "Bathroom Remodel Ideas", "Primary Bathroom Remodel Ideas", "Black And White Bathroom Remodel Ideas", "Full Bathroom Remodel Ideas", "Small Bathroom Remodel Ideas Modern", "Modern Bathroom Remodel Ideas", "Small Bathroom Ideas Remodel Tiny Spaces", "Guest Bathroom Remodel Ideas", "Bathroom Remodel Vanity Ideas", "Small Bathroom Remodel Ideas 2025", "Bathroom Remodel Ideas 2024", "Bathroom Remodel Ideas With Tub", "Small Bathroom Shower Remodel Ideas", "Ideas For Small Bathroom Remodel", "White Bathroom Remodel Ideas"],
    [BOARD_IDS.TOWEL_RACK]: ["Beach Bathroom Towel Rack Ideas", "Towel Folding Ideas Bathroom Rack", "Bathroom Towel Rack Ideas Display", "Bathroom Towel Rack Ideas Hooks", "Towel Rack Bathroom Hanging Ideas", "Modern Bathroom Towel Rack Ideas", "Bathroom Towel Rack Ideas", "Bathroom Towel Rack Ideas Over Toilet", "Farmhouse Bathroom Towel Rack Ideas", "Bathroom Wet Towel Rack Ideas", "Bathroom Ideas Towel Rack", "Diy Towel Rack Bathroom Hanging Ideas", "Small Bathroom Ideas Towel Rack", "Bathroom Towel Drying Rack Ideas", "Towel Rack Bathroom Ideas", "Bathroom Wall Towel Rack Ideas", "Half Bathroom Towel Rack Ideas"],
    [BOARD_IDS.WALL_COLOR]: ["Interior Wall Color Combination Ideas", "Wall Color Combination Bedroom Aesthetic", "Wall Paint Color Combination", "Color Combination For Wall", "Wall And Door Color Combination", "Wall And Floor Color Combination", "Light Color Combination For Bedroom Wall", "Roof And Wall Color Combination Bloxburg", "Wall And Floor Tiles Color Combination", "Wall Door Color Combination", "Wood And Wall Color Combination", "Wall Painting Color Combination", "Bedroom Color Combination Accent Wall", "Interior Wall And Door Color Combination", "Wall Color Combination Ideas", "Pink Wall Color Combination", "Color Combination With Cream Wall", "Living Room Wall Color Combination Ideas", "Geometric Wall Paint Color Combination", "Yellow Wall Color Combination", "Ceiling And Wall Color Combination", "Wall Color Combination For Hall", "Wall Color Combination With Green", "Living Room Color Combination Wall", "Furniture And Wall Color Combination", "Wardrobe And Wall Color Combination", "White Wall And Door Color Combination", "Wall Floor Color Combination", "Bedroom Wall Color Combination Ideas", "Wall Color Combination With Wooden Floor", "Color Combination For Wall Paint", "Color Combination For Bedroom Wall"],
    [BOARD_IDS.THRIFTED]: ["Thrifted Home Decor Diy Ideas", "Thrifted Home Decor", "Rustic Thrifted Home Decor", "Thrifted Home Decor Inspiration", "Vintage Thrifted Home Decor", "Thrifted Home Decor Aesthetic", "Thrifted Home Decor Bedroom", "Thrifted Vs Styled Home Decor", "Thrifted Home Decor Living Room"],
    [BOARD_IDS.BABY_SHOWER]: ["Summer Baby Shower Ideas Girl", "Summer Baby Shower Ideas Gender Neutral", "Girl Baby Shower Ideas Themes Summer", "Baby Boy Summer Shower Ideas", "Summer Themed Baby Shower Ideas", "Outside Baby Shower Ideas Summer", "Summer Citrus Baby Shower Ideas", "Baby Girl Shower Ideas Summer", "Baby Shower Ideas Girl Summer", "Baby Boy Shower Ideas Summer", "Baby Shower Summer Ideas", "Summer Boy Baby Shower Ideas", "Baby Shower Ideas Summer Theme", "Late Summer Baby Shower Ideas", "Summer Girl Baby Shower Ideas", "Summer Time Baby Shower Ideas", "Summer Theme Baby Shower Ideas For Boys", "Boy Summer Baby Shower Ideas", "Summer Baby Girl Shower Ideas", "Baby Girl Baby Shower Ideas Summer", "Girl Summer Baby Shower Ideas", "Simple Summer Baby Shower Ideas", "Summer Baby Shower Food Ideas", "Gender Neutral Baby Shower Ideas Summer", "Boy Baby Shower Ideas Summer", "Baby Boy Shower Ideas Themes Summer"],
    [BOARD_IDS.SMALL_BEDROOM]: ["Bedroom Ideas For Small Rooms Cozy Black", "Small White Bedroom Ideas Cozy", "Aesthetic Small Bedroom Ideas Cozy", "Cozy Small Bedroom Decor Ideas Simple", "Small Guest Bedroom Ideas Cozy", "Small Cozy Bedroom Ideas For Couples", "Bedroom Ideas For Small Rooms Cozy Cheap", "Small Bedroom Ideas Aesthetic Cozy", "Bedroom Ideas For Small Rooms Women Cozy", "Cozy Small Bedroom Ideas", "Cozy Modern Bedroom Ideas Small Rooms", "Small Dark Bedroom Ideas Cozy", "Cozy Bedroom Ideas Small Room", "Small Guest Bedroom Ideas Cozy Simple", "Small Cozy Bedroom Ideas Tiny Apartments", "Small Room Makeover Ideas Bedroom Cozy", "Bedroom Ideas For Small Rooms Cozy", "Bedroom Sitting Area Ideas Small Cozy", "Aesthetic Bedroom Ideas For Small Rooms Cozy", "Small Cozy Bedroom Ideas Fairy Lights Room Decor", "Cozy Small Bedroom Decor Ideas", "Small Bedroom Ideas Cozy Relaxing", "Cute Bedroom Ideas For Small Rooms Cozy", "Small Bedroom Ideas Minimalist Cozy", "Extremely Small Bedroom Ideas Cozy", "Dark Cozy Bedroom Ideas Small Spaces", "Bedroom Ideas For Small Rooms Cozy Boho", "Small Bedroom Decor Ideas For Women Cozy", "Cute Small Bedroom Ideas Cozy"],
    [BOARD_IDS.DARK_GREY_COUCH]: ["Dark Grey Living Room Couch", "Living Room Inspiration Dark Grey Couch", "Small Living Room Decor Dark Grey Couch", "Living Room Decor Dark Grey Couch", "Dark Grey Couch Living Room Rugs", "Dark Blue Grey Couch Living Room", "Dark Grey Couch Colorful Living Room", "Dark Grey L Shaped Couch Living Room", "Modern Living Room Dark Grey Couch", "Apartment Living Room Dark Grey Couch", "Dark Grey Couch Living Room Ideas Modern", "Minimalist Living Room Dark Grey Couch", "Modern Living Room With Dark Grey Couch", "Dark Grey Couch Living Room Ideas Cozy", "Dark Living Room Rugs With Grey Couch", "Living Room Design With Dark Grey Couch", "Small Living Room Ideas Dark Grey Couch", "Living Room Dark Grey Couch", "Dark Grey Couch Living Room Curtains", "Living Room Rug Dark Grey Couch", "Living Room Dark Grey Couch Color Scheme", "Dark Grey Couch Living Room Ideas Colour Schemes", "Dark Grey Couch Living Room Colour Schemes", "Small Living Room Dark Grey Couch", "Dark Grey Couch Living Room Farmhouse", "Living Room With Dark Grey Couch", "Dark Grey Couch Living Room End Tables", "Boho Living Room Dark Grey Couch", "Dark Grey Couch Living Room Decor", "Dark Grey Couch Boho Living Room", "Dark Grey Couch Living Room Ideas", "Dark Grey Leather Couch Living Room", "Living Room Rugs With Dark Grey Couch", "Living Room Ideas Dark Grey Couch"],
    [BOARD_IDS.VICTORIAN_LR_LAYOUT]: [
        "Victorian Living Room Layout", "Victorian Living Room Bay Window", "Victorian Terrace House Living Room", "Victorian Townhouse Living Room", "Victorian Terrace Living Room Ideas", "Large Victorian Living Room", "Small Victorian Living Room Ideas", "Small Victorian Terrace Living Room", "Victorian Open Plan Kitchen Living Room"
    ],
    [BOARD_IDS.VICTORIAN_LR_STYLE]: [
        "Modern Victorian Living Room Ideas", "Dark Victorian Living Room Goth", "Goth Victorian Living Room", "Victorian Farmhouse Living Room", "Gothic Victorian Living Room", "Moody Victorian Living Room", "French Victorian Living Room", "Victorian Mansion Living Room", "Old Victorian Living Room", "Contemporary Victorian Living Room", "Victorian Inspired Living Room", "Victorian Cottage Living Room", "Victorian Style Living Room Ideas", "Modern Victorian Decor Living Room", "Modern Victorian Style Living Room", "Victorian Era Living Room"
    ],
    [BOARD_IDS.VICTORIAN_LR_COLOR]: [
        "Blue Victorian Living Room", "Green Victorian Living Room", "Red Victorian Living Room", "Dark Green Victorian Living Room", "Victorian Living Room Green", "Neutral Victorian Living Room", "White Victorian Living Room", "Black Victorian Living Room", "Victorian Living Room Wallpaper", "Victorian Living Room Paint Color Ideas"
    ],
    [BOARD_IDS.VICTORIAN_LR_DECOR]: [
        "Victorian Living Room Tv Ideas", "Victorian Living Room With Tv", "Tv In Victorian Living Room", "Victorian Curtains Living Room", "Victorian Fireplace Living Room", "Victorian Living Room Furniture", "Victorian Sofa Living Room", "Victorian Furniture Living Room", "Victorian Living Room Decor"
    ],
    [BOARD_IDS.VICTORIAN_LIVING_ROOM]: [
        "Victorian Living Room Layout", "Victorian Living Room Bay Window", "Victorian Terrace House Living Room", "Victorian Townhouse Living Room", "Victorian Terrace Living Room Ideas", "Large Victorian Living Room", "Small Victorian Living Room Ideas", "Small Victorian Terrace Living Room", "Victorian Open Plan Kitchen Living Room",
        "Modern Victorian Living Room Ideas", "Dark Victorian Living Room Goth", "Goth Victorian Living Room", "Victorian Farmhouse Living Room", "Gothic Victorian Living Room", "Moody Victorian Living Room", "French Victorian Living Room", "Victorian Mansion Living Room", "Old Victorian Living Room", "Contemporary Victorian Living Room", "Victorian Inspired Living Room", "Victorian Cottage Living Room", "Victorian Style Living Room Ideas", "Modern Victorian Decor Living Room", "Modern Victorian Style Living Room", "Victorian Era Living Room",
        "Blue Victorian Living Room", "Green Victorian Living Room", "Red Victorian Living Room", "Dark Green Victorian Living Room", "Victorian Living Room Green", "Neutral Victorian Living Room", "White Victorian Living Room", "Black Victorian Living Room", "Victorian Living Room Wallpaper", "Victorian Living Room Paint Color Ideas",
        "Victorian Living Room Tv Ideas", "Victorian Living Room With Tv", "Tv In Victorian Living Room", "Victorian Curtains Living Room", "Victorian Fireplace Living Room", "Victorian Living Room Furniture", "Victorian Sofa Living Room", "Victorian Furniture Living Room", "Victorian Living Room Decor"
    ],
    [BOARD_IDS.VICTORIAN_INTERIOR]: [
        "Old Victorian Homes Interior Kitchen", "Victorian Restaurant Interior", "Victorian Classic Interior", "Victorian Interior Bloxburg", "Folk Victorian House Interior", "Victorian Palace Interior", "Victorian Renovation Interior Design", "Victorian Interior Living Room", "White Victorian House Interior", "Victorian Shop Interior", "Victorian Interior Aesthetic", "Victorian House Uk Interior Design", "Victorian Train Interior", "Victorian Interior Design Kitchen", "Old Victorian Interior", "Luxury Victorian Interior", "Interior Design Victorian Modern", "Small Victorian Terrace Interior Living Rooms", "Victorian Bedroom Interior", "House Interior Victorian", "Victorian Contemporary Interior", "Victorian Houses Interior Ideas", "Victorian Terrace Interior Living Rooms", "Victorian Style Homes Interior Modern", "Classic Victorian Interior", "Goth Victorian House Interior Design", "Colorful Victorian Interior", "Gothic Victorian Homes Interior", "Victorian Semi Detached House Interior", "Dark Victorian Homes Interior", "Victorian Beach House Interior", "Victorian Dollhouse Interior Ideas", "Old Homes Interior Victorian", "Sims 4 Victorian House Interior", "Victorian Home Interior Design", "Old Victorian Homes Interior Bedrooms", "Victorian Paint Colors Interior", "Old Victorian Houses Interior", "Victorian Interior Doors", "Pink Victorian House Interior", "Victorian Interior Design Bedroom", "Victorian Flat Interior", "Victorian Minimalist Interior", "Victorian Mansion Interior Bedrooms", "Victorian Era Interior", "Neo Victorian Interior", "Dark Victorian Interior", "Victorian Interior Design Living Room", "Folk Victorian Interior", "Victorian Modern Interior", "Victorian Era House Interior Design", "Updated Victorian Interior", "Victorian Conservatory Interior", "Victorian Architecture Interior", "Victorian Interior Design 19Th Century", "Vintage House Interior Victorian", "Victorian Style Interior", "Gothic Interior Design Victorian", "Victorian Style Homes Interior", "Gothic Victorian House Interior", "Victorian Terrace House Interior", "Victorian Farmhouse Interior", "Victorian Home Interior", "Victorian Cottage Interior", "Victorian Mansion Interior", "Victorian Dollhouse Interior", "Small Victorian Terrace Interior", "Modern Victorian Interior Design", "Modern Victorian Homes Interior", "Old Victorian Homes Interior", "Victorian Interior", "Victorian Interior Design", "Victorian Homes Interior"
    ],
    [BOARD_IDS.TV_WALL_BED_LAYOUT]: [
        "Blank Wall In Bedroom Ideas", "Half Wall Bedroom Ideas", "Bedroom Side Wall Decor Ideas", "Small Wall Closet Ideas Bedroom", "Large Blank Wall Ideas Bedroom", "Bedroom Bed Wall Ideas", "Bedroom Main Wall Ideas", "Wall Bedroom Ideas", "Wall Closet Ideas Bedroom", "Blank Wall Bedroom Ideas", "Bedroom Empty Wall Ideas", "Empty Wall Ideas Bedroom"
    ],
    [BOARD_IDS.TV_WALL_BED_STYLE]: [
        "Wooden Wall Bedroom Ideas", "Grass Wall Bedroom Ideas", "Wall Color Ideas Bedroom Aesthetic", "Wall Paint Bedroom Ideas", "Bedroom Mirror Ideas Wall", "Bedroom Ideas Black Wall", "Bedroom Cladding Wall Ideas", "Bedroom Wall Trim Ideas", "Wall Pannel Ideas Bedroom", "Stone Wall Bedroom Ideas", "Wall Design Ideas Bedroom Aesthetic", "Green Bedroom Wall Ideas", "Wall Mirror Ideas Bedroom Diy", "Green Accent Wall Bedroom Ideas", "Dark Green Wall Bedroom Ideas", "Pink Wall Room Decor Bedroom Ideas", "Mirror Wall Bedroom Ideas", "White Wall Bedroom Ideas Colour Schemes", "Purple Wall Painting Ideas Bedroom", "Bedroom Paint Ideas Accent Wall", "Black Bedroom Wall Ideas", "Painting Bedroom Wall Ideas", "Wall Paneling Ideas Bedroom", "Bedroom Wall Designs Paint Ideas", "Black Wall Bedroom Ideas", "Wall Painting Ideas Bedroom", "Wall Paneling Ideas Bedroom", "Bedroom Wall Art Painting Ideas", "Wall Painting Ideas Bedroom Unique"
    ],
    [BOARD_IDS.TV_WALL_BED_STORAGE]: [
        "Full Wall Closet Ideas Bedroom", "Bedroom Wall Cabinet Ideas", "Book Shelf Wall Ideas Bedroom", "Wall Bookshelf Ideas Bedroom", "Wall Wardrobe Ideas Bedroom", "Wall Book Shelf Ideas Bedroom", "Bedroom Shelving Ideas Wall Shelves", "Wall Shelf Ideas Bedroom", "Bedroom Wall Shelf Ideas", "Bedroom Wall Storage Ideas"
    ],
    [BOARD_IDS.TV_WALL_BED_DECOR]: [
        "Bedroom Wall Highlight Ideas", "Bedroom Wall Graffiti Ideas", "Bedroom Wall Picture Ideas", "Bedroom Posters Wall Ideas Men", "Bedroom Mirror Wall Ideas", "Feature Bedroom Wall Ideas", "Bedroom Photo Wall Ideas Above Bed", "Bedroom Ideas Posters Wall Art", "Diy Picture Wall Ideas Bedroom", "Bedroom Wall Art Ideas Above Bed", "Wall Colages Bedroom Ideas", "Vision Board On Wall Ideas Bedroom", "Simple Wall Decor Bedroom Easy Diy Cute Ideas", "Couple Bedroom Wall Decor Ideas", "Photo Wall Ideas Bedroom Room Decor", "Bedroom Wall Collage Ideas", "Memory Wall Ideas Bedroom", "Easy Diy Room Decor Wall Art Craft Ideas Bedroom", "Bedroom Gallery Wall Ideas", "Wall Decoration Ideas Bedroom", "Diy Bedroom Decor Ideas Wall Decorations", "Bedroom Poster Ideas Wall Art", "Bedroom Wall Mural Ideas", "Wall Decor Ideas For Bedroom Aesthetic", "Mirror Wall Decor Bedroom Ideas", "Pic Wall Ideas Bedroom", "Album Cover Wall Decor Bedroom Ideas", "Large Bedroom Wall Decor Ideas", "Bedroom Photo Wall Ideas", "Photo Wall Ideas Bedroom", "Picture Wall Ideas Bedroom Aesthetic", "Sticky Notes Ideas Wall Bedroom", "Wall Frames Ideas Bedroom", "Bedroom Wall Art Ideas", "Bedroom Picture Wall Ideas", "Bedroom Posters Wall Ideas", "Wall Decor Ideas For Bedroom", "Wall Posters Ideas Bedroom"
    ],
    [BOARD_IDS.TV_WALL_BEDROOM]: [
        "Blank Wall In Bedroom Ideas", "Half Wall Bedroom Ideas", "Bedroom Side Wall Decor Ideas", "Small Wall Closet Ideas Bedroom", "Large Blank Wall Ideas Bedroom", "Bedroom Bed Wall Ideas", "Bedroom Main Wall Ideas", "Wall Bedroom Ideas", "Wall Closet Ideas Bedroom", "Blank Wall Bedroom Ideas", "Bedroom Empty Wall Ideas", "Empty Wall Ideas Bedroom",
        "Wooden Wall Bedroom Ideas", "Grass Wall Bedroom Ideas", "Wall Color Ideas Bedroom Aesthetic", "Wall Paint Bedroom Ideas", "Bedroom Mirror Ideas Wall", "Bedroom Ideas Black Wall", "Bedroom Cladding Wall Ideas", "Bedroom Wall Trim Ideas", "Wall Pannel Ideas Bedroom", "Stone Wall Bedroom Ideas", "Wall Design Ideas Bedroom Aesthetic", "Green Bedroom Wall Ideas", "Wall Mirror Ideas Bedroom Diy", "Green Accent Wall Bedroom Ideas", "Dark Green Wall Bedroom Ideas", "Pink Wall Room Decor Bedroom Ideas", "Mirror Wall Bedroom Ideas", "White Wall Bedroom Ideas Colour Schemes", "Purple Wall Painting Ideas Bedroom", "Bedroom Paint Ideas Accent Wall", "Black Bedroom Wall Ideas", "Painting Bedroom Wall Ideas", "Wall Paneling Ideas Bedroom", "Bedroom Wall Designs Paint Ideas", "Black Wall Bedroom Ideas", "Wall Painting Ideas Bedroom", "Wall Paneling Ideas Bedroom", "Bedroom Wall Art Painting Ideas", "Wall Painting Ideas Bedroom Unique",
        "Full Wall Closet Ideas Bedroom", "Bedroom Wall Cabinet Ideas", "Book Shelf Wall Ideas Bedroom", "Wall Bookshelf Ideas Bedroom", "Wall Wardrobe Ideas Bedroom", "Wall Book Shelf Ideas Bedroom", "Bedroom Shelving Ideas Wall Shelves", "Wall Shelf Ideas Bedroom", "Bedroom Wall Shelf Ideas", "Bedroom Wall Storage Ideas",
        "Bedroom Wall Highlight Ideas", "Bedroom Wall Graffiti Ideas", "Bedroom Wall Picture Ideas", "Bedroom Posters Wall Ideas Men", "Bedroom Mirror Wall Ideas", "Feature Bedroom Wall Ideas", "Bedroom Photo Wall Ideas Above Bed", "Bedroom Ideas Posters Wall Art", "Diy Picture Wall Ideas Bedroom", "Bedroom Wall Art Ideas Above Bed", "Wall Colages Bedroom Ideas", "Vision Board On Wall Ideas Bedroom", "Simple Wall Decor Bedroom Easy Diy Cute Ideas", "Couple Bedroom Wall Decor Ideas", "Photo Wall Ideas Bedroom Room Decor", "Bedroom Wall Collage Ideas", "Memory Wall Ideas Bedroom", "Easy Diy Room Decor Wall Art Craft Ideas Bedroom", "Bedroom Gallery Wall Ideas", "Wall Decoration Ideas Bedroom", "Diy Bedroom Decor Ideas Wall Decorations", "Bedroom Poster Ideas Wall Art", "Bedroom Wall Mural Ideas", "Wall Decor Ideas For Bedroom Aesthetic", "Mirror Wall Decor Bedroom Ideas", "Pic Wall Ideas Bedroom", "Album Cover Wall Decor Bedroom Ideas", "Large Bedroom Wall Decor Ideas", "Bedroom Photo Wall Ideas", "Photo Wall Ideas Bedroom", "Picture Wall Ideas Bedroom Aesthetic", "Sticky Notes Ideas Wall Bedroom", "Wall Frames Ideas Bedroom", "Bedroom Wall Art Ideas", "Bedroom Picture Wall Ideas", "Bedroom Posters Wall Ideas", "Wall Decor Ideas For Bedroom", "Wall Posters Ideas Bedroom",
        "Tv Wall Bedroom Ideas", "Tv Wall Ideas Bedroom", "Tv On Wall Ideas Bedroom", "Tv Wall Mount Ideas Bedroom Small Spaces", "Under Tv Ideas Wall Mounted Tv Bedroom", "Tv Unit Ideas For Small Bedroom", "Tv Design Wall Bedroom", "Tv Decoration Ideas Bedroom", "Tv Backdrop Ideas Bedroom", "Tv Placement Ideas Bedroom", "Tv Cabinet Ideas Bedroom", "Tv Nook Ideas Bedroom", "Tv Area Ideas Bedroom", "Tv Panel Ideas Bedroom", "Tv Stand Ideas Bedroom"
    ],
    [BOARD_IDS.SMALL_SPACE_LIVING]: [
        "Small Living With Kitchen Open Space", "Small Space Living Dining Room Combo", "Play Area Small Space Living Rooms", "Tv Space Ideas Small Living", "Small Garage Living Space Ideas", "Small Space Living Room Furniture", "Small Space Built Ins Living Room", "Small Space Play Area In Living Room", "Living Small Space", "Small Space Living Bedroom", "Tv Wall Design Small Space Living Room", "Small Work Space In Living Room", "Nordic Living Room Small Space", "Small Corner Office Space In Living Room", "Small Living Room Space-Saving Ideas", "Living Room Small Space Apartments", "Small Play Space In Living Room", "Kitchen Living Room Small Space", "Small Space Living Kitchen", "Living Room Decor Small Space Cozy", "Small Open Space Living Room", "Small Space Kitchen Living Room Combo", "Living Dining Small Space", "Tiny Loft Apartment Small Space Living", "Small Space Kitchen And Living Room", "Small Space Living Room And Dining Room", "Modern Small Space Living Room Ideas", "Small Corner Space Ideas Living Room", "Small Space Boho Living Room", "Small Desk Space In Living Room", "Living Room Tv Wall Small Space", "Farmhouse Living Room Small Space", "Wfh Desk Setup Small Space Living Room", "Small Space Dining And Living Room Ideas", "Small Space Living Apartment", "Small Space Living Room With Work Space", "Living In A Small Space", "Small Open Space Kitchen And Living Room", "Living Area Small Space", "Small Space Decorating Ideas Living Room", "Sectional Living Room Layout Small Space", "Neutral Living Room Small Space", "Small Living Space Decor", "Small Living Ideas Space Saving", "Small Dining Space In Living Room", "Small Living Space Ideas Studio Apt", "Small Outdoor Living Space", "Minimalist Living Room Small Space", "Small Space Living Room Ideas Layout", "Small Space Living And Dining Room Combo", "Small Open Space Living Room And Kitchen", "Small Space Living Hacks", "Living Room Decor Small Space", "Small Space Living", "Living Room Idea For Small Space", "Small Living Space", "Small Space Living Room Ideas", "Small Space Living Room Ideas Tiny Apartments", "Sofa For Small Living Room Space Saving"
    ],
    [BOARD_IDS.SMALL_SPACE_LAYOUT]: [
        "Sectional Living Room Layout Small Space", "Small Space Living Room Ideas Layout", "Small Space Living Room And Dining Room", "Play Area Small Space Living Rooms"
    ],
    [BOARD_IDS.SMALL_SPACE_ZONES]: [
        "Small Corner Office Space In Living Room", "Small Work Space In Living Room", "Small Play Space In Living Room", "Small Desk Space In Living Room", "Small Living Room With Work Space", "Small Dining Space In Living Room"
    ],
    [BOARD_IDS.SMALL_SPACE_STYLE]: [
        "Nordic Living Room Small Space", "Small Space Boho Living Room", "Farmhouse Living Room Small Space", "Minimalist Living Room Small Space", "Living Room Decor Small Space Cozy", "Modern Small Space Living Room Ideas"
    ],
    [BOARD_IDS.SMALL_FRONT_YARD_LANDSCAPING]: [
        "Small Simple Front Yard Landscaping Ideas", "Small Front Yard Landscaping Ideas Arizona", "Small Townhome Front Yard Landscaping", "Small Front Yard Landscaping Hydrangea", "Small Front Yard Landscaping Low Maintenance", "Small Tropical Front Yard Landscaping", "Landscaping For A Small Front Yard", "Small Yard Landscaping Front Curb Appeal", "Small Front Yard Desert Landscaping Ideas", "Small Square Front Yard Landscaping", "Small Brick House Landscaping Front Yard", "Small Front Yard Landscaping Florida", "Small Front Yard Rock Landscaping", "Small Front Yard Landscaping Ideas On A Budget", "Landscaping A Small Front Yard", "Small Hill Landscaping Ideas Front Yard", "Front Yard Landscaping Ideas Small House", "Simple Small Front Yard Landscaping", "Front Yard Small Landscaping", "Small Front Yard Landscaping Ideas Easy", "Small Front Yard Landscaping", "Small Front Yard Landscaping Ideas Minimalist", "Small Front Yard Landscaping Pots & Planters", "Small Home Front Yard Landscaping", "Small Sloped Front Yard Landscaping"
    ],
    [BOARD_IDS.SMALL_KITCHEN_REMODEL]: [
        "Small Kitchen Remodel White", "Small Vintage Kitchen Remodel", "Small Kitchen Remodel L Shaped Layout", "Kitchen Remodel Small Farmhouse", "Small Kitchen Remodel Dark Cabinets", "Small Kitchen Remodel Black Cabinets", "Small Kitchen Remodel Green", "Small U Kitchen Remodel", "Simple Small Kitchen Remodel", "Small Old Kitchen Remodel", "Small U Shape Kitchen Remodel", "Small Kitchen Remodel Ideas With Island", "Small Ranch Kitchen Remodel", "Small Farmhouse Kitchen Remodel", "Small Kitchen Remodel Wood Cabinets", "Small Kitchen Remodel Apartment", "Small Kitchen Remodel With Peninsula", "Kitchen Remodel Ideas Small Space", "Small L Shaped Kitchen Remodel", "Small House Kitchen Remodel", "Small Narrow Kitchen Remodel", "Small Kitchen Remodel Galley", "Small Square Kitchen Remodel", "Small Kitchen Remodel Ideas Cabinets", "Small Kitchen Remodel White Cabinets", "Small Old Kitchen Remodel On A Budget", "Small Galley Kitchen Remodel Ideas", "Small Kitchen Remodel Indian", "Small Corner Kitchen Remodel", "Simple Kitchen Remodel Small Spaces", "Small Galley Kitchen Remodel Layout", "Kitchen Remodel For Small Kitchens", "Small Galley Kitchen Remodel Layout Picture Ideas", "Small Kitchen Remodel Cost", "Small Kitchen Remodel Farmhouse", "Small Apartment Kitchen Remodel", "Small Kitchen Remodel Modern", "Very Small Kitchen Remodel", "Diy Small Kitchen Remodel", "Small Kitchen Remodel Cabinets", "Small Galley Kitchen Remodel On A Budget", "Small Kitchen Remodel Ideas On A Budget", "Remodel Small Kitchen", "Kitchen Remodel Small Space", "Small Kitchen Remodel With Island", "Small Kitchen Remodel L Shaped", "Small U Shaped Kitchen Remodel", "Kitchen Remodel Small Layout", "Small Kitchen Remodel Layout", "Small Galley Kitchen Remodel"
    ],
    [BOARD_IDS.SMALL_KITCHEN_LAYOUT]: [
        "Small Kitchen Remodel L Shaped Layout", "Small U Kitchen Remodel", "Small U Shape Kitchen Remodel", "Small Kitchen Remodel Ideas With Island", "Small Kitchen Remodel With Peninsula", "Small L Shaped Kitchen Remodel", "Small Narrow Kitchen Remodel", "Small Kitchen Remodel Galley", "Small Square Kitchen Remodel", "Small Galley Kitchen Remodel Layout", "Kitchen Remodel Small Layout", "Small Kitchen Remodel Layout", "Small Galley Kitchen Remodel", "Small Kitchen Remodel L Shaped", "Small U Shaped Kitchen Remodel"
    ],
    [BOARD_IDS.SMALL_KITCHEN_STYLE]: [
        "Small Vintage Kitchen Remodel", "Kitchen Remodel Small Farmhouse", "Small Farmhouse Kitchen Remodel", "Small Ranch Kitchen Remodel", "Small Kitchen Remodel Modern", "Diy Small Kitchen Remodel", "Simple Small Kitchen Remodel", "Simple Kitchen Remodel Small Spaces"
    ],
    [BOARD_IDS.SMALL_KITCHEN_COLOR]: [
        "Small Kitchen Remodel White", "Small Kitchen Remodel Dark Cabinets", "Small Kitchen Remodel Black Cabinets", "Small Kitchen Remodel Green", "Small Kitchen Remodel Wood Cabinets", "Small Kitchen Remodel White Cabinets"
    ],
    [BOARD_IDS.SMALL_BA_LAYOUT]: [
        "Small Bathroom With Corner Shower Ideas", "Small Apartment Bathroom Decor Ideas", "Small Spa Bathroom Ideas", "Small Bathroom Ideas Toilet Only", "Small Cabin Bathroom Ideas", "Small Bathroom Ideas With Bathtub", "Small Rectangular Bathroom Ideas", "Very Small Bathroom Ideas With Tub", "Small Jack And Jill Bathroom Ideas", "Small En Suite Bathroom Ideas", "Small Narrow Bathroom Ideas", "Small Pool Bathroom Ideas", "Small Square Bathroom Ideas", "Small Bathroom With Shower Ideas", "Bathroom Tiles Design Ideas Small Spaces", "Mini Bathroom Ideas Small Spaces", "Small Basement Bathroom Ideas", "Small Bathroom Layout Ideas", "Really Small Bathroom Ideas", "Small Long Bathroom Ideas", "Very Small Bathroom Ideas Modern", "Small Full Bathroom Ideas With Tub", "Small Apartment Bathroom Ideas", "Small Bathroom Stand Up Shower Ideas", "Small Bathroom Basin Ideas", "Small Bathroom Partition Ideas", "Small Office Bathroom Ideas", "Small Uk Bathroom Ideas", "Small Toilet Bathroom Ideas", "Small Double Sink Bathroom Ideas", "Small Full Bathroom Ideas Modern", "Small Bedroom Bathroom Ideas", "Small Bathroom Wet Room Ideas", "Extremely Small Bathroom Ideas", "Bathroom Ideas Small With Bathtub", "Small Windowless Bathroom Ideas", "Small Downstairs Bathroom Ideas", "Small Bathroom Ideas No Window"
    ],
    [BOARD_IDS.SMALL_BA_STYLE]: [
        "Farmhouse Small Bathroom Ideas", "Cottage Small Bathroom Ideas", "Small Country Bathroom Ideas", "Small Western Bathroom Ideas", "Small Cottage Bathroom Ideas", "Small Farmhouse Bathroom Ideas", "Small Main Bathroom Ideas", "Small Indian Bathroom Ideas", "Bloxburg Small Bathroom Ideas", "Small Rustic Bathroom Ideas", "Cute Small Bathroom Ideas", "Small Bathroom Renovation Ideas", "Small Bathroom Decor Ideas Modern", "Spa Bathroom Ideas Small Apartment", "Small Girly Bathroom Ideas", "Sims 4 Small Bathroom Ideas", "Small Bathroom Ideas Boho", "Small Bathroom Aesthetic Ideas", "Simple Bathroom Decor Ideas Small Spaces", "Small Bathroom Ideas Colorful", "Small Bathroom Ideas 2024", "Small Bathroom Ideas 2025", "Cozy Bathroom Ideas Small Spaces", "Small Moody Bathroom Ideas", "Small Primary Bathroom Ideas", "Small Full Bathroom Ideas Farmhouse", "Small Bathroom Ideas Modern Space Saving", "Small Bathroom Rental Ideas"
    ],
    [BOARD_IDS.SMALL_BA_COLOR]: [
        "Small Bathroom Color Ideas Paint", "Small Bathroom Ideas Black", "Small Gray Bathroom Ideas", "Small Marble Bathroom Ideas", "Small Bathroom Ideas Black And White", "Small White Bathroom Ideas", "Small Bathroom Ideas Pink", "Small Grey Bathroom Ideas", "Small Bathroom Ideas Green", "Small Beige Bathroom Ideas", "Small Blue Bathroom Ideas", "Small Black And White Bathroom Ideas", "Small Bathroom Ideas Brown", "Small Powder Bathroom Ideas Wallpapers"
    ],
    [BOARD_IDS.SMALL_BA_FEATURES]: [
        "Small Bathroom Accent Wall Ideas", "Small Bathroom Towel Rack Ideas", "Small Bathroom Shower Curtain Ideas", "Small Shower Bathroom Ideas", "Small Shower Ideas Bathroom", "Small Bathroom With Shower Ideas", "Small Bathroom Lighting Ideas", "Small Bathroom Mirror Ideas", "Small Bathroom Window Ideas", "Small Bathroom With Bathtub Ideas", "Small Bathroom Accessories Ideas", "Small Bathroom Flooring Ideas Tile", "Small Bathroom Mirror And Lighting Ideas", "Small Wash Basin Ideas In Living Room", "Small Windowless Bathroom Ideas", "Small Bathroom Hand Towel Holder Ideas"
    ],
    [BOARD_IDS.SMALL_BA_DECOR]: [
        "Small Bathroom Ideas Wallpaper", "Small Bathroom Rug Ideas", "Small Bathroom Wall Ideas", "Small Bathroom Closet Ideas", "Small Bathroom Ceiling Ideas", "Small Bathroom Wainscoting Ideas", "Small Bathroom Floor Tile Ideas", "Small Bathroom Makeover Ideas", "Wallpaper Bathroom Ideas Small Spaces", "Small Bathroom Cabinet Ideas", "Storage Ideas For Small Spaces Bathroom", "Small Bathroom Paneling Ideas", "Small Powder Bathroom Ideas Wallpapers", "Small Half Bathroom Storage Ideas", "Small Bathroom Wall Decor Ideas"
    ],
    [BOARD_IDS.SMALL_BATHROOM_IDEAS]: [
        "Small Bathroom With Corner Shower Ideas", "Small Bathroom Accent Wall Ideas", "Small Bathroom Ideas Toilet Only", "Small Bathroom Color Ideas Paint", "Small Apartment Bathroom Decor Ideas", "Small Spa Bathroom Ideas", "Small Bathroom Ideas Black", "Small Bathroom Towel Rack Ideas", "Small Cabin Bathroom Ideas", "Small Bathroom Ideas With Bathtub", "Bathroom Ideas For Small Rooms", "Small Bathroom Ideas Dark", "Small Bathroom Ideas Colors", "Cottage Small Bathroom Ideas", "Small Country Bathroom Ideas", "Small Bathroom Ideas Wallpaper", "Small Shower Ideas Bathroom", "Toca Boca Small Bathroom Ideas", "Small Rectangular Bathroom Ideas", "Very Small Bathroom Ideas With Tub", "Small Jack And Jill Bathroom Ideas", "Farmhouse Small Bathroom Ideas", "Small En Suite Bathroom Ideas", "Small Gray Bathroom Ideas", "Small Western Bathroom Ideas", "Small Bathroom Rug Ideas", "Small Marble Bathroom Ideas", "Small Bathroom Shower Curtain Ideas", "Small Shower Bathroom Ideas", "Small Narrow Bathroom Ideas", "Small Cottage Bathroom Ideas", "Small Bathroom Ideas Black And White", "Small Pool Bathroom Ideas", "Small Square Bathroom Ideas", "Small Bathroom With Shower Ideas", "Small Farmhouse Bathroom Ideas", "Small Main Bathroom Ideas", "Small Indian Bathroom Ideas", "Small Bathroom Ideas Storage", "Bathroom Tiles Design Ideas Small Spaces", "Mini Bathroom Ideas Small Spaces", "Small Bathroom Wall Ideas", "Small Bathroom Lighting Ideas", "Small Basement Bathroom Ideas", "Small White Bathroom Ideas", "Small Bathroom Closet Ideas", "Small Bathroom Ceiling Ideas", "Small Bathroom Ideas Pink", "Small Beach Bathroom Ideas", "Small Bathroom Layout Ideas", "Small Bathroom Decor Ideas On A Budget", "Bloxburg Small Bathroom Ideas", "Small Bathroom Wainscoting Ideas", "Small Bathroom With Bathtub Ideas", "Bathroom Ideas For Small Bathrooms", "Small Grey Bathroom Ideas", "Really Small Bathroom Ideas", "Small Bathroom Floor Tile Ideas", "Small Dark Bathroom Ideas", "Small Rustic Bathroom Ideas", "Small Long Bathroom Ideas", "Small Bathroom Makeover Ideas", "Very Small Bathroom Ideas Modern", "Small Full Bathroom Ideas With Tub", "Bathroom Color Ideas For Small Bathrooms", "Small Bathroom Ideas Green", "Small Bathroom Window Ideas", "Cute Small Bathroom Ideas", "Small Beige Bathroom Ideas", "Small Apartment Bathroom Ideas", "Small Bathroom Renovation Ideas", "Small Bathroom Mirror Ideas", "Small Blue Bathroom Ideas", "Small Bathroom Tiles Ideas", "Wallpaper Bathroom Ideas Small Spaces", "Bathroom Ideas Small On A Budget", "Small Black And White Bathroom Ideas", "Small Bathroom Stand Up Shower Ideas", "Small Bathroom Cabinet Ideas", "Small Bathroom Basin Ideas", "Small Bathroom Partition Ideas", "Small Bathroom Decor Ideas Modern", "Spa Bathroom Ideas Small Apartment", "Small Bathroom With Laundry Ideas", "Small Bathroom Accessories Ideas", "Small Bathroom Flooring Ideas Tile", "Small Office Bathroom Ideas", "Small Bathroom Ideas Brown", "Small Uk Bathroom Ideas", "Small Bathroom Tile Ideas Modern", "Small Bloxburg Bathroom Ideas", "Small Girly Bathroom Ideas", "Sims 4 Small Bathroom Ideas", "Storage Ideas For Small Spaces Bathroom", "Small Toilet Bathroom Ideas", "Small Double Sink Bathroom Ideas", "Small Full Bathroom Ideas Modern", "Small Bedroom Bathroom Ideas", "Small Bathroom Theme Ideas", "Ensuite Bathroom Ideas Small Decor", "Small Bathroom Wet Room Ideas", "Small Bathroom Hand Towel Holder Ideas", "Extremely Small Bathroom Ideas", "Small Bathroom Ideas Boho", "Bathroom Ideas Small With Bathtub", "Small Bathroom Ideas Wood", "Bath Tub Ideas For Small Bathroom", "Small Bathroom Mirror And Lighting Ideas", "Small Bathroom Aesthetic Ideas", "Simple Bathroom Decor Ideas Small Spaces", "Small Bathroom Ideas Colorful", "Small Bathroom Ideas 2024", "Small Bathroom Paneling Ideas", "On Suite Bathroom Ideas Small Spaces", "Small Powder Bathroom Ideas Wallpapers", "Small Windowless Bathroom Ideas", "Small Downstairs Bathroom Ideas", "Small Bathroom Ideas No Window", "Small Bathroom Ideas Small Decor", "Cozy Bathroom Ideas Small Spaces", "Small Moody Bathroom Ideas", "Small Primary Bathroom Ideas", "Small Half Bathroom Storage Ideas", "Small Full Bathroom Ideas Farmhouse", "Small Bathroom Ideas Modern Space Saving", "Small Bathroom Wall Decor Ideas", "Small Rental Bathroom Ideas", "Small Bathroom Ideas 2025"
    ],
    [BOARD_IDS.POWDER_ROOM_STYLE]: [
        "Japandi Powder Room Ideas", "Vintage Powder Room Ideas", "Powder Room Ideas Farmhouse", "Boho Powder Room Ideas", "Mediterranean Powder Room Ideas", "Transitional Powder Room Ideas", "Traditional Powder Room Ideas", "Rustic Powder Room Ideas", "Powder Room Ideas Organic Modern", "Unique Powder Room Ideas", "Funky Powder Room Ideas", "Dramatic Powder Room Ideas", "Elegant Powder Room Ideas", "Modern Powder Room Ideas", "Powder Room Ideas Modern", "Modern Farmhouse Powder Room Ideas"
    ],
    [BOARD_IDS.POWDER_ROOM_COLOR]: [
        "Pink Powder Room Ideas", "Navy Blue Powder Room Ideas", "Gray Powder Room Ideas", "Powder Room Ideas Blue", "Powder Room Ideas Dark", "Powder Blue Room Ideas", "White Powder Room Ideas", "Grey Powder Room Ideas", "Navy Powder Room Ideas", "Black And White Powder Room Ideas", "Blue Powder Room Ideas", "Green Powder Room Ideas", "Colorful Powder Room Ideas"
    ],
    [BOARD_IDS.POWDER_ROOM_FEATURES]: [
        "Small Powder Room Vanity Ideas", "Powder Room Wainscoting Ideas", "Powder Room Door Ideas", "Small Powder Room Design Ideas", "Powder Room Remodel Ideas", "Powder Room Wall Ideas", "Powder Room Shelf Ideas", "Powder Room Sink Ideas", "Powder Room Lighting Ideas", "Powder Room Cabinet Ideas", "Powder Room Floor Ideas", "Powder Room Tile Ideas", "Powder Room Towel Holder Ideas", "Powder Room Pedestal Sink", "Powder Room Mirror Ideas"
    ],
    [BOARD_IDS.POWDER_ROOM_DECOR]: [
        "Small Powder Room Decor Ideas", "Fun Powder Room Ideas Wallpapers", "Powder Room Hand Towel Ideas", "Powder Room Decor Ideas Half Baths", "Powder Room Styling Ideas", "Powder Room Rug Ideas", "Powder Room Artwork Ideas", "Wallpaper Powder Room Ideas", "Powder Room Decorating Ideas"
    ],
    [BOARD_IDS.POWDER_ROOM_IDEAS]: [
        "Japandi Powder Room Ideas", "Vintage Powder Room Ideas", "Powder Room Ideas Farmhouse", "Boho Powder Room Ideas", "Mediterranean Powder Room Ideas", "Transitional Powder Room Ideas", "Traditional Powder Room Ideas", "Rustic Powder Room Ideas", "Powder Room Ideas Organic Modern", "Unique Powder Room Ideas", "Funky Powder Room Ideas", "Dramatic Powder Room Ideas", "Elegant Powder Room Ideas", "Modern Powder Room Ideas", "Powder Room Ideas Modern", "Modern Farmhouse Powder Room Ideas",
        "Pink Powder Room Ideas", "Navy Blue Powder Room Ideas", "Gray Powder Room Ideas", "Powder Room Ideas Blue", "Powder Room Ideas Dark", "Powder Blue Room Ideas", "White Powder Room Ideas", "Grey Powder Room Ideas", "Navy Powder Room Ideas", "Black And White Powder Room Ideas", "Blue Powder Room Ideas", "Green Powder Room Ideas", "Colorful Powder Room Ideas",
        "Small Powder Room Vanity Ideas", "Powder Room Wainscoting Ideas", "Powder Room Door Ideas", "Small Powder Room Design Ideas", "Powder Room Remodel Ideas", "Powder Room Wall Ideas", "Powder Room Shelf Ideas", "Powder Room Sink Ideas", "Powder Room Lighting Ideas", "Powder Room Cabinet Ideas", "Powder Room Floor Ideas", "Powder Room Tile Ideas", "Powder Room Towel Holder Ideas", "Powder Room Pedestal Sink", "Powder Room Mirror Ideas",
        "Small Powder Room Decor Ideas", "Fun Powder Room Ideas Wallpapers", "Powder Room Hand Towel Ideas", "Powder Room Decor Ideas Half Baths", "Powder Room Styling Ideas", "Powder Room Rug Ideas", "Powder Room Artwork Ideas", "Wallpaper Powder Room Ideas", "Powder Room Decorating Ideas"
    ],
    [BOARD_IDS.ART_DECO_BATHROOM]: [
        "Art Deco Style Bathroom", "Art Deco Bathroom Decor", "Art Deco Small Bathroom", "Green Art Deco Bathroom", "Art Deco Interior Bathroom", "Art Deco Bathroom Mirror", "Art Deco Bathroom Lighting", "Art Deco Tiles Bathroom", "Art Deco Bathroom Design", "Art Deco Bathroom Vanity", "Art Deco Bathroom Tile", "Bathroom Art Deco", "Modern Art Deco Bathroom", "Art Deco Bathroom Ideas", "Art Deco Apartment Bathroom", "Art Deco Public Bathroom", "Art Deco Sconces Bathroom", "Art Deco Marble Bathroom", "Art Deco Bathroom Tile Ideas", "Art Deco Bathroom Floor Tile", "Art Deco Bathroom Art", "White Art Deco Bathroom", "Contemporary Art Deco Bathroom", "Bathroom Decor Art Deco", "20S Bathroom Art Deco", "Modern Art Deco Interior Bathroom", "Art Deco Bathroom Black And White", "Art Deco Guest Bathroom", "Bathroom Art Deco Modern", "Dark Art Deco Bathroom", "Art Deco Bathroom Cabinet", "1930S Bathroom Ideas Art Deco", "Art Deco Black And White Bathroom", "Art Deco Interior Design Bathroom", "80S Art Deco Bathroom", "Art Deco Bathroom Sink", "Small Bathroom Art Deco", "Art Deco Bathroom Ideas Small Spaces", "Moody Art Deco Bathroom", "Vintage Art Deco Bathroom", "Modern Art Deco Bathroom Ideas", "Art Deco Half Bathroom", "Blue Art Deco Bathroom", "Art Deco Inspired Bathroom", "Art Deco Bathroom Wallpaper", "Pink Art Deco Bathroom", "Art Deco Bathroom Accessories", "Art Deco Bathroom Pink"
    ],
    [BOARD_IDS.BEDROOM_IDEAS_FOR_TEENS]: [
        "Disney Bedroom Ideas For Teens", "Christmas Bedroom Ideas For Teens", "Aqua Bedroom Ideas For Teens", "Purple And Gray Bedroom Ideas For Teens", "Paris Bedroom Ideas For Teens", "Very Small Bedroom Ideas For Teens", "Beach Themed Bedroom Ideas For Teens", "Boho Bedroom Ideas For Teens", "Teens Girls Bedroom Ideas", "Bedroom Ideas For Teens Girls Cozy", "Cute Small Bedroom Ideas For Teens", "Small Bedroom Ideas For Teens Boys", "Box Bedroom Ideas For Teens", "Teens Bedroom Ideas For Girls Teenagers", "Teal Bedroom Ideas For Teens", "Light Blue Bedroom Ideas For Teens", "Stitch Bedroom Ideas For Teens", "Lavender Bedroom Ideas For Teens", "Single Bedroom Ideas For Teens", "Blue Bedroom Ideas For Teens", "Beach Bedroom Ideas For Teens", "Ikea Bedroom Ideas For Teens", "Pink Bedroom Ideas For Teens", "Basement Bedroom Ideas For Teens", "Western Bedroom Ideas For Teens", "Horse Bedroom Ideas For Teens", "Cowgirl Bedroom Ideas For Teens", "Black Bedroom Ideas For Teens", "Attic Bedroom Ideas For Teens", "Cool Bedroom Ideas For Teens", "Black And White Bedroom Ideas For Teens"
    ],
    [BOARD_IDS.BLACK_AND_GOLD_KITCHEN]: [
        "Black And Gold Kitchen Chandelier", "Black And Gold Kitchen Aesthetic", "Kitchen Decor Black And Gold", "Gold And Black Kitchen Faucet", "Kitchen With Black And Gold Appliances", "Black And Gold Handles Kitchen", "Modern Black And Gold Kitchen", "Gold White And Black Kitchen", "Beige Black And Gold Kitchen", "Black Brown And Gold Kitchen", "Kitchen With Black And Gold Accents", "Black And Gold Kitchen Countertops", "Black And Gold Modern Kitchen", "Gold And Black Kitchen Ideas", "Black And Gold Kitchen Decor Apartment", "Black And Gold Kitchen Sink", "Kitchen With Black And Gold Hardware", "White Black And Gold Kitchen Ideas", "Black White And Gold Kitchen Decor Ideas", "Black And Gold Pendant Lights Over Kitchen Island", "Grey Black And Gold Kitchen", "Black And Gold Light Fixture Kitchen", "Black And Gold Kitchen Ideas Modern", "Black And White Kitchen With Gold Hardware", "Black And Gold Kitchen Lighting", "Black And Gold Mixed Metals Kitchen", "Black Cream And Gold Kitchen", "Black And Gold Marble Kitchen", "Kitchen Ideas Black And Gold", "Black And Gold Cabinets Kitchen", "Sage Green Black And Gold Kitchen", "Black And Gold Backsplash Kitchen", "Black White And Gold Kitchen Decor", "Green Black And Gold Kitchen", "Black And Gold Kitchen Decor Ideas", "Kitchen Black And Gold", "Black And Gold Appliances Kitchen", "Black White And Gold Kitchen Ideas", "White Gold And Black Kitchen", "Black Gold And White Kitchen", "Black And Gold Kitchen Hardware", "Black And Gold Hardware Kitchen", "Black And Gold Pendant Light Kitchen", "White Black And Gold Kitchen", "Black And Gold Kitchen Decor", "Black White And Gold Kitchen", "Black And Gold Kitchen Ideas"
    ],
    [BOARD_IDS.BEDROOM_IDEAS_WITH_DESK]: [
        "Bedroom Ideas With Desk Area", "Apartment Bedroom Ideas With Desk", "Bedroom Ideas With Tv And Desk", "Small Bedroom Ideas With Computer Desk", "Cozy Bedroom With Desk Ideas", "Square Bedroom Layout Ideas With Desk", "Bedroom Ideas For 2 Sisters With Desk", "Bedroom With Desk Ideas Layout", "Bedroom Ideas With A Desk", "Bedroom Ideas With Desk Study Areas", "Bedroom Ideas With Vanity And Desk", "Guest Bedroom Ideas With Desk", "Bedroom With Computer Desk Ideas", "Small Bedroom Layout Ideas With Desk And Dresser", "Small Bedroom With Desk Ideas", "Bedroom With Desk Layout Ideas", "Small Bedroom Ideas With Wardrobe And Desk", "Room With Desk Ideas Bedroom", "Small Bedroom Layout Ideas With Desk", "Bedroom Ideas With Desk"
    ],
    [BOARD_IDS.COTTAGE_BATHROOM_IDEAS]: [
        "Lake House Bathroom Ideas Cottage", "Dark Cottage Bathroom Ideas", "Cottage Bathroom Ideas Rustic", "Bathroom Ideas Cottage Style", "Tiny Cottage Bathroom Ideas", "Coastal Cottage Bathroom Ideas", "Cottage Core Aesthetic Bathroom Ideas", "White Cottage Bathroom Ideas", "Cottage Bathroom Shower Ideas", "Cottage Bathroom Ideas Farmhouse", "Cottage Bathroom Flooring Ideas", "Cottage Half Bathroom Ideas", "Bathroom Cottage Ideas", "Cottage Bathroom Decor Ideas", "Beach Cottage Bathroom Ideas", "Small Bathroom Ideas Cottage", "Cottage Bathroom Vanity Ideas", "Cottage Bathroom Tile Ideas", "Cozy Cottage Bathroom Ideas", "Cottage Core Bathroom Ideas", "Cottage Core Bathroom Decor Ideas", "Vintage Cottage Bathroom Ideas", "Cottage Style Bathroom Ideas", "Cottage Small Bathroom Ideas", "Cottage Bathroom Design Ideas", "Small Cottage Bathroom Ideas", "French Cottage Bathroom Ideas", "English Cottage Bathroom Ideas", "Cottage Bathroom Ideas"
    ],
    [BOARD_IDS.DARK_HALLWAY_IDEAS]: [
        "Dark Hallway Decorating Ideas", "Dark Paint Hallway Ideas", "Dark Floor Hallway Ideas", "Dark Painted Hallway Ideas", "Dark Narrow Hallway Ideas Wall Colors", "Small Dark Hallway Ideas Brighten", "Dark Wood Hallway Ideas", "Dark Green Hallway Ideas Entrance Halls", "Dark Teal Hallway Ideas", "Hallway Ideas Dark Wood Floor", "Dark Hallway Paint Ideas", "Dark Hallway Ideas Color Schemes", "Dark Hallway Lighting Ideas", "Hallway Ideas Dark", "Dark Grey Hallway Ideas", "Long Dark Hallway Ideas", "Dark Green Hallway Ideas", "Narrow Dark Hallway Ideas", "Small Dark Hallway Ideas", "Dark Hallway Ideas Brighten", "Dark Hallway Ideas", "Dark Wood Floor Hallway Ideas", "Dark Red Hallway Ideas", "Dark Hallway Design Ideas", "Dark Colour Hallway Ideas", "Dark Victorian Hallway Ideas", "Dark Long Hallway Ideas", "Dark Gray Hallway Ideas", "Long Narrow Dark Hallway Ideas"
    ],
    [BOARD_IDS.BEDROOM_IDEAS_WHITE_FURNITURE]: [
        "White Bedroom Ideas Brown Furniture", "White Wood Bedroom Furniture Decorating Ideas", "White Bedroom Ideas With Dark Furniture", "Neutral Bedroom Ideas White Furniture", "Western Bedroom Ideas White Furniture", "Bedroom Decor Ideas With White Furniture", "Bedroom Ideas With White Furniture Cozy", "Bedroom Ideas For Small Rooms White Furniture", "Bedroom Paint Ideas With White Furniture", "White Furniture Bedroom Ideas Decorating", "Bedroom With White Furniture Ideas", "Grey Bed White Furniture Bedroom Ideas"
    ],
    [BOARD_IDS.FOYER_AREA]: [
        "Foyer Dog Area", "Foyer Area Wall Design Entrance", "Foyer Area In Living Room", "Foyer Area Rugs", "Foyer Decorating Small Area", "Foyer Area Cabinet Design", "Buddha In Foyer Area", "Wallpaper For Foyer Area", "False Ceiling For Foyer Area", "Foyer Area Design Entrance Indian", "Foyer Area Interior Design", "Foyer With Seating Area", "Foyer Sitting Area", "Foyer Area Ceiling Design", "Foyer Area Design Entrance", "Foyer Area Design", "Foyer Area Design Entrance Modern", "Small Foyer Area Design Entrance", "Foyer Area Design Entrance Minimalist", "Foyer Area Mirror Design", "Shoe Rack In Foyer Area", "Foyer Area Shoe Rack Design", "Foyer Area Shoe Rack Design", "Foyer Sitting Area Entryway", "Foyer Area False Ceiling Design", "Foyer Area Wall Design"
    ],
    [BOARD_IDS.STAMPED_CONCRETE_PATIO_IDEAS]: [
        "Raised Stamped Concrete Patio Ideas", "Stamped Concrete Patio Ideas Wood Plank", "Stamped Concrete Patio Color Ideas", "Patio Ideas Stamped Concrete", "Stamped Concrete Patio Ideas With Steps", "Stamped Concrete Patio Ideas Pool Decks", "Small Stamped Concrete Patio Ideas", "Wood Stamped Concrete Patio Ideas", "Modern Stamped Concrete Patio Ideas"
    ],
    [BOARD_IDS.SHABBY_CHIC_BEDROOMS]: [
        "Shabby Chic Bedrooms Curtains & Drapes", "Master Bedrooms Shabby Chic", "Master Bedrooms Decor Shabby Chic", "Shabby Chic Master Bedrooms Decorating Ideas", "Rustic Master Bedrooms Decor Shabby Chic", "Simple Shabby Chic Bedrooms", "Boho Shabby Chic Decor Bohemian Bedrooms", "Shabby Chic Bedrooms Pink", "Dreamy Bedrooms Romantic Shabby Chic", "Shabby Chic Bedrooms Decorating Ideas", "Shabby Chic Bedrooms On A Budget", "Shabby Chic Bedrooms", "Shabby Chic Bedrooms Romantic"
    ],
    [BOARD_IDS.MUD_ENTRY_LAYOUT]: [
        "Small Mudroom Ideas Entryway", "Narrow Mudroom Ideas Entryway", "Tiny Mudroom Ideas Entryway", "Small Mudroom Ideas Entryway Entrance", "Mudroom Ideas Entryway Modern"
    ],
    [BOARD_IDS.MUD_ENTRY_STORAGE]: [
        "Mudroom Storage Ideas", "Mudroom Shoe Storage Ideas", "Mudroom Closet Ideas", "Mudroom Cabinet Ideas", "Mudroom Locker Ideas"
    ],
    [BOARD_IDS.MUD_ENTRY_STYLE]: [
        "Mudroom Wall Ideas", "Mudroom Paint Color Ideas", "Modern Mudroom Ideas", "Rustic Mudroom Ideas", "Moody Mudroom Ideas", "Wallpaper Mudroom Ideas"
    ],
    [BOARD_IDS.MUDROOM_IDEAS_ENTRYWAY]: [
        "Mudroom Ideas", "Small Mudroom Ideas Entryway", "Small Mudroom Ideas", "Garage Mudroom Ideas", "Mudroom Laundry Room Ideas", "Entry Mudroom Ideas", "Garage Mudroom Ideas Diy", "Tiny Mudroom Ideas Entryway", "Mudroom Ideas Entryway Garage", "Mudroom Storage Ideas", "Mudroom Flooring Ideas", "Narrow Mudroom Ideas Entryway", "Entryway Mudroom Ideas", "Corner Mudroom Ideas", "Mudroom Tile Floor Ideas", "Mudroom Bench Ideas", "Mudroom Shoe Storage Ideas", "Mudroom Closet Ideas", "Bloxburg Mudroom Ideas", "Ikea Mudroom Ideas", "Mudroom Paint Color Ideas", "Modern Mudroom Ideas", "Mudroom Wall Ideas", "Small Mudroom Laundry Room Ideas", "Mudroom Design Ideas", "Large Mudroom Ideas Entryway", "Mudroom Ideas Entryway Laundry", "Farmhouse Mudroom Ideas Entryway", "Mudroom Organization Ideas", "Mudroom In Garage Ideas", "Mudroom Laundry Room Ideas Layout", "Mudroom Decor Ideas", "Rustic Mudroom Ideas", "Mudroom Color Ideas", "Wallpaper Mudroom Ideas", "Mudroom Locker Ideas", "Mudroom Ideas Entryway Modern"
    ],
    [BOARD_IDS.MINT_GREEN_BEDROOM]: [
        "Mint Green Rooms Bedroom", "Mint Green And Coral Bedroom", "Navy Blue And Mint Green Bedroom", "Mint Green Bedroom Ideas For Adults", "Purple And Mint Green Bedroom", "Mint Green And Peach Bedroom", "Bedroom With Mint Green Walls", "Mint Green Room Decor Bedroom", "Mint Green Curtains Bedroom", "Mint Green And Gold Bedroom", "Mint Green And Lilac Bedroom", "Mint Green Boho Bedroom", "Mint Green Furniture Bedroom", "Mint Green And Navy Bedroom", "Mint Green Bedroom Design", "Mint Green And Cream Bedroom", "Mint Green And Brown Bedroom", "Mint Green Bedroom Walls Color Pallets", "Mint Green Wall Bedroom", "Mint Green Aesthetic Bedroom", "Black And Mint Green Bedroom", "Bedroom Ideas Mint Green", "Mint Green Bedroom Decor", "Mint Green And White Bedroom", "Mint Green Walls Bedroom", "Mint Green And Grey Bedroom", "Mint Green Girls Bedroom", "Bedroom Mint Green", "Mint Green Bedroom Walls", "Mint Green And Pink Bedroom", "Mint Green Bedroom Aesthetic", "Mint And Green Bedroom", "Mint Green And Gold Bedroom Ideas", "Mint Green Guest Bedroom", "Mint Green Navy Blue And Grey Bedroom", "Mint Green Pink And Grey Bedroom", "Mint Green And Orange Bedroom"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_FEAT]: [
        "Small Backyard Modern Landscaping", "Small Backyard Landscaping Flowers", "Small Backyard Turf Landscaping", "Small Backyard Corner Landscaping Ideas", "Easy Small Backyard Landscaping", "Small Backyard Fence Landscaping"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_STYLE]: [
        "Modern Small Backyard Landscaping", "Boho Small Backyard Landscaping", "Western Small Backyard Landscaping", "Rustic Small Backyard Landscaping", "Minimalist Small Backyard Landscaping"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_LAYOUT]: [
        "Small Backyard Landscaping Ideas Layout", "Small Step Backyard Landscaping", "Small Backyard Layout Ideas", "Small Zen Backyard Landscaping"
    ],
    [BOARD_IDS.SMALL_BACKYARD_LANDSCAPING]: [
        "Small Backyard Modern Landscaping", "Small Backyard Landscaping Flowers", "Small Backyard Turf Landscaping", "Small Backyard Corner Landscaping Ideas", "Easy Small Backyard Landscaping", "Small Backyard Fence Landscaping",
        "Modern Small Backyard Landscaping", "Boho Small Backyard Landscaping", "Western Small Backyard Landscaping", "Rustic Small Backyard Landscaping", "Minimalist Small Backyard Landscaping",
        "Small Backyard Landscaping Ideas Layout", "Small Step Backyard Landscaping", "Small Backyard Layout Ideas", "Small Zen Backyard Landscaping"
    ],
    [BOARD_IDS.BED_WARDROBE_LAYOUT]: [
        "Bedroom Wardrobe Layout Ideas", "Small Bedroom Wardrobe Ideas", "Corner Bedroom Wardrobe Ideas", "Built In Bedroom Wardrobe Ideas", "Wardrobe In Bedroom Ideas"
    ],
    [BOARD_IDS.BED_WARDROBE_USER]: [
        "Kids Bedroom Wardrobe Ideas", "Mens Bedroom Wardrobe Ideas", "Girls Bedroom Wardrobe Ideas", "Teen Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.BED_WARDROBE_STYLE]: [
        "Modern Bedroom Wardrobe Ideas", "Farmhouse Bedroom Wardrobe Ideas", "Simple Bedroom Wardrobe Ideas", "Aesthetic Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.BEDROOM_IDEAS_WARDROBE]: [
        "Bedroom Wardrobe Layout Ideas", "Small Bedroom Wardrobe Ideas", "Corner Bedroom Wardrobe Ideas", "Built In Bedroom Wardrobe Ideas", "Wardrobe In Bedroom Ideas",
        "Kids Bedroom Wardrobe Ideas", "Mens Bedroom Wardrobe Ideas", "Girls Bedroom Wardrobe Ideas", "Teen Bedroom Wardrobe Ideas",
        "Modern Bedroom Wardrobe Ideas", "Farmhouse Bedroom Wardrobe Ideas", "Simple Bedroom Wardrobe Ideas", "Aesthetic Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.LIMEWASH_WALLS]: [
        "Light Gray Limewash Walls", "Limewash Basement Walls", "Sand Limewash Walls", "Limewash Shower Walls", "Ivory Limewash Walls", "How To Limewash Walls", "Grey Limewash Walls Bedroom", "Limewash Walls Dining Room", "Limewash Walls Interiors Bedroom", "Limewash Walls Panelling", "Dark Limewash Walls Bedroom", "Limewash Walls And Ceiling", "Limewash Walls Nursery", "Blush Limewash Walls", "Bathroom Limewash Walls", "Limewash Walls With Molding", "Limewash Walls Office", "Limewash Walls Interiors Living Room", "Limewash Walls Exterior", "Light Gray Limewash Walls", "Navy Limewash Walls", "Limewash Walls Gray", "Limewash On Textured Walls", "Light Blue Limewash Walls", "Yellow Limewash Walls", "Neutral Limewash Walls", "Taupe Limewash Walls", "Sage Limewash Walls", "Limewash Textured Walls", "Light Limewash Walls", "Purple Limewash Walls", "Orange Limewash Walls", "Dark Green Limewash Walls", "Cream Limewash Walls", "Terracotta Limewash Walls", "How To Limewash Interior Walls", "Limewash Kitchen Walls", "Limewash Interior Walls", "Limewash Walls Green", "Faux Limewash Walls Diy", "Limewash Walls Bathroom", "Limewash Bathroom Walls", "White Limewash Walls", "Beige Limewash Walls", "Limewash Walls Living Rooms", "Grey Limewash Walls", "Dark Limewash Walls", "Limewash Walls Bedroom", "Faux Limewash Walls", "Blue Limewash Walls", "Limewash Walls Interiors"
    ],
    [BOARD_IDS.HOME_DECOR_IDEAS_LIVING_ROOM]: [
        "Home Decor Ideas Living Room Color", "Spiritual Decor Ideas Home Living Room", "African Home Decor Ideas Living Room", "Home Decor Ideas Living Room Colorful", "Safari Living Room Ideas Home Decor", "Antique Home Decor Ideas Living Room", "Living Ideas Room Home Decor", "Grey Black And White Living Room Ideas Home Decor", "Home Decor Ideas With Plants Living Room", "Home Living Room Decor Ideas", "Home Decor Ideas Living Room Indian", "Home Decor Ideas Living Room", "Home Decor Ideas Living Room Fireplace Interior Design", "Western Home Decor Living Room Southwestern Style Ideas", "Navy Blue Living Room Ideas Home Decor", "Home Decor Ideas Living Room Grey Couch", "Home Decor Ideas Living Room Shelves", "Home Decor Ideas Living Room Fireplace", "Home Decor Ideas Living Room Green", "Blue Living Room Ideas Home Decor", "Bay Window Ideas Living Room Home Decor", "Home Decor Ideas Living Room Boho", "Dollar Tree Diy Home Decor Ideas Living Room", "Home Decor Ideas Living Room On A Budget House", "Home Decor Ideas Living Room Cozy Big Windows", "Home Decor Ideas Living Room Simple", "Home Decor Ideas Living Room Black", "First Home Ideas Decor Living Room", "Home Decor Ideas Living Room Diy", "Curtains Living Room Ideas Home Decor", "Bohemian Home Decor Ideas Living Room", "Living Room Theme Ideas Colour Schemes Home Decor", "Home Decor Ideas Living Room On A Budget Apartments", "Living Room Tv Wall Ideas Small Apartments Home Decor", "Home Decor Ideas Small Living Room", "Glam Home Decor Ideas Living Room", "Home Decor Ideas Living Room Modern Cozy", "Home Wall Decor Ideas Living Room", "Home Decor Ideas Living Room Modern", "Home Decor Ideas Living Room Traditional Wall Art", "Cute Home Decor Ideas Living Room", "Home Decor Ideas Living Room Cozy Small Spaces Tiny House", "Home Decor Living Room Ideas", "Home Decor Ideas Living Room Small Space", "Home Decor Ideas Living Room On A Budget", "Home Decor Ideas Living Room Modern Interior Design", "Cozy Home Decor Ideas Living Room", "Home Decor Ideas Living Room Apartment", "Christmas Home Decor Ideas Living Room", "Home Decor Ideas Living Room Farmhouse", "Home Decor Ideas Living Room Cozy", "Home Decor Ideas Living Room And Kitchen"
    ],
    [BOARD_IDS.COFFEE_TABLE_DECOR_IDEAS]: [
        "Stylish Coffee Table Decor Ideas", "Coffee Table Decor Ideas 2025", "Coffee Table Books Decor Ideas", "Creative Coffee Table Decor Ideas", "Cozy Coffee Table Decor Ideas", "Coffee Table Top Ideas Decor", "Tray Decor Ideas Coffee Table", "Fall Decor Ideas For Coffee Table", "Glam Coffee Table Decor Ideas", "Unique Coffee Table Decor Ideas", "Table Coffee Decor Ideas", "Coffee Table Tray Decor Ideas", "Coffee Table Fall Decor Ideas", "Coffee Table Decor Ideas", "Coffee Table Decor Ideas Centerpieces", "Formal Coffee Table Decor Ideas", "Coffee Table Decor Ideas Round", "Round Coffee Table Fall Decor Ideas", "Nesting Coffee Table Decor Ideas", "Western Coffee Table Decor Ideas", "Under Coffee Table Decor Ideas", "Living Room Round Coffee Table Decor Ideas", "Decor Ideas For Coffee Table", "Coffee Table Xmas Decor Ideas", "Winter Coffee Table Decor Ideas", "Halloween Coffee Table Decor Ideas", "Summer Coffee Table Decor Ideas", "Ottoman Coffee Table Decor Ideas", "Small Coffee Table Decor Ideas", "Outdoor Coffee Table Decor Ideas", "Large Coffee Table Decor Ideas", "Coffee Table Decor Ideas Living Room", "White Coffee Table Decor Ideas", "Diy Coffee Table Decor Ideas", "Ideas For Coffee Table Decor", "Glass Coffee Table Decor Ideas", "Side Coffee Table Decor Ideas", "Oval Coffee Table Decor Ideas", "Spring Coffee Table Decor Ideas", "Coastal Coffee Table Decor Ideas", "Christmas Decor Ideas Coffee Table", "Christmas Decor Ideas For Coffee Table", "Vintage Coffee Table Decor Ideas", "Christmas Coffee Table Decor Ideas", "Minimalist Coffee Table Decor Ideas", "Boho Coffee Table Decor Ideas", "Farmhouse Coffee Table Decor Ideas", "Rustic Coffee Table Decor Ideas", "Black Coffee Table Decor Ideas", "Coffee Table Halloween Decor Ideas", "Round Coffee Table Decor Ideas", "Modern Coffee Table Decor Ideas", "Living Room Coffee Table Decor Ideas", "Coffee Table Christmas Decor Ideas"
    ],
    [BOARD_IDS.BATHROOM_WALLPAPER_IDEAS]: [
        "Peal And Stick Wallpaper Ideas Bathroom", "Fun Half Bathroom Ideas Wallpaper", "Flower Wallpaper Bathroom Ideas", "Vintage Wallpaper Bathroom Ideas", "Moody Bathroom Ideas Wallpaper", "Bathroom Decor Ideas Wallpaper", "Tropical Wallpaper Bathroom Ideas", "Coastal Bathroom Wallpaper Ideas", "Pink Wallpaper Bathroom Ideas", "Small Bathroom With Wallpaper Ideas", "Tropical Bathroom Wallpaper Ideas", "Black Wallpaper Bathroom Ideas", "Boys Bathroom Wallpaper Ideas", "Green Wallpaper Bathroom Ideas", "Bathroom Ideas With Wallpaper", "Wallpaper Ideas Bathroom", "Textured Wallpaper Bathroom Ideas", "Guest Bathroom Ideas With Wallpaper", "Half Bathroom Wallpaper Ideas Farmhouse", "Wallpaper Bathroom Ceiling Ideas", "Small Guest Bathroom Wallpaper Ideas", "Wallpaper Ceiling Ideas Bathroom", "Blue Bathroom Wallpaper Ideas", "Bathroom Paint And Wallpaper Ideas", "Half Bathroom Ideas With Wallpaper", "Tiny Bathroom Wallpaper Ideas", "Small Half Bathroom Wallpaper Ideas", "Modern Bathroom Wallpaper Ideas", "Wallpaper Small Bathroom Ideas", "Kids Bathroom Wallpaper Ideas", "Floral Wallpaper Bathroom Ideas", "Bathroom Ceiling Wallpaper Ideas", "Farmhouse Bathroom Wallpaper Ideas", "Wallpaper Bathroom Ideas Vintage", "Bathroom Wallpaper Ideas Accent Wall", "Wallpaper Bathroom Ideas Modern", "Guest Bathroom Ideas Wallpaper", "Small Half Bathroom Ideas Wallpaper", "Bathroom Ideas Wallpaper", "Wallpaper Bathroom Ideas Small Spaces", "Guest Bathroom Wallpaper Ideas"
    ],
    [BOARD_IDS.DARK_COTTAGECORE_KITCHEN]: [
        "Dark Academia Cottagecore Kitchen", "Dark Cottagecore Decor Kitchen", "Dark Cottagecore Kitchen Ideas", "Dark Cottagecore Kitchen Aesthetic", "Dark Cottagecore Kitchen"
    ],
    [BOARD_IDS.SMALL_LR_LAYOUT]: [
        "Sofa Ideas Living Room Small Spaces", "Small L Shaped Living Room Ideas", "Small Loft Living Room Ideas", "Small Living Room Space-Saving Ideas", "Small Living Room Seating Ideas Layout", "Living Room Condo Ideas Small Spaces", "Small Living Room Sectional Ideas Layout", "Small Space Living Room Ideas Layout", "Small Living Dining Room Ideas Layout", "Small Living Room Arrangement Ideas", "Small Living Room Ideas Apartment Layout", "Small Living Room Seating Ideas", "Small Living And Dining Room Ideas", "Small Space Living Room Ideas", "Small Living Room Furniture Ideas", "Sofa Ideas For Small Living Room", "Living Room Chairs Ideas Small Spaces", "Small Living Room Couch Ideas", "Small Living Room Table Ideas", "Small Long Living Room Ideas"
    ],
    [BOARD_IDS.SMALL_LR_STYLE]: [
        "Small Living Room Ideas Boho", "Small Victorian Living Room Ideas", "Small Living Room Ideas Apartment Boho", "Aesthetic Small Living Room Ideas", "Scandinavian Small Living Room Ideas", "Small Living Room Ideas Farmhouse", "Elegant Small Living Room Ideas", "Small Cottage Living Room Ideas", "Minimalist Small Living Room Ideas", "Rustic Small Living Room Ideas", "Small Living Room Ideas Cozy", "Small Living Room Decor Ideas Cozy", "Cozy Living Room Ideas For Small Spaces", "Small Living Room Ideas Aesthetic", "Small Living Room Ideas Cozy Rustic", "Small Simple Living Room Ideas", "Small Dark Living Room Ideas", "Scandinavian Small Living Room Ideas", "Small Formal Living Room Ideas"
    ],
    [BOARD_IDS.SMALL_LR_FEATURES]: [
        "Small Tv Living Room Ideas", "Small Tv Wall Ideas Living Room", "Small Living Room With Tv Ideas", "Small Living Room Tv Wall Ideas", "Tv Room Ideas Cozy Small Living", "Small Living Room Fireplace Ideas", "Small Alcove Ideas Living Room", "Alcove Ideas Living Room Small Spaces", "Small Nook Ideas Living Room", "Small Corner Ideas Living Room", "Corner Living Room Ideas Small Spaces", "Small Living Room Window Ideas", "Small Bay Window Ideas Living Room", "Living Room Divider Ideas Small Spaces", "Small Living Room With Kitchen Ideas", "Small Open Kitchen And Living Room Ideas", "Small Kitchen And Living Room Ideas", "Small Living Room Ideas With Dining Area", "Small Living Room Dining Room Ideas", "Small Living Dining Room Ideas Layout", "Small Living Room Ideas With Desk", "Small Living Room Office Ideas", "Small Bar In Living Room Ideas", "Small Living Room Toy Storage Ideas", "Mini Bar Ideas Small Spaces Living Room", "Small Living Room Bar Ideas", "Small Entryway Ideas In Living Room"
    ],
    [BOARD_IDS.SMALL_LR_DECOR]: [
        "Small Living Room Wallpaper Ideas", "Small Living Room Accent Wall Ideas", "Small Living Room Wall Color Ideas", "Small Living Room Wall Ideas", "Small Living Room Wall Decor Ideas", "Small Living Room Decor Ideas", "Small Living Room Carpet Ideas", "Small Living Room Curtains Ideas", "Wall Mirror Ideas Living Room Small Spaces", "Small Living Room Lighting Ideas", "Home Decor Ideas Small Living Room", "Small Living Room Paint Ideas", "Small Living Room Color Ideas", "Small Living Room Colour Ideas", "Living Room Small Wall Decor Ideas", "Small Living Room Storage Ideas", "Small Living Room Shelving Ideas", "Bookshelf Living Room Ideas Small Spaces"
    ],
    [BOARD_IDS.SMALL_LIVING_ROOM_IDEAS]: [
        "Small Living Room Wallpaper Ideas", "Small Tv Living Room Ideas", "Small Living Room Office Ideas", "Small Living Room Accent Wall Ideas", "Small Western Living Room Ideas", "Small Living Room Carpet Ideas", "Small Living Room Decor Ideas Simple", "Decorating Small Living Room Ideas", "Small Uk Living Room Ideas", "Small Bar In Living Room Ideas", "Sofa Ideas Living Room Small Spaces", "Small Light Living Room Ideas", "Small Living Room Toy Storage Ideas", "Small Living Room Ideas Cozy Rustic", "Small Tv Wall Ideas Living Room", "Living Room Small Wall Decor Ideas", "Living Room Small Corner Ideas", "Small Living Room Ideas No Tv", "Small Living Room Wall Color Ideas", "Small Living Room Ideas Aesthetic", "Minecraft Small Living Room Ideas", "Small L Shaped Living Room Ideas", "Small Living Tv Room Ideas", "Small Living Room Shelving Ideas", "Small Victorian Living Room Ideas", "Small Living Room Boho Ideas", "Small Living Room Ideas Black Couch", "Small Loft Living Room Ideas", "Tv Unit Ideas For Small Living Room", "Uk Living Room Ideas Small Spaces", "Small Couch Living Room Ideas", "Small Alcove Ideas Living Room", "Small Living Room Ideas With Desk", "Small Living Room Ideas With Stairs", "Small Living Room Ideas Grey", "Small Room Living Room Ideas", "Sofas Ideas Small Living Room", "Small Living Room Makeover Ideas", "Small Living Room Space-Saving Ideas", "Small Living Room Colour Ideas", "Small Table Ideas Living Room", "Bookshelf Living Room Ideas Small Spaces", "Small Family Living Room Ideas", "Small Living Room Ideas Apartment Boho", "Living Room Condo Ideas Small Spaces", "Small Living Room Seating Ideas Layout", "Small Living Room Window Ideas", "Small Living Room Bar Ideas", "Small Living Room Ideas Black", "Small Living Room Sectional Ideas Layout", "Small Living Room Wall Color Ideas", "Corner Living Room Ideas Small Spaces", "Living Room Paint Color Ideas With Accent Wall Small Spaces", "Small Living Room Dining Room Ideas", "Corner Sofas Ideas Living Room Small Spaces", "Office In Living Room Ideas Small Spaces", "Studio Living Room Ideas Small Spaces", "Small Living Room With Recliners Ideas", "Aesthetic Small Living Room Ideas", "Small Studio Living Room Ideas", "Small Living Room Wall Ideas", "Small Living Dining Room Ideas Layout", "Toca Boca Small Living Room Ideas", "Small Living Room Ideas Open Concept", "Small Living Room And Dining Room Ideas", "Mini Bar Ideas Small Spaces Living Room", "Second Living Room Ideas Small Spaces", "Home Decor Ideas Small Living Room", "Small Living Room Ideas Boho", "Small Living Room Ideas Grey Couch", "Small Living Room Arrangement Ideas", "Small Entryway Ideas In Living Room", "Small Home Living Room Ideas", "Small Living Room Ideas Apartment Budget", "Small Living Room Ideas Apartment Modern", "Small Living Room Decor Ideas Cozy", "Sofa Set Ideas For Small Living Room", "Small Living Room Paint Ideas", "Wall Mirror Ideas Living Room Small Spaces", "Small Living Room Curtains Ideas", "Scandinavian Small Living Room Ideas", "Small Living Room Ideas Apartment Layout", "Small Living Room Ideas Farmhouse", "Small Space Living Room Ideas Layout", "Alcove Ideas Living Room Small Spaces", "Small Living Room With Tv Ideas", "Elegant Small Living Room Ideas", "Small Nook Ideas Living Room", "Ikea Small Living Room Ideas", "Super Small Living Room Ideas", "Small Living Room Decorating Ideas Apartment", "Cute Small Living Room Ideas", "Small Basement Living Room Ideas", "Rustic Small Living Room Ideas", "Small Dark Living Room Ideas", "Living Room Divider Ideas Small Spaces", "Small Living Room Table Ideas", "Small Kitchen And Living Room Ideas", "Small Living Room Storage Ideas", "Simple Small Living Room Ideas", "Minimalist Small Living Room Ideas", "Small Long Living Room Ideas", "Living Room Ideas Small Spaces", "Tiny Living Room Ideas Small Apartments", "Small Living Room With Kitchen Ideas", "Small Cottage Living Room Ideas", "Small Living Room Seating Ideas", "Small Living Room Lighting Ideas", "Small Formal Living Room Ideas", "Small Open Kitchen And Living Room Ideas", "Small Living Room Furniture Ideas", "Small Living Room Color Ideas", "Living Room Chairs Ideas Small Spaces", "Small Cozy Living Room Ideas", "Small Bay Window Ideas Living Room", "Small Narrow Living Room Ideas", "Small Living Room Tv Wall Ideas", "Small Cosy Living Room Ideas", "Living Room Ideas For Small Spaces", "Tv Room Ideas Cozy Small Living", "Small Living Room Couch Ideas", "Sofa Ideas For Small Living Room", "Small Simple Living Room Ideas", "Small Living Room Wall Decor Ideas", "Cozy Living Room Ideas For Small Spaces", "Small Living Room Decorating Ideas", "Small House Living Room Ideas", "Small Wash Basin Ideas In Living Room", "Small Dining And Living Room Combo Ideas", "Mini Living Room Ideas Small Spaces", "Cozy Small Living Room Ideas", "Small Living Room Ideas Layout", "Small Living Room Decor Ideas", "Small Living And Dining Room Ideas", "Extremely Small Living Room Ideas", "Small Living Room Ideas With Dining Area", "Small Living Room Ideas Cozy", "Small Space Living Room Ideas", "Small Living Room Ideas Apartment Cozy"
    ],
    [BOARD_IDS.FIREPLACE_MANTLE_DECOR]: [
        "Fireplace Decor Mantle", "Wedding Fireplace Mantle Decor", "Tv Fireplace Mantle Decor", "Red Brick Fireplace Mantle Decor", "Fireplace No Mantle Decor", "Decor For Fireplace Mantle With Tv", "Deep Fireplace Mantle Decor", "Wedding Fireplace Mantle Decor", "Kitchen Fireplace Mantle Decor", "Fall Fireplace Mantle Decor", "Fireplace Mantle Fall Decor Ideas", "Fireplace Decor No Mantle", "White Fireplace Mantle Decor", "Tall Fireplace Mantle Decor", "French Country Fireplace Mantle Decor", "Corner Fireplace Mantle Decor", "Fireplace Mantle Decor With Tv Above", "Fireplace Mantle With Tv Decor", "Fireplace Mantle Christmas Decor", "Fireplace Mantle Decor Ideas Everyday", "Stone Fireplace Mantle Decor", "Brick Fireplace Mantle Decor", "Long Fireplace Mantle Decor", "Decor For Fireplace Mantle", "Modern Fireplace Mantle Decor", "Fireplace Mantle Decor With Clock", "January Fireplace Decor Mantle Ideas", "Christmas Fireplace Mantle Decor", "Fireplace Mantle Decor With Pictures", "Fireplace Mantle Decor With Tv Modern", "Fireplace Mantle With Tv Decor Ideas", "Fireplace Mantle Decor Simple", "Fireplace Mantle Decor With Family Photo", "Fireplace Mantle Decor Under Tv", "Rock Fireplace Mantle Decor", "Fireplace Mantle Decor Boho", "Brick Fireplace Mantle Decor Ideas", "Fireplace Mantle Decor Wedding", "Fireplace Mantle Decor Mirror", "Moody Fireplace Mantle Decor", "Eclectic Fireplace Mantle Decor", "Fireplace Valentine Decor Mantle Ideas", "Coastal Fireplace Mantle Decor", "Fireplace Decor Without Mantle", "Fireplace Mantle Halloween Decor", "Fireplace Mantle Decor Minimalist", "Halloween Fireplace Mantle Decor", "BoHo Fireplace Mantle Decor With Tv", "Corner Fireplace Mantle Decor Ideas", "Cabin Fireplace Mantle Decor", "Country Fireplace Mantle Decor", "Fireplace Mantle Decor Farmhouse Rustic", "Faux Fireplace Mantle Decor", "Wide Fireplace Mantle Decor", "Modern Boho Fireplace Mantle Decor", "Neutral Fireplace Mantle Decor"
    ],
    [BOARD_IDS.MUD_ROOM_LAYOUT]: [
        "Mud Room Layout Floor Plans", "Mud Room Entry Way", "Mud Room Plans", "Mud Room Hallway", "Mud Room Under Staircase", "Mud Room Entry Farmhouse", "Mud Room Corner", "Laundry Room Mud Room Combo Floor Plans", "Mud Room Addition Exterior Entrance", "Mud Room Entry Modern", "Mud Room Area", "Mobile Home Mud Room Addition", "Corner Mud Room Ideas", "Laundry Mud Room Layout", "Mud Room Under Stairs", "Mud Room Floor Plans Layout", "Mud Room Layout", "Narrow Mud Room", "Modern Mud Room Ideas", "Mud Room Addition Exterior", "Laundry Room Mud Room Combo Small Layout", "Mud Room Garage", "Laundry Mud Room Ideas Off Garage", "Mud Room Laundry Room Combo Layout", "Mud Room Entry"
    ],
    [BOARD_IDS.MUD_ROOM_STORAGE]: [
        "Mud Room Benches", "Mud Room Cubby", "Mud Room Shoe Storage Ideas Entry Ways", "Mud Room Bench Ideas", "Mud Room Baskets", "Mud Room Shelves", "Coat Hook Ideas", "Ikea Mud Room Storage Cabinets", "Diy Mud Room Storage Ideas", "Mud Room Cabinet Storage", "Mud Room Closet Shoe Storage", "Diy Mud Room Bench", "Mud Room Coat And Shoe Storage", "Mud Room Hooks And Shelf", "Mud Room Closet Ideas", "Mud Room Storage Diy Plans", "Diy Mud Room Coat Rack", "Mud Room Cubby Storage Ideas", "Mud Room Shoes Storage Ideas", "Mud Room Storage"
    ],
    [BOARD_IDS.MUD_ROOM_PETS]: [
        "Mud Room Dog Kennel", "Mud Room Dog Feeding Station", "Mud Room With Dog Bath", "Mud Room With Dog Kennel", "Dog Mud Room Ideas Entryway", "Mud Room With Dog Bath And Laundry", "Mud Room Dog Wash Station", "Dog Mud Room Ideas"
    ],
    [BOARD_IDS.MUD_ROOM_DECOR]: [
        "Mud Room Rugs", "Mud Room Accent Wall", "Mud Room With Wallpaper", "Mud Room Mirror", "Mud Room Green", "Mud Room Colors Scheme", "Mud Room Aesthetic", "Mud Room Lighting Ideas", "Green Mud Room Ideas", "Mud Room Flooring Ideas Tile", "Mud Room Wallpaper Ideas", "Mud Room Wall Ideas", "Mud Room Wall Decor", "Mud Room Colors", "Mud Room Sink", "Mud Room Wall", "Mud Room Lighting", "Mud Room Color Ideas", "Mud Room Paint Colors"
    ],
    [BOARD_IDS.MUD_ROOM]: [
        "Mud Room Rugs", "Mud Room Layout Floor Plans", "Laundry Room Mud Room Ideas", "Mud Room Benches", "Farm House Mud Room", "Mud Room Sink Ideas", "Mud Room Accent Wall", "Mud Room Cubby", "Rustic Mud Room Ideas", "Mud Room Entry Way", "Mud Room Ideas Laundry", "Mud Room Shoe Storage Ideas Entry Ways", "Mud Room Bathroom Combo", "Mud Room With Wallpaper", "Mud Room Dog Kennel", "Mud Room Kitchen Combo", "Mud Room Mirror", "Mud Room Makeover", "Mud Room Dog Feeding Station", "Mud Room Bench Ideas", "Mud Room Baskets", "Toca Boca Mud Room", "Mud Room Desk", "Farmhouse Mud Room Laundry Room Combo", "Mud Room Ideas With Laundry", "Mud Room Green", "Mud Room Colors Scheme", "Mud Room Shelves", "Mud Room Plans", "Mini Mud Room Ideas", "Mud Room With Dog Bath", "Mud Room Coat Hook Ideas", "Ikea Mud Room Storage Cabinets", "Mud Room Aesthetic", "Mud Room With Dog Kennel", "Mud Room Diy Ideas", "Mud Room Designs Ideas", "Utility Mud Room Ideas", "Diy Mud Room Storage Ideas", "Mud Room Hallway", "Mud Room Under Staircase", "Mud Room Entry Farmhouse", "Mud Room Corner", "Mud Room Cabinet Storage", "Dog Mud Room Ideas Entryway", "Mud Room Dining Room Combo", "Mud Room Lighting Ideas", "Mud Room Makeover Small Spaces", "Narrow Mud Room Ideas Entryway", "Laundry Room Mud Room Combo Floor Plans", "Mud Room Addition Exterior Entrance", "Green Mud Room Ideas", "Mud Room Closet Shoe Storage", "Tiny Mud Room Ideas Entryway", "Garage Mud Room Ideas", "Diy Mud Room Bench", "Mud Room Coat And Shoe Storage", "Mud Room Entry Modern", "Mud Room Area", "Mud Room Flooring Ideas Tile", "Mud Room Hooks And Shelf", "Mobile Home Mud Room Addition", "Mud And Laundry Room", "Cabin Mud Room", "Kids Mud Room", "Mud Room Board And Batten", "Mud Room With Laundry And Bathroom", "Mud Room Wallpaper Ideas", "Mud Room Closet Ideas", "Mud Room With Desk", "Corner Mud Room Ideas", "Mud Room Inspiration", "Laundry Mud Room Layout", "Laundry Room And Mud Room", "Mud Room Under Stairs", "Mud Room Floor Plans Layout", "Small Mud Room Ideas Entryway Laundry", "Mid Century Mud Room", "Mud Room Storage Diy Plans", "Beach House Mud Room", "Mud Room Decor Ideas", "Mud Room Ideas Small Entryway", "Mud Room Wall Ideas", "Diy Mud Room Coat Rack", "Mud Room Laundry Room Combo", "Small Laundry Mud Room", "Large Mud Room Ideas", "Laundry And Mud Room Ideas", "Mud Room And Pantry Combo", "Mud Room Decor Entry Ways", "Mud Room Walls", "Mud Room Layout", "Moody Mud Room", "Outdoor Mud Room", "Mud Room Hook Wall", "Narrow Mud Room", "Mud Room Nook", "Diy Mud Room Small Space", "Tiny Mud Room", "Mud Room Laundry Room Combo Entry Ways", "Mud Room Storage Ideas", "Blue Mud Room", "Mud Room Wall Decor", "Mud Room Colors", "Mud And Laundry Room Combo", "Modern Mud Room Ideas", "Mud Room Coat Rack Ideas", "Mud Room Addition Exterior", "Laundry Room Mud Room", "Mud Room Sink", "Mud Room Drop Zone", "Laundry Room Mud Room Combo Small Layout", "Mud Room Organization", "Mud Room Garage", "Mud Room Bench With Storage Farmhouse", "Black Mud Room", "Laundry Mud Room Ideas Off Garage", "Mud Room Closet Conversion", "Mud Room Floor", "Large Mud Room", "Mud Room Laundry Room Combo Layout", "Mud Room Organization Tips", "Farmhouse Mud Room", "Mud Laundry Room Combo", "Mud Room Cubby Storage Ideas", "Mud Room With Dog Bath And Laundry", "Mud Room Ideas Bloxburg", "Mud Room Design", "Mud Room Wall", "Mud Room Lighting", "Modern Mud Room", "Mud Room Ideas Entryway Laundry", "Mud Room Color Ideas", "Mud Room Office Combo", "Mud Room Paint Colors", "Mud Room Bloxburg", "Mud Room Pantry Combo", "Small Mud Room Ideas Entryway Garage", "Small Mudroom Ideas Entryway", "Mud Room Dog Wash Station", "Mud Room Entrance", "Mud Room Floor Ideas", "Mud Room Tile Floor", "Entry Way Mud Room Ideas", "Laundry And Mud Room Combo", "Mud Room Cabinets Ideas", "Mud Room Decor", "Laundry Mud Room Ideas", "Dog Mud Room Ideas", "Mud Room Shoes Storage Ideas", "Mud Room Ideas Entryway Entrance", "Mud Room Storage", "Mud Room Ideas Entryway", "Mud Room Entry"
    ],
    [BOARD_IDS.MASTER_BED_VIBE]: [
        "Cozy Master Bedrooms Decor Relaxing", "Master Bedrooms Decor Romantic Relaxing", "Serene Master Bedrooms Decor", "Masculine Master Bedrooms Decor", "Master Bedrooms Decor Romantic Luxe", "Tranquil Master Bedrooms Decor", "Large Master Bedrooms Decor Cozy Relaxing", "Warm Master Bedrooms Decor", "Peaceful Master Bedrooms Decor", "Small Master Bedrooms Decor Cozy", "Relaxing Master Bedrooms Decor", "Moody Master Bedrooms Decor Cozy", "Calming Master Bedrooms Decor", "Dark Master Bedrooms Decor Cozy"
    ],
    [BOARD_IDS.MASTER_BED_STYLE]: [
        "Southern Master Bedrooms Decor", "Master Bedrooms Decor Minimalist", "Scandinavian Master Bedrooms Decor", "Modern Farmhouse Master Bedrooms Decor", "Mcm Master Bedrooms Decor", "Industrial Master Bedrooms Decor", "Loft Master Bedrooms Decor", "Cottage Core Master Bedrooms Decor", "Neutral Master Bedrooms Decor", "Hotel Master Bedrooms Decor", "Organic Modern Master Bedrooms Decor", "Victorian Master Bedrooms Decor", "Japanese Master Bedrooms Decor", "Japandi Master Bedrooms Decor", "Country Master Bedrooms Decor", "Western Master Bedrooms Decor", "Beachy Master Bedrooms Decor", "Coastal Master Bedrooms Decor", "Mediterranean Master Bedrooms Decor", "Boho Master Bedrooms Decor Cozy"
    ],
    [BOARD_IDS.MASTER_BED_COLOR]: [
        "Yellow Master Bedrooms Decor", "Emerald Green Master Bedrooms Decor", "Master Bedrooms Decor Grey", "Master Bedrooms Decor Colorful", "Colourful Master Bedrooms Decor", "Earth Tone Master Bedrooms Decor", "Mauve Master Bedrooms Decor", "Blue Master Bedrooms Decor Farmhouse", "Burgundy Master Bedrooms Decor", "Light Green Master Bedrooms Decor", "Green Wall Master Bedrooms Decor", "Master Bedrooms Decor Navy", "Blue And Green Master Bedrooms Decor", "Green Master Bedrooms Decor Cozy", "Teal Master Bedrooms Decor", "Blue Master Bedrooms Decor Cozy", "Dark Blue Master Bedrooms Decor", "Olive Green Master Bedrooms Decor", "Navy Blue Master Bedrooms Decor", "Light Blue Master Bedrooms Decor", "Gray Master Bedrooms Decor", "Purple Master Bedrooms Decor"
    ],
    [BOARD_IDS.MASTER_BED_FEATURES]: [
        "Master Bedrooms Decor Dark Furniture", "Master Bedrooms Decor Dark Wood Furniture", "Master Bedrooms Decor Wallpaper", "Carpet Master Bedrooms Decor", "Master Bedrooms Decor Grey Bed", "Taupe Master Bedrooms Decor", "Luxury Master Bedrooms Decor Elegant", "Ralph Lauren Master Bedrooms Decor", "Master Bedrooms Decor With Tv", "King Master Bedrooms Decor", "Post Bed Decor Master Bedrooms", "Tv In Master Bedrooms Decor", "Wall Behind Bed Decor Ideas Master Bedrooms", "Wallpaper Master Bedrooms Decor", "Main Room Decor Master Bedrooms"
    ],
    [BOARD_IDS.MASTER_BEDROOMS_DECOR]: [
        "Cozy Master Bedrooms Decor Relaxing", "Master Bedrooms Decor Romantic Relaxing", "Serene Master Bedrooms Decor", "Masculine Master Bedrooms Decor", "Master Bedrooms Decor Romantic Luxe", "Tranquil Master Bedrooms Decor", "Large Master Bedrooms Decor Cozy Relaxing", "Warm Master Bedrooms Decor", "Peaceful Master Bedrooms Decor", "Small Master Bedrooms Decor Cozy", "Relaxing Master Bedrooms Decor", "Moody Master Bedrooms Decor Cozy", "Calming Master Bedrooms Decor", "Dark Master Bedrooms Decor Cozy",
        "Southern Master Bedrooms Decor", "Master Bedrooms Decor Minimalist", "Scandinavian Master Bedrooms Decor", "Modern Farmhouse Master Bedrooms Decor", "Mcm Master Bedrooms Decor", "Industrial Master Bedrooms Decor", "Loft Master Bedrooms Decor", "Cottage Core Master Bedrooms Decor", "Neutral Master Bedrooms Decor", "Hotel Master Bedrooms Decor", "Organic Modern Master Bedrooms Decor", "Victorian Master Bedrooms Decor", "Japanese Master Bedrooms Decor", "Japandi Master Bedrooms Decor", "Country Master Bedrooms Decor", "Western Master Bedrooms Decor", "Beachy Master Bedrooms Decor", "Coastal Master Bedrooms Decor", "Mediterranean Master Bedrooms Decor", "Boho Master Bedrooms Decor Cozy",
        "Yellow Master Bedrooms Decor", "Emerald Green Master Bedrooms Decor", "Master Bedrooms Decor Grey", "Master Bedrooms Decor Colorful", "Colourful Master Bedrooms Decor", "Earth Tone Master Bedrooms Decor", "Mauve Master Bedrooms Decor", "Blue Master Bedrooms Decor Farmhouse", "Burgundy Master Bedrooms Decor", "Light Green Master Bedrooms Decor", "Green Wall Master Bedrooms Decor", "Master Bedrooms Decor Navy", "Blue And Green Master Bedrooms Decor", "Green Master Bedrooms Decor Cozy", "Teal Master Bedrooms Decor", "Blue Master Bedrooms Decor Cozy", "Dark Blue Master Bedrooms Decor", "Olive Green Master Bedrooms Decor", "Navy Blue Master Bedrooms Decor", "Light Blue Master Bedrooms Decor", "Gray Master Bedrooms Decor", "Purple Master Bedrooms Decor",
        "Master Bedrooms Decor Dark Furniture", "Master Bedrooms Decor Dark Wood Furniture", "Master Bedrooms Decor Wallpaper", "Carpet Master Bedrooms Decor", "Master Bedrooms Decor Grey Bed", "Taupe Master Bedrooms Decor", "Luxury Master Bedrooms Decor Elegant", "Ralph Lauren Master Bedrooms Decor", "Master Bedrooms Decor With Tv", "King Master Bedrooms Decor", "Post Bed Decor Master Bedrooms", "Tv In Master Bedrooms Decor", "Wall Behind Bed Decor Ideas Master Bedrooms", "Wallpaper Master Bedrooms Decor", "Main Room Decor Master Bedrooms"
    ],
    [BOARD_IDS.MUDROOM_IDEA_LAYOUT]: [
        "Entry Mudroom Ideas", "Entryway Mudroom Ideas", "Front Entrance Mudroom Ideas", "Mudroom Entrance", "Mudroom Ideas Entryway", "Entry Way Mudroom Ideas", "Small Mudroom Ideas Entryway", "Tiny Mudroom Ideas Entryway", "Narrow Mudroom Ideas Entryway", "L Shaped Mudroom Ideas", "Corner Mudroom Ideas", "Mudroom Nook Ideas", "Garage Mudroom Ideas", "Mudroom Garage", "Mudroom Ideas Garage", "Basement Mudroom Ideas"
    ],
    [BOARD_IDS.MUDROOM_IDEA_STORAGE]: [
        "Mudroom Storage Ideas", "Mudroom Bench Ideas", "Mudroom Shoe Storage Ideas", "Mudroom Closet Ideas", "Mudroom Locker Ideas", "Mudroom Locker Storage Ideas", "Mudroom Cubby Ideas", "Mudroom Cabinet Ideas", "Mudroom Hook Ideas", "Mudroom Drop Zone Ideas", "Mudroom Organization Ideas", "Diy Mudroom Storage Ideas", "Mudroom Closet Shoe Storage", "Mudroom Benches", "Mudroom Baskets", "Mudroom Shelves", "Mudroom Hooks And Shelf"
    ],
    [BOARD_IDS.MUDROOM_IDEA_STYLE]: [
        "Modern Mudroom Ideas", "Modern Mudroom Ideas Entryway", "Farmhouse Mudroom Ideas Entryway", "Rustic Mudroom Ideas", "Rustic Mudroom Ideas Entryway", "Moody Mudroom Ideas", "Cosy Mudroom Ideas", "Aesthetic Mudroom Ideas", "Green Mudroom Ideas", "Blue Mudroom Ideas", "Black Mudroom Ideas", "Mudroom Paint Color Ideas", "Mudroom Color Ideas", "Wallpaper Mudroom Ideas", "Mudroom Wallpaper Ideas", "Mudroom Tile Ideas", "Mudroom Flooring Ideas", "Mudroom Design Ideas"
    ],
    [BOARD_IDS.MUDROOM_IDEA_SETTING]: [
        "Mudroom Laundry Room Ideas", "Mudroom Ideas Laundry", "Mudroom Room Ideas", "Laundry Room Mudroom Ideas", "Laundry Mudroom Ideas", "Laundryroom Mudroom Ideas", "Small Mudroom Laundry Room Ideas", "Mudroom Ideas Entryway Laundry", "Mudroom Sink Ideas", "Mudroom With Dog Bath", "Dog Mudroom Ideas", "Mudroom Office Combo", "Mudroom Pantry Combo", "Mudroom Kitchen Combo", "Mudroom Bathroom Combo"
    ],
    [BOARD_IDS.MUDROOM_IDEA]: [
        "Entry Mudroom Ideas", "Entryway Mudroom Ideas", "Front Entrance Mudroom Ideas", "Mudroom Entrance", "Mudroom Ideas Entryway", "Entry Way Mudroom Ideas", "Small Mudroom Ideas Entryway", "Tiny Mudroom Ideas Entryway", "Narrow Mudroom Ideas Entryway", "L Shaped Mudroom Ideas", "Corner Mudroom Ideas", "Mudroom Nook Ideas", "Garage Mudroom Ideas", "Mudroom Garage", "Mudroom Ideas Garage", "Basement Mudroom Ideas",
        "Mudroom Storage Ideas", "Mudroom Bench Ideas", "Mudroom Shoe Storage Ideas", "Mudroom Closet Ideas", "Mudroom Locker Ideas", "Mudroom Locker Storage Ideas", "Mudroom Cubby Ideas", "Mudroom Cabinet Ideas", "Mudroom Hook Ideas", "Mudroom Drop Zone Ideas", "Mudroom Organization Ideas", "Diy Mudroom Storage Ideas", "Mudroom Closet Shoe Storage", "Mudroom Benches", "Mudroom Baskets", "Mudroom Shelves", "Mudroom Hooks And Shelf",
        "Modern Mudroom Ideas", "Modern Mudroom Ideas Entryway", "Farmhouse Mudroom Ideas Entryway", "Rustic Mudroom Ideas", "Rustic Mudroom Ideas Entryway", "Moody Mudroom Ideas", "Cosy Mudroom Ideas", "Aesthetic Mudroom Ideas", "Green Mudroom Ideas", "Blue Mudroom Ideas", "Black Mudroom Ideas", "Mudroom Paint Color Ideas", "Mudroom Color Ideas", "Wallpaper Mudroom Ideas", "Mudroom Wallpaper Ideas", "Mudroom Tile Ideas", "Mudroom Flooring Ideas", "Mudroom Design Ideas",
        "Mudroom Laundry Room Ideas", "Mudroom Ideas Laundry", "Mudroom Room Ideas", "Laundry Room Mudroom Ideas", "Laundry Mudroom Ideas", "Laundryroom Mudroom Ideas", "Small Mudroom Laundry Room Ideas", "Mudroom Ideas Entryway Laundry", "Mudroom Sink Ideas", "Mudroom With Dog Bath", "Dog Mudroom Ideas", "Mudroom Office Combo", "Mudroom Pantry Combo", "Mudroom Kitchen Combo", "Mudroom Bathroom Combo"
    ],
    [BOARD_IDS.COVERED_PATIO_LAYOUT]: [
        "Covered Patio Ideas For Back Of House", "Back Of House Covered Patio Ideas", "Covered Front Patio Ideas", "Backyard Covered Patio Ideas", "Small Covered Patio Ideas", "Narrow Covered Patio Ideas", "Large Covered Patio Ideas", "Modern Covered Patio Extension Ideas", "Attached Covered Patio Ideas", "Freestanding Covered Patio Ideas", "Back Porch Covered Patio Ideas", "Deck Covered Patio Ideas", "Pool Side Covered Patio Ideas", "Corner Covered Patio Ideas"
    ],
    [BOARD_IDS.COVERED_PATIO_FEATURES]: [
        "Covered Patio Ideas With Fireplace", "Covered Patio Ideas With Fire Pit", "Covered Patio Ideas With Outdoor Kitchen", "Outdoor Kitchen Covered Patio Ideas", "Covered Patio Ideas With Fans", "Covered Patio Ideas With Curtains", "Covered Patio Lighting Ideas", "Covered Patio Ceiling Ideas", "Covered Patio Roof Ideas", "Retractable Covered Patio Ideas", "Covered Patio Ideas With Bar", "Covered Patio Ideas With Tv", "Screened In Covered Patio Ideas", "Glass Covered Patio Ideas", "Covered Patio Ideas With Hot Tub"
    ],
    [BOARD_IDS.COVERED_PATIO_DECOR]: [
        "Covered Patio Decorating Ideas", "Covered Patio Furniture Ideas", "Boho Covered Patio Ideas", "Modern Covered Patio Ideas", "Farmhouse Covered Patio Ideas", "Rustic Covered Patio Ideas", "Cozy Covered Patio Ideas", "Covered Patio Rug Ideas", "Covered Patio Flooring Ideas", "Covered Patio Wall Decor Ideas", "Luxury Covered Patio Ideas", "Simple Covered Patio Ideas", "Cheap Covered Patio Ideas On A Budget", "Diy Covered Patio Ideas"
    ],
    [BOARD_IDS.COVERED_PATIO_SIZE]: [
        "Small Covered Patio Ideas", "Very Small Covered Patio Ideas", "Large Covered Patio Ideas", "Covered Patio Ideas For Small Backyards", "Covered Patio Ideas For Large Backyards"
    ],
    [BOARD_IDS.COVERED_PATIO_IDEAS]: [
        "Covered Patio Ideas For Back Of House", "Back Of House Covered Patio Ideas", "Covered Front Patio Ideas", "Backyard Covered Patio Ideas", "Small Covered Patio Ideas", "Narrow Covered Patio Ideas", "Large Covered Patio Ideas", "Modern Covered Patio Extension Ideas", "Attached Covered Patio Ideas", "Freestanding Covered Patio Ideas", "Back Porch Covered Patio Ideas", "Deck Covered Patio Ideas", "Pool Side Covered Patio Ideas", "Corner Covered Patio Ideas",
        "Covered Patio Ideas With Fireplace", "Covered Patio Ideas With Fire Pit", "Covered Patio Ideas With Outdoor Kitchen", "Outdoor Kitchen Covered Patio Ideas", "Covered Patio Ideas With Fans", "Covered Patio Ideas With Curtains", "Covered Patio Lighting Ideas", "Covered Patio Ceiling Ideas", "Covered Patio Roof Ideas", "Retractable Covered Patio Ideas", "Covered Patio Ideas With Bar", "Covered Patio Ideas With Tv", "Screened In Covered Patio Ideas", "Glass Covered Patio Ideas", "Covered Patio Ideas With Hot Tub",
        "Covered Patio Decorating Ideas", "Covered Patio Furniture Ideas", "Boho Covered Patio Ideas", "Modern Covered Patio Ideas", "Farmhouse Covered Patio Ideas", "Rustic Covered Patio Ideas", "Cozy Covered Patio Ideas", "Covered Patio Rug Ideas", "Covered Patio Flooring Ideas", "Covered Patio Wall Decor Ideas", "Luxury Covered Patio Ideas", "Simple Covered Patio Ideas", "Cheap Covered Patio Ideas On A Budget", "Diy Covered Patio Ideas",
        "Small Covered Patio Ideas", "Very Small Covered Patio Ideas", "Large Covered Patio Ideas", "Covered Patio Ideas For Small Backyards", "Covered Patio Ideas For Large Backyards"
    ],
    [BOARD_IDS.CLOSET_ORG_SIZE]: [
        "Small Closet Organization Ideas Kids", "Bedroom Closet Organization Ideas Small Walk In", "Closet Organization Ideas Small Closet", "Narrow Closet Organization Ideas", "Walk In Closet Ideas Organization", "Big Closet Organization Ideas", "Small Coat Closet Organization Ideas", "Large Closet Organization Ideas", "Tiny Closet Organization Ideas Bedrooms", "Small Walkin Closet Organization Ideas", "Master Walk In Closet Organization Ideas", "Small Master Closet Organization Ideas", "Long Closet Organization Ideas", "Tiny Closet Organization Ideas Bedrooms", "Mini Closet Organization Ideas", "Walk In Closet Organization Ideas Layout", "Closet Organization Ideas Small Space", "Small Closet Ideas Organization", "Tiny Closet Organization Ideas", "Closet Organization Ideas Small Bedrooms", "Deep Closet Organization Ideas", "Walking Closet Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_FEATURES]: [
        "Closet Organization Ideas With Dresser", "Closet Organization Ideas Corner", "Closet Dresser Organization Ideas", "Closet Organization Ideas With Drawers", "Wired Closet Organization Ideas", "Wire Shelf Closet Organization Ideas", "Wire Rack Closet Organization Ideas", "Closet Top Shelf Organization Ideas", "Closet Drawer Organization Ideas", "Top Shelf Closet Organization Ideas", "Closet Island Organization Ideas", "Closet Door Organization Ideas", "Closet Organization Ideas Drawers", "Closet Organization Ideas Shelves", "Closet Shelf Organization Ideas", "Wall Closet Organization Ideas", "Closet Organization Ideas Sliding Door", "Closet Organization Ideas Corner", "Sliding Door Closet Organization Ideas", "Wire Closet Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_ITEMS]: [
        "Small Closet Shoe Organization Ideas", "Closet Organization Ideas Pants", "Closet Organization Ideas Jeans", "Tshirt Storage Ideas Closet Organization", "Closet Purse Organization Ideas", "Handbag Closet Organization Ideas", "Hoodie Organization Ideas Closet", "Closet Organization Ideas For Shoes", "Shoe Closet Organization Ideas", "Closet Bag Organization Ideas", "Clothes Closet Organization Ideas", "Closet Organization Ideas Clothes", "Closet Organization Ideas Shoes", "Towel Closet Organization Ideas", "Closet Tshirt Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_USER]: [
        "Closet Organization Ideas Kids Room", "Mens Closet Organization Ideas", "Shared Kids Closet Organization Ideas", "Closet Organization Ideas Women", "Shared Kids Closet Organization Ideas", "Closet Organization Ideas Nursery", "College Dorm Closet Organization Ideas", "Master Walk In Closet Organization Ideas", "Teen Closet Organization Ideas", "Women Closet Organization Ideas", "Kid Closet Organization Ideas", "Kids Small Closet Organization Ideas", "Nursery Closet Organization Ideas", "Baby Closet Organization Ideas", "Closet Organization Ideas Kids", "Boys Closet Organization Ideas", "Kids Closet Organization Ideas Diy", "Closet Organization Ideas Men", "Teen Closet Organization Ideas", "Toddler Closet Organization Ideas", "College Dorm Closet Organization Ideas", "Dorm Closet Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_STYLE]: [
        "Modern Closet Organization Ideas", "Farmhouse Closet Organization Ideas", "Rustic Closet Organization Ideas", "Vintage Closet Organization Ideas", "Minimalist Closet Organization Ideas", "Simple Closet Organization Ideas", "Simple Closet Organization Ideas", "Top Closet Organization Ideas", "Regular Closet Organization Ideas", "Ideas For Closet Organization", "Organization Ideas For Closet", "Organization Ideas For The Closet", "Organization Ideas Closet", "Closet Room Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_BUDGET]: [
        "Closet Organization Ideas Cheap", "Closet Organization Ideas On A Budget", "Affordable Closet Organization Ideas", "Cheap Closet Organization Ideas", "Closet Organization Ideas Rental", "Target Closet Organization Ideas", "Ikea Closet Organization Ideas", "Closet Organization Ideas Ikea"
    ],
    [BOARD_IDS.CLOSET_ORG_SPECIAL]: [
        "Art Closet Organization Ideas", "Game Closet Organization Ideas", "Closet Pantry Organization Ideas", "Craft Closet Organization Ideas Diy", "Craft Closet Organization Ideas", "Supply Closet Organization Ideas", "Cleaning Closet Organization Ideas", "Utility Closet Organization Ideas", "Storage Closet Organization Ideas", "Closet Storage Organization Ideas", "Linen Closet Organization Ideas Hallways", "Small Bathroom Closet Organization Ideas", "Closet Organization Ideas Bathroom", "Bathroom Closet Organization Ideas", "Kitchen Closet Organization Ideas", "Garage Closet Organization Ideas", "Laundry Closet Organization Ideas", "Hallway Closet Organization Ideas Front Entry", "Hall Closet Organization Ideas Entryway", "Hallway Closet Organization Ideas", "Hall Closet Organization Ideas Hallways", "Entryway Closet Organization Ideas", "Entry Closet Organization Ideas", "Mudroom Closet Organization Ideas", "Hall Closet Organization Ideas", "Coat Closet Organization Ideas", "Small Coat Closet Organization Ideas", "Office Closet Organization Ideas"
    ],
    [BOARD_IDS.CLOSET_ORG_METHODS]: [
        "Closet Organization Ideas Color Code", "Open Closet Organization Ideas", "Walking Closet Organization Ideas", "Diy Closet Organization Ideas", "Walk In Closet Organization Ideas Diy", "Shared Closet Organization Ideas", "Inside Closet Organization Ideas", "Organization Ideas For The Home Closet", "Line Closet Organization Ideas", "Regular Closet Organization Ideas", "Walk In Closet Organization Ideas Layout"
    ],
    [BOARD_IDS.CLOSET_ORGANIZATION_IDEAS]: [
        "Small Closet Organization Ideas Kids", "Bedroom Closet Organization Ideas Small Walk In", "Closet Organization Ideas Small Closet", "Narrow Closet Organization Ideas", "Walk In Closet Ideas Organization", "Big Closet Organization Ideas", "Small Coat Closet Organization Ideas", "Large Closet Organization Ideas", "Tiny Closet Organization Ideas Bedrooms", "Small Walkin Closet Organization Ideas", "Master Walk In Closet Organization Ideas", "Small Master Closet Organization Ideas", "Long Closet Organization Ideas", "Tiny Closet Organization Ideas Bedrooms", "Mini Closet Organization Ideas", "Walk In Closet Organization Ideas Layout", "Closet Organization Ideas Small Space", "Small Closet Ideas Organization", "Tiny Closet Organization Ideas", "Closet Organization Ideas Small Bedrooms", "Deep Closet Organization Ideas", "Walking Closet Organization Ideas",
        "Closet Organization Ideas With Dresser", "Closet Organization Ideas Corner", "Closet Dresser Organization Ideas", "Closet Organization Ideas With Drawers", "Wired Closet Organization Ideas", "Wire Shelf Closet Organization Ideas", "Wire Rack Closet Organization Ideas", "Closet Top Shelf Organization Ideas", "Closet Drawer Organization Ideas", "Top Shelf Closet Organization Ideas", "Closet Island Organization Ideas", "Closet Door Organization Ideas", "Closet Organization Ideas Drawers", "Closet Organization Ideas Shelves", "Closet Shelf Organization Ideas", "Wall Closet Organization Ideas", "Closet Organization Ideas Sliding Door", "Closet Organization Ideas Corner", "Sliding Door Closet Organization Ideas", "Wire Closet Organization Ideas",
        "Small Closet Shoe Organization Ideas", "Closet Organization Ideas Pants", "Closet Organization Ideas Jeans", "Tshirt Storage Ideas Closet Organization", "Closet Purse Organization Ideas", "Handbag Closet Organization Ideas", "Hoodie Organization Ideas Closet", "Closet Organization Ideas For Shoes", "Shoe Closet Organization Ideas", "Closet Bag Organization Ideas", "Clothes Closet Organization Ideas", "Closet Organization Ideas Clothes", "Closet Organization Ideas Shoes", "Towel Closet Organization Ideas", "Closet Tshirt Organization Ideas",
        "Closet Organization Ideas Kids Room", "Mens Closet Organization Ideas", "Shared Kids Closet Organization Ideas", "Closet Organization Ideas Women", "Shared Kids Closet Organization Ideas", "Closet Organization Ideas Nursery", "College Dorm Closet Organization Ideas", "Master Walk In Closet Organization Ideas", "Teen Closet Organization Ideas", "Women Closet Organization Ideas", "Kid Closet Organization Ideas", "Kids Small Closet Organization Ideas", "Nursery Closet Organization Ideas", "Baby Closet Organization Ideas", "Closet Organization Ideas Kids", "Boys Closet Organization Ideas", "Kids Closet Organization Ideas Diy", "Closet Organization Ideas Men", "Teen Closet Organization Ideas", "Toddler Closet Organization Ideas", "College Dorm Closet Organization Ideas", "Dorm Closet Organization Ideas",
        "Modern Closet Organization Ideas", "Farmhouse Closet Organization Ideas", "Rustic Closet Organization Ideas", "Vintage Closet Organization Ideas", "Minimalist Closet Organization Ideas", "Simple Closet Organization Ideas", "Simple Closet Organization Ideas", "Top Closet Organization Ideas", "Regular Closet Organization Ideas", "Ideas For Closet Organization", "Organization Ideas For Closet", "Organization Ideas For The Closet", "Organization Ideas Closet", "Closet Room Organization Ideas",
        "Closet Organization Ideas Cheap", "Closet Organization Ideas On A Budget", "Affordable Closet Organization Ideas", "Cheap Closet Organization Ideas", "Closet Organization Ideas Rental", "Target Closet Organization Ideas", "Ikea Closet Organization Ideas", "Closet Organization Ideas Ikea",
        "Art Closet Organization Ideas", "Game Closet Organization Ideas", "Closet Pantry Organization Ideas", "Craft Closet Organization Ideas Diy", "Craft Closet Organization Ideas", "Supply Closet Organization Ideas", "Cleaning Closet Organization Ideas", "Utility Closet Organization Ideas", "Storage Closet Organization Ideas", "Closet Storage Organization Ideas", "Linen Closet Organization Ideas Hallways", "Small Bathroom Closet Organization Ideas", "Closet Organization Ideas Bathroom", "Bathroom Closet Organization Ideas", "Kitchen Closet Organization Ideas", "Garage Closet Organization Ideas", "Laundry Closet Organization Ideas", "Hallway Closet Organization Ideas Front Entry", "Hall Closet Organization Ideas Entryway", "Hallway Closet Organization Ideas", "Hall Closet Organization Ideas Hallways", "Entryway Closet Organization Ideas", "Entry Closet Organization Ideas", "Mudroom Closet Organization Ideas", "Hall Closet Organization Ideas", "Coat Closet Organization Ideas", "Small Coat Closet Organization Ideas", "Office Closet Organization Ideas",
        "Closet Organization Ideas Color Code", "Open Closet Organization Ideas", "Walking Closet Organization Ideas", "Diy Closet Organization Ideas", "Walk In Closet Organization Ideas Diy", "Shared Closet Organization Ideas", "Inside Closet Organization Ideas", "Organization Ideas For The Home Closet", "Line Closet Organization Ideas", "Regular Closet Organization Ideas", "Walk In Closet Organization Ideas Layout"
    ],
    [BOARD_IDS.MODERN_TV_WALL_STYLE]: [
        "Luxury Modern Tv Wall Design", "Modern Minimalist Tv Wall Design", "Tv Wall Design Mid Century Modern", "Contemporary Tv Wall Design Modern", "Elegant Tv Wall Design Modern"
    ],
    [BOARD_IDS.MODERN_TV_WALL_FEATURE]: [
        "Modern Tv Feature Wall Design", "Modern Led Wall Design", "Wall Mount Tv Unit Design Modern", "Modern Tv Wall Panel Design Modern Living", "Wall Panelling Design Modern", "Modern Wall Moulding Design", "Wall Molding Design Modern", "Modern Wall Panelling Design Interiors"
    ],
    [BOARD_IDS.MODERN_TV_WALL_ROOM]: [
        "Tv Wall Design Modern Luxury Living Room", "Tv Wall Design Modern Master Bedrooms", "Tv Unit Design Modern Small Wall", "Lcd Wall Design Modern Bedroom", "Office Tv Wall Design Modern", "Drawing Room Wall Design Modern"
    ],
    [BOARD_IDS.MODERN_TV_WALL_DESIGN]: [
        "Tv Wall Design Modern Luxury Living Room", "Tv Wall Design Modern Master Bedrooms", "Tv Unit Design Modern Small Wall", "Lcd Wall Design Modern Bedroom", "Office Tv Wall Design Modern", "Drawing Room Wall Design Modern",
        "Modern Tv Feature Wall Design", "Modern Led Wall Design", "Wall Mount Tv Unit Design Modern", "Modern Tv Wall Panel Design Modern Living", "Wall Panelling Design Modern", "Modern Wall Moulding Design", "Wall Molding Design Modern", "Modern Wall Panelling Design Interiors",
        "Luxury Modern Tv Wall Design", "Modern Minimalist Tv Wall Design", "Tv Wall Design Mid Century Modern", "Contemporary Tv Wall Design Modern", "Elegant Tv Wall Design Modern",
        "Modern Media Wall Design Ideas", "Tv Wall Design Modern Luxury", "Media Wall Design Modern", "Tv Wall Modern Design", "Modern Wall Design Ideas", "Wall Design Modern"
    ],
    [BOARD_IDS.GIRLS_BED_THEME]: [
        "Rainbow Girls Bedroom Ideas", "Unicorn Girls Bedroom Ideas", "Mermaid Bedroom Ideas For Girls Kids", "Girls Princess Bedroom Ideas", "Girls Nature Bedroom Ideas", "Girls Flower Bedroom Ideas"
    ],
    [BOARD_IDS.GIRLS_BED_STYLE]: [
        "Boho Girls Bedroom Ideas", "Girls Bedroom Ideas Aesthetic", "Cute Girls Bedroom Ideas", "Cool Girls Bedroom Ideas", "Girls Bedroom Ideas Pink", "Girls Purple Bedroom Ideas", "Green Girls Bedroom Ideas"
    ],
    [BOARD_IDS.GIRLS_BED_USER]: [
        "Toddler Girls Bedroom Ideas", "Little Girls Bedroom Ideas", "Preteen Girls Bedroom Ideas Blue", "Girls shared Bedroom Ideas", "Two Girls Bedroom Ideas", "Girls Twin Bedroom Ideas"
    ],
    [BOARD_IDS.GIRLS_BED_STORAGE]: [
        "Girls Bedroom Storage Ideas", "Girls Bedroom Organization Ideas", "Girls Bedroom Desk Ideas", "Girls Bedroom Shelving Ideas"
    ],
    [BOARD_IDS.GIRLS_BEDROOM_IDEAS]: [
        "Rainbow Girls Bedroom Ideas", "Unicorn Girls Bedroom Ideas", "Mermaid Bedroom Ideas For Girls Kids", "Girls Princess Bedroom Ideas", "Girls Nature Bedroom Ideas", "Girls Flower Bedroom Ideas",
        "Boho Girls Bedroom Ideas", "Girls Bedroom Ideas Aesthetic", "Cute Girls Bedroom Ideas", "Cool Girls Bedroom Ideas", "Girls Bedroom Ideas Pink", "Girls Purple Bedroom Ideas", "Green Girls Bedroom Ideas",
        "Toddler Girls Bedroom Ideas", "Little Girls Bedroom Ideas", "Preteen Girls Bedroom Ideas Blue", "Girls shared Bedroom Ideas", "Two Girls Bedroom Ideas", "Girls Twin Bedroom Ideas",
        "Girls Bedroom Storage Ideas", "Girls Bedroom Organization Ideas", "Girls Bedroom Desk Ideas", "Girls Bedroom Shelving Ideas"
    ],
    [BOARD_IDS.FARMHOUSE_LR_WALL]: [
        "Rustic Farmhouse Wall Decor Living Room", "Boho Farmhouse Living Room Wall Decor", "Diy Farmhouse Wall Decor Living Room", "Living Room Wall Decor Ideas Above Couch Farmhouse", "Farmhouse Wall Decor Ideas Living Room", "Modern Farmhouse Living Room Wall Decor Ideas", "Country Farmhouse Wall Decor Living Room", "Farmhouse Decor Living Room Wall", "Wall Decor Living Room Farmhouse", "Living Room Farmhouse Wall Decor", "Farmhouse Clock Wall Decor Living Room", "Living Room Wall Decor Ideas Farmhouse"
    ],
    [BOARD_IDS.FARMHOUSE_LR_STYLE]: [
        "Farmhouse Modern Decor Living Room", "Living Room Decor Farmhouse Rustic", "Antique Farmhouse Decor Living Room", "Farmhouse Decor Small Living Room", "Farm Living Room Decor Farmhouse Style", "Teal Farmhouse Decor Living Room", "Coastal Farmhouse Living Room Decor", "Living Room Decor Boho Farmhouse", "French Country Farmhouse Decor Living Room", "Cottage Farmhouse Decor Living Room", "Farmhouse Antique Decor Living Room", "Colorful Farmhouse Decor Living Room", "Black Farmhouse Decor Living Room", "Farmhouse Chic Decor Living Room", "Boho Farmhouse Living Room Decor Ideas", "Farmhouse Home Decor Living Room", "Dark Farmhouse Decor Living Room", "Farmhouse Glam Decor Living Room", "Farmhouse Chic Living Room Decor Ideas", "Cozy Farmhouse Living Room Decor", "Rustic Living Room Decor Farmhouse Style", "Coastal Farmhouse Decor Living Room"
    ],
    [BOARD_IDS.FARMHOUSE_LR_FEAT]: [
        "Farmhouse Ladder Decor Living Room", "Farmhouse Living Room Fireplace Decor", "Modern Farmhouse Shelf Decor Living Room", "Cow Decor Farmhouse Style Living Room", "Spring Farmhouse Decor Living Room", "Farmhouse Tv Stand Decor Living Room", "Farmhouse Living Room Table Decor", "Side Table Decor Living Room Farmhouse", "Farmhouse Fall Decor Living Room"
    ],
    [BOARD_IDS.FARMHOUSE_DECOR_LIVING_ROOM]: [
        "Rustic Farmhouse Wall Decor Living Room", "Boho Farmhouse Living Room Wall Decor", "Diy Farmhouse Wall Decor Living Room", "Living Room Wall Decor Ideas Above Couch Farmhouse", "Farmhouse Wall Decor Ideas Living Room", "Modern Farmhouse Living Room Wall Decor Ideas", "Country Farmhouse Wall Decor Living Room", "Farmhouse Decor Living Room Wall", "Wall Decor Living Room Farmhouse", "Living Room Farmhouse Wall Decor", "Farmhouse Clock Wall Decor Living Room", "Living Room Wall Decor Ideas Farmhouse",
        "Farmhouse Modern Decor Living Room", "Living Room Decor Farmhouse Rustic", "Antique Farmhouse Decor Living Room", "Farmhouse Decor Small Living Room", "Farm Living Room Decor Farmhouse Style", "Teal Farmhouse Decor Living Room", "Coastal Farmhouse Living Room Decor", "Living Room Decor Boho Farmhouse", "French Country Farmhouse Decor Living Room", "Cottage Farmhouse Decor Living Room", "Farmhouse Antique Decor Living Room", "Colorful Farmhouse Decor Living Room", "Black Farmhouse Decor Living Room", "Farmhouse Chic Decor Living Room", "Boho Farmhouse Living Room Decor Ideas", "Farmhouse Home Decor Living Room", "Dark Farmhouse Decor Living Room", "Farmhouse Glam Decor Living Room", "Farmhouse Chic Living Room Decor Ideas", "Cozy Farmhouse Living Room Decor", "Rustic Living Room Decor Farmhouse Style", "Coastal Farmhouse Decor Living Room",
        "Farmhouse Ladder Decor Living Room", "Farmhouse Living Room Fireplace Decor", "Modern Farmhouse Shelf Decor Living Room", "Cow Decor Farmhouse Style Living Room", "Spring Farmhouse Decor Living Room", "Farmhouse Tv Stand Decor Living Room", "Farmhouse Living Room Table Decor", "Side Table Decor Living Room Farmhouse", "Farmhouse Fall Decor Living Room"
    ],
    [BOARD_IDS.BG_KITCHEN_FIXTURES]: [
        "Gold And Black Kitchen Faucet", "Gold And Black Kitchen Sink", "Black And Gold Kitchen Lighting", "Black And Gold Chandelier Kitchen", "Black And Gold Pendant Light Kitchen", "Black And Gold Pendant Lights Over Kitchen Island", "Black And Gold Light Fixture Kitchen"
    ],
    [BOARD_IDS.BG_KITCHEN_STYLE]: [
        "Black And Gold Kitchen Aesthetic", "Black And Gold Modern Kitchen", "Gold And Black Kitchen Ideas", "Modern Black And Gold Kitchen", "Elegant Black And Gold Kitchen", "Black And Gold Kitchen Decor Apartment", "Black And Gold Modern Kitchen Ideas"
    ],
    [BOARD_IDS.BG_KITCHEN_COLOR]: [
        "Gold White And Black Kitchen", "Beige Black And Gold Kitchen", "Black Brown And Gold Kitchen", "White Black And Gold Kitchen Ideas", "Black White And Gold Kitchen Decor Ideas", "Grey Black And Gold Kitchen", "Black Cream And Gold Kitchen", "Black And Gold Marble Kitchen"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_FEAT]: [
        "Small Backyard Walkway Ideas", "Backyard Paver Walkway Ideas", "Backyard Concrete Walkway Ideas", "Small Backyard Garden Ideas", "Backyard Garden Walkway Ideas"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_STYLE]: [
        "Modern Small Backyard Landscaping", "Boho Small Backyard Landscaping", "Farmhouse Small Backyard Landscaping", "Rustic Small Backyard Landscaping", "Minimalist Small Backyard Landscaping"
    ],
    [BOARD_IDS.SMALL_BY_LANDSCAPE_LAYOUT]: [
        "Small Backyard Landscaping Ideas Layout", "Small Zen Backyard Landscaping", "Small Backyard Layout Ideas"
    ],
    [BOARD_IDS.BED_WARDROBE_LAYOUT]: [
        "Bedroom Wardrobe Layout Ideas", "Small Bedroom Wardrobe Ideas", "Corner Bedroom Wardrobe Ideas", "Built In Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.BED_WARDROBE_USER]: [
        "Kids Bedroom Wardrobe Ideas", "Mens Bedroom Wardrobe Ideas", "Girls Bedroom Wardrobe Ideas", "Teen Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.BED_WARDROBE_STYLE]: [
        "Modern Bedroom Wardrobe Ideas", "Farmhouse Bedroom Wardrobe Ideas", "Simple Bedroom Wardrobe Ideas", "Aesthetic Bedroom Wardrobe Ideas"
    ],
    [BOARD_IDS.LIMEWASH_COLOR]: [
        "Limewash Wall Color Ideas", "Grey Limewash Walls", "Beige Limewash Walls", "White Limewash Walls", "Green Limewash Walls"
    ],
    [BOARD_IDS.LIMEWASH_ROOM]: [
        "Limewash Walls Bedroom", "Limewash Walls Living Room", "Limewash Walls Bathroom", "Limewash Walls Kitchen"
    ],
    [BOARD_IDS.LIMEWASH_STYLE]: [
        "Modern Limewash Walls", "Rustic Limewash Walls", "Minimalist Limewash Walls", "Aesthetic Limewash Walls"
    ],
    [BOARD_IDS.HOME_DECOR_LR_STYLE]: [
        "Modern Home Decor Living Room", "Boho Home Decor Living Room", "Farmhouse Home Decor Living Room", "Rustic Home Decor Living Room"
    ],
    [BOARD_IDS.HOME_DECOR_LR_FEATURES]: [
        "Home Decor Living Room Wall Art", "Home Decor Living Room Shelving", "Home Decor Living Room Lighting", "Home Decor Living Room Rugs"
    ],
    [BOARD_IDS.HOME_DECOR_LR_BUDGET]: [
        "Home Decor Living Room Budget Friendly", "Cheap Home Decor Living Room", "Diy Home Decor Living Room"
    ],
    [BOARD_IDS.COFFEE_TABLE_VIBE]: [
        "Cozy Coffee Table Decor", "Minimalist Coffee Table Decor", "Aesthetic Coffee Table Decor", "Modern Coffee Table Decor"
    ],
    [BOARD_IDS.COFFEE_TABLE_SEASON]: [
        "Fall Coffee Table Decor", "Spring Coffee Table Decor", "Summer Coffee Table Decor", "Winter Coffee Table Decor", "Christmas Coffee Table Decor"
    ],
    [BOARD_IDS.COFFEE_TABLE_ELEMENTS]: [
        "Coffee Table Books Decor", "Coffee Table Tray Decor", "Coffee Table Candle Decor", "Coffee Table Flowers Decor"
    ],
    [BOARD_IDS.BA_WALLPAPER_STYLE]: [
        "Modern Bathroom Wallpaper Ideas", "Floral Wallpaper Bathroom Ideas", "Vintage Wallpaper Bathroom Ideas", "Textured Wallpaper Bathroom Ideas", "Moody Bathroom Ideas Wallpaper"
    ],
    [BOARD_IDS.BA_WALLPAPER_COLOR]: [
        "Blue Bathroom Wallpaper Ideas", "Green Wallpaper Bathroom Ideas", "Pink Wallpaper Bathroom Ideas", "Black Wallpaper Bathroom Ideas"
    ],
    [BOARD_IDS.BA_WALLPAPER_ROOM]: [
        "Small Half Bathroom Wallpaper Ideas", "Small Guest Bathroom Wallpaper Ideas", "Kids Bathroom Wallpaper Ideas", "Small Bathroom With Wallpaper Ideas"
    ],
    [BOARD_IDS.FIREPLACE_MANTLE_STYLE]: [
        "Modern Fireplace Mantle Decor", "French Country Fireplace Mantle Decor", "Moody Fireplace Mantle Decor", "Eclectic Fireplace Mantle Decor", "Coastal Fireplace Mantle Decor", "Fireplace Mantle Decor Simple"
    ],
    [BOARD_IDS.FIREPLACE_MANTLE_HOLIDAY]: [
        "Fireplace Mantle Christmas Decor", "Fall Fireplace Mantle Decor", "Fireplace Mantle Halloween Decor", "January Fireplace Decor Mantle Ideas", "Fireplace Valentine Decor Mantle Ideas"
    ],
    [BOARD_IDS.FIREPLACE_MANTLE_FEATURE]: [
        "Fireplace Mantle Decor With Tv Modern", "Fireplace Mantle Decor Mirror", "Fireplace Mantle Decor With Family Photo", "Fireplace Mantle Decor With Clock"
    ],
    [BOARD_IDS.COFFEE_BAR_STYLE]: [
        "Modern Coffee Bar Ideas", "Farmhouse Coffee Bar Ideas", "White Coffee Bar Ideas", "Glam Coffee Bar Ideas", "Rustic Coffee Bar Ideas", "Boho Coffee Bar Ideas", "Antique Coffee Bar Ideas", "Aesthetic Coffee Bar Ideas", "Bohemian Coffee Bar Ideas", "Cute Coffee Bar Ideas", "Pink Coffee Bar Ideas"
    ],
    [BOARD_IDS.COFFEE_BAR_ROOM]: [
        "Coffee Bar Ideas Kitchen", "Coffee Bar In Living Room Ideas", "Coffee Bar Ideas Bedroom", "Coffee Bar Ideas Office", "Coffee Bar At Home Ideas", "Coffee Bar In Dining Room Ideas", "Salon Coffee Bar Ideas", "School Coffee Bar Ideas", "Rv Coffee Bar Ideas"
    ],
    [BOARD_IDS.COFFEE_BAR_SETUP]: [
        "Coffee Bar Station Ideas", "Coffee Bar Cart Ideas", "Coffee Bar Cabinet Ideas", "Coffee Bar Countertop Ideas", "Coffee Bar Nook Ideas", "Coffee Bar Armoire Ideas", "Coffee Bar Hutch Ideas", "Coffee Bar Buffet Ideas", "Pantry Coffee Bar Ideas", "Closet Coffee Bar Ideas", "Coffee Bar Shelves Ideas", "Coffee Bar Wall Ideas", "Coffee Bar Backsplash Ideas", "Coffee Bar Sink Ideas", "Coffee Bar Sign Ideas", "Coffee Bar Logo Design Ideas", "Coffee Bar Menu Ideas"
    ],
    [BOARD_IDS.COFFEE_BAR_SIZE]: [
        "Small Coffee Bar Ideas", "Simple Coffee Bar Ideas", "Tiny Coffee Bar Ideas", "Mini Coffee Bar Ideas", "Narrow Coffee Bar Ideas", "Cheap Coffee Bar Ideas", "Coffee Bar Diy Ideas", "Dollar Tree Coffee Bar Ideas"
    ],
    [BOARD_IDS.COFFEE_BAR_IDEAS]: [
        "Coffee Bar Ideas With Sink", "Hair Salon Coffee Bar Ideas", "White Coffee Bar Ideas", "Armoire Coffee Bar Ideas", "School Coffee Bar Ideas", "Narrow Coffee Bar Ideas", "Coffee Bar Ideas In Front Of Window", "Beauty Salon Coffee Bar Ideas", "Coffee Bar Wall Decor Ideas", "Outdoor Coffee Bar Ideas", "Coffee Bar Furniture Ideas", "Ice Coffee Bar Ideas", "Coffee Snack Bar Ideas", "Coffee And Tea Bar Ideas Party", "Mini Coffee Bar Ideas Small Spaces", "Mobile Coffee Bar Ideas", "Closet Coffee Bar Ideas", "Cute Coffee Bar Ideas Small Spaces", "Coffee Bar Ideas Bedroom", "Coffee Bar Ideas On Countertop", "Coffee And Bar Ideas", "Simple Coffee Bar Ideas Kitchen Counter", "Pantry Coffee Bar Ideas", "Coffee Bar Ideas In Kitchen", "Coffee Bar Nespresso Ideas", "Cabinet Coffee Bar Ideas", "Coffee Bar Styling Ideas", "Buffet Coffee Bar Ideas", "Coffee Bar Cart Ideas Small Spaces", "Small Coffee Bar Ideas Kitchen", "Coffee Bar In Living Room Ideas", "Ikea Coffee Bar Ideas", "Coffee Bar Wedding Ideas", "Coffee Bar Gift Basket Ideas", "Coffee Bar Logo Design Ideas", "Coffee Liquor Bar Ideas", "Coffee Bar Ideas Bloxburg", "Cheap Coffee Bar Ideas", "Tiny Coffee Bar Ideas", "Coffee Bar Tray Ideas", "Coffee Bar Ideas Pink", "Coffee And Drink Bar Ideas", "Halloween Coffee Bar Ideas", "Coffee Bar Nook Ideas", "Coffee Bar Ideas Farmhouse", "Coffee Tea Bar Ideas", "Counter Top Coffee Bar Ideas", "Coffee Bar Counter Ideas", "Coffee Bar Decor Ideas Display", "At Home Coffee Bar Ideas", "Coffee Bar Ideas Simple", "Small Coffee Bar Ideas Modern", "Coffee Bar Diy Ideas", "Bedroom Coffee Bar Ideas", "Coffee Bar Ideas In Living Room", "Small Simple Coffee Bar Ideas", "Coffee And Wine Bar Ideas Small Spaces", "Coffee Bar Shelves Ideas", "Small Coffee Bar Ideas Office", "Coffee Bar At Home Ideas", "Coffee Bar Set Up Ideas Party", "Pink Coffee Bar Ideas", "Coffee Bar Kitchen Ideas", "Spring Coffee Bar Ideas", "Small Space Coffee Bar Ideas", "Glam Coffee Bar Ideas", "Coffee Bar Painting Ideas", "Coffee Bar Office Ideas", "Coffee Bar Backsplash Ideas", "Coffee Bar Ideas Kitchen Cabinets", "Coffee Bar In Dining Room Ideas", "Home Coffee Bar Ideas Kitchen Counters", "Coffee And Snack Bar Ideas", "Little Coffee Bar Ideas", "Rv Coffee Bar Ideas", "Coffee Bar Ideas Home", "Coffee Bar Lighting Ideas", "Coffee Bar Storage Ideas", "Party Coffee Bar Ideas", "Counter Coffee Bar Ideas", "Coffee Bar Menu Ideas", "Coffee And Wine Bar Ideas Small Spaces", "Wedding Coffee Bar Ideas", "Coffee Bar Home Ideas", "Ideas For Coffee Bar", "Small Coffee Bar Ideas Kitchen", "Coffee And Hot Chocolate Bar Ideas", "Coffee Bar Ideas Office", "Coffee And Bar Ideas For Home", "Coffee Bar Ideas Ikea", "Corner Coffee Bar Ideas Station", "Built In Coffee Bar Ideas", "Coffee Bar Ideas Kitchen Counter Corner", "Coffee Bar Corner Ideas", "Coffee Bar Ideas Party", "Fall Coffee Bar Decor Ideas", "Home Coffee Bar Ideas Small Spaces", "Small Corner Coffee Bar Ideas", "Coffee Bar Ideas Aesthetic", "Coffee Bar Ideas Modern", "Coffee Bar Sign Ideas", "Coffee And Liquor Bar Ideas", "Office Coffee Bar Ideas", "Coffee Bar Wall Ideas", "Coffee Bar Station Ideas", "Small Coffee Bar Ideas Apartments", "Fall Coffee Bar Ideas", "Valentine Coffee Bar Ideas", "Coffee Bar Table Ideas", "Coffee Bar Party Ideas", "Cute Coffee Bar Ideas", "Bohemian Coffee Bar Ideas", "Coffee Bar Organization Ideas", "Coffee Bar Set Up Ideas", "Small Countertop Coffee Bar Ideas", "Coffee Bar Armoire Ideas", "Coffee And Tea Bar Ideas", "Coffee Bar Ideas For Wedding", "Coffee Bar Cart Ideas", "Bakers Rack Coffee Bar Ideas", "Christmas Coffee Bar Ideas", "Salon Coffee Bar Ideas", "Coffee Bar Ideas For Kitchens", "Boho Coffee Bar Ideas", "Coffee Bar Hutch Ideas", "Coffee And Alcohol Bar Ideas", "Coffee Bar Cabinet Ideas", "Coffee Bar Ideas Kitchen", "Dollar Tree Coffee Bar Ideas", "Iced Coffee Bar Ideas Party"
    ],
    [BOARD_IDS.COZY_BEDROOM_IDEAS]: [
        "Cozy Fall Room Decor Bedroom Ideas", "Cozy Summer Bedroom Ideas", "Cozy Room Colors Bedroom Ideas", "Cozy Rv Bedroom Ideas", "King Bedroom Ideas Master Cozy", "Fall Decor Ideas For Bedroom Cozy", "Master Bedding Ideas Cozy Bedroom Romantic", "Single Woman Bedroom Ideas Cozy", "Bedroom Ideas For Women In 30'S Cozy", "Cozy Bedroom Ideas Plants", "Tiny Guest Bedroom Ideas Cozy", "Bloxburg Cozy Bedroom Ideas", "Bedroom Seating Ideas Cozy Corner", "White Cozy Bedroom Ideas", "Cozy Cute Bedroom Ideas", "Cozy Bedroom Ideas Dark Colors", "Moody Cozy Bedroom Ideas", "Minecraft Cozy Bedroom Ideas", "Cozy Gaming Bedroom Ideas", "Cozy Bedroom Office Ideas", "Cozy Bedroom Ideas Black Furniture", "Brown And White Bedroom Ideas Cozy", "Minimalist Cozy Bedroom Ideas", "Master Bedding Ideas Cozy Bedroom Layered", "Teen Girl Cozy Bedroom Ideas", "Light Brown Bedroom Ideas Cozy", "Bedroom Retreat Ideas Master Cozy", "Cozy Bedroom Ideas For Couples Rustic", "Queen Size Bedroom Ideas Cozy", "Cozy Bedroom Decor Ideas Relaxing", "Room Ideas For Women Bedroom Cozy", "Neutral Color Bedroom Ideas Cozy", "Small Dark Bedroom Ideas Cozy", "Bedroom Decor Ideas Aesthetic Cozy", "Cozy Bedroom Ideas Boho", "Cozy Bedroom Apartment Ideas", "Bed Throws Ideas Cozy Bedroom", "Cozy Farmhouse Bedroom Ideas Simple", "Cozy Bedroom Nook Ideas", "Cozy Bedroom Curtain Ideas", "Cozy Chic Bedroom Ideas", "Cozy Boho Bedroom Ideas Rustic", "Small Cozy Bedroom Ideas Tiny Apartments", "Cozy Light Bedroom Ideas", "Master Bed Ideas Cozy Bedroom Comforter", "Bedroom Makeover Ideas Cozy", "Simple And Cozy Bedroom Ideas", "Cute And Cozy Bedroom Ideas", "Aesthetic Small Bedroom Ideas Cozy", "Cozy Western Bedroom Ideas", "Cozy Spring Bedroom Ideas", "Womens Bedroom Ideas Single Cozy", "White Aesthetic Bedroom Ideas Cozy", "Cozy Modern Bedroom Ideas Small Rooms", "Cozy Large Bedroom Ideas", "Peaceful Bedroom Ideas Cozy", "Cozy Bedroom Ideas Colorful", "Dark Cozy Bedroom Ideas Fairy Lights", "Cute Bedroom Ideas Aesthetic Cozy", "Small Guest Bedroom Ideas Cozy Simple", "Bedroom Ideas For Small Rooms Women Cozy", "Bedroom Ideas Cozy Colors", "Cozy Bedroom Storage Ideas", "Cozy Moody Bedroom Ideas", "Cozy Clean Bedroom Ideas", "Cozy Farmhouse Bedroom Ideas Rustic", "Cozy Bedroom Ideas Rental", "Cozy Bedroom Ideas Black Bed Frame", "Dark Bedroom Ideas Cozy Boho", "Cozy Attic Bedroom Ideas", "Primary Bedroom Ideas Cozy", "Cute Small Bedroom Ideas Cozy", "Cozy Bedroom Ideas Vintage Cottage Style", "Cozy Big Bedroom Ideas", "Comfy Bed Ideas Cozy Bedroom", "Low Bed Ideas Cozy Bedroom Modern", "Cozy Modern Bedroom Ideas For Couples", "Cozy Grey Bedroom Ideas", "Cozy Neutral Bedroom Ideas", "Apartment Bedroom Ideas For Couples Cozy", "Gray And White Bedroom Ideas Cozy", "Bedroom Ideas Simple Cozy", "Cozy Boho Bedroom Ideas", "Small Guest Bedroom Ideas Cozy", "Cozy Romantic Bedroom Ideas", "Cozy Bedroom Decor Ideas", "Tiny Bedroom Ideas Cozy", "Small Cozy Bedroom Ideas Fairy Lights Room Decor", "Room Ideas Bedroom Cozy", "Cozy Bedroom Lighting Ideas", "Cozy Small Bedroom Ideas", "Cozy Bedroom Color Palette Ideas", "Cozy Bedroom Ideas Small Room", "Cozy Modern Bedroom Ideas", "Cute Cozy Bedroom Ideas", "Brown Bedroom Ideas Cozy", "Low Bed Ideas Cozy Bedroom", "Cozy Guest Bedroom Ideas", "Aesthetic Bedroom Ideas Cozy", "Dark Bedroom Ideas Cozy", "Comfy Cozy Bedroom Ideas", "Cozy Bedroom Ideas Aesthetic", "Bedroom Ideas Cozy", "Cozy Farmhouse Bedroom Ideas", "Bedroom Ideas For Small Rooms Cozy"
    ],
    [BOARD_IDS.ENTRYWAY_LAYOUT]: [
        "Small Entryway Ideas", "Narrow Entryway Ideas", "Large Entryway Ideas", "Modern Entryway Ideas", "Fake Entryway Ideas", "No Entryway Ideas Living Rooms", "Entryway Nook Ideas", "Square Entryway Ideas", "Awkward Entryway Ideas", "Long Narrow Entryway Ideas", "Corner Entryway Ideas"
    ],
    [BOARD_IDS.ENTRYWAY_STORAGE]: [
        "Entryway Shoe Storage Ideas", "Entryway Storage Ideas", "Entryway Bench Ideas", "Entryway Coat Rack Ideas", "Entryway Key Holder Ideas", "Entryway Furniture Ideas", "Entryway Shelf Ideas", "Entryway Closet Ideas", "Entryway Cabinet Ideas"
    ],
    [BOARD_IDS.ENTRYWAY_STYLE]: [
        "Farmhouse Entryway Ideas", "Rustic Entryway Ideas", "Boho Entryway Ideas", "Modern Organic Entryway Ideas", "Glam Entryway Ideas", "Japandi Entryway Ideas", "Mid Century Modern Entryway Ideas", "Coastal Entryway Ideas", "Dark Entryway Ideas", "Colorful Entryway Ideas"
    ],
    [BOARD_IDS.ENTRYWAY_OUTDOOR]: [
        "Front Door Entryway Ideas", "Outside Entryway Ideas", "Enclosed Entryway Ideas", "Covered Entryway Ideas", "Front Porch Entryway Ideas", "Driveway Entryway Ideas"
    ],
    [BOARD_IDS.ENTRYWAY_IDEAS]: [
        "Small Entryway Ideas", "Narrow Entryway Ideas", "Large Entryway Ideas", "Modern Entryway Ideas", "Fake Entryway Ideas", "No Entryway Ideas Living Rooms", "Entryway Nook Ideas", "Square Entryway Ideas", "Awkward Entryway Ideas", "Long Narrow Entryway Ideas", "Corner Entryway Ideas",
        "Entryway Shoe Storage Ideas", "Entryway Storage Ideas", "Entryway Bench Ideas", "Entryway Coat Rack Ideas", "Entryway Key Holder Ideas", "Entryway Furniture Ideas", "Entryway Shelf Ideas", "Entryway Closet Ideas", "Entryway Cabinet Ideas",
        "Farmhouse Entryway Ideas", "Rustic Entryway Ideas", "Boho Entryway Ideas", "Modern Organic Entryway Ideas", "Glam Entryway Ideas", "Japandi Entryway Ideas", "Mid Century Modern Entryway Ideas", "Coastal Entryway Ideas", "Dark Entryway Ideas", "Colorful Entryway Ideas",
        "Front Door Entryway Ideas", "Outside Entryway Ideas", "Enclosed Entryway Ideas", "Covered Entryway Ideas", "Front Porch Entryway Ideas", "Driveway Entryway Ideas"
    ],
};

export const BOARD_DISPLAY_INFO = [
    { label: 'Accent Ceiling Ideas', id: BOARD_IDS.ACCENT_CEILING, icon: '🛖' },
    { label: 'Backyard Walkway Ideas', id: BOARD_IDS.BACKYARD, icon: '📋' },
    { label: 'Barbie Storage Ideas', id: BOARD_IDS.BARBIE, icon: '🎀' },
    { label: 'Bathroom Remodel Idea', id: BOARD_IDS.BATHROOM_REMODEL, icon: '🛀' },
    { label: 'Bathroom Towel Rack Ideas', id: BOARD_IDS.TOWEL_RACK, icon: '🧖' },
    { label: 'Bohemian Bedroom', id: BOARD_IDS.BOHEMIAN, icon: '🧶' },
    { label: 'Cream and White Bedroom', id: BOARD_IDS.CREAM, icon: '🤍' },
    { label: 'Dark Elegant Bedroom', id: BOARD_IDS.DARK, icon: '🖤' },
    { label: 'Dark Grey Couch Living Room', id: BOARD_IDS.DARK_GREY_COUCH, icon: '🛋️' },
    { label: 'Home Apothecary', id: BOARD_IDS.APOTHECARY, icon: '🌿' },
    { label: 'Jacuzzi Outdoor', id: BOARD_IDS.JACUZZI, icon: '🛁' },
    { label: 'Purse Storage Ideas', id: BOARD_IDS.PURSE, icon: '👜' },
    { label: 'Raised Garden Beds', id: BOARD_IDS.RAISED_BEDS, icon: '🌻' },
    { label: 'Small Bedroom Ideas Cozy', id: BOARD_IDS.SMALL_BEDROOM, icon: '🛌' },
    { label: 'Stylish Home Gym', id: BOARD_IDS.GYM, icon: '💪' },
    { label: 'Summer Baby Shower Ideas', id: BOARD_IDS.BABY_SHOWER, icon: '👶' },
    { label: 'Thrifted Home Decor', id: BOARD_IDS.THRIFTED, icon: '🏺' },
    { label: 'Tile Shower Ideas', id: BOARD_IDS.TILE_SHOWER, icon: '🚿' },
    { label: 'Wall Color Combination', id: BOARD_IDS.WALL_COLOR, icon: '🎨' },
    { label: 'Whimsical Kids Room', id: BOARD_IDS.WHIMSICAL_KIDS, icon: '🎠' },
    { label: 'Victorian Living Room', id: BOARD_IDS.VICTORIAN_LIVING_ROOM, icon: '🕰️', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.VICTORIAN_LR_LAYOUT, icon: '📐', parentId: BOARD_IDS.VICTORIAN_LIVING_ROOM },
    { label: 'By Style', id: BOARD_IDS.VICTORIAN_LR_STYLE, icon: '✨', parentId: BOARD_IDS.VICTORIAN_LIVING_ROOM },
    { label: 'By Color', id: BOARD_IDS.VICTORIAN_LR_COLOR, icon: '🎨', parentId: BOARD_IDS.VICTORIAN_LIVING_ROOM },
    { label: 'By Decor', id: BOARD_IDS.VICTORIAN_LR_DECOR, icon: '🖼️', parentId: BOARD_IDS.VICTORIAN_LIVING_ROOM },
    { label: 'Victorian Interior', id: BOARD_IDS.VICTORIAN_INTERIOR, icon: '🏠' },
    { label: 'Tv Wall Bedroom Ideas', id: BOARD_IDS.TV_WALL_BEDROOM, icon: '📺', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.TV_WALL_BED_LAYOUT, icon: '📐', parentId: BOARD_IDS.TV_WALL_BEDROOM },
    { label: 'By Style', id: BOARD_IDS.TV_WALL_BED_STYLE, icon: '✨', parentId: BOARD_IDS.TV_WALL_BEDROOM },
    { label: 'By Storage', id: BOARD_IDS.TV_WALL_BED_STORAGE, icon: '📦', parentId: BOARD_IDS.TV_WALL_BEDROOM },
    { label: 'By Decor', id: BOARD_IDS.TV_WALL_BED_DECOR, icon: '🖼️', parentId: BOARD_IDS.TV_WALL_BEDROOM },
    { label: 'Small Space Living', id: BOARD_IDS.SMALL_SPACE_LIVING, icon: '🏠', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.SMALL_SPACE_LAYOUT, icon: '📏', parentId: BOARD_IDS.SMALL_SPACE_LIVING },
    { label: 'By Zones', id: BOARD_IDS.SMALL_SPACE_ZONES, icon: '📍', parentId: BOARD_IDS.SMALL_SPACE_LIVING },
    { label: 'By Style', id: BOARD_IDS.SMALL_SPACE_STYLE, icon: '✨', parentId: BOARD_IDS.SMALL_SPACE_LIVING },
    { label: 'Small Front Yard Landscaping', id: BOARD_IDS.SMALL_FRONT_YARD_LANDSCAPING, icon: '🏡' },
    { label: 'Small Kitchen Remodel', id: BOARD_IDS.SMALL_KITCHEN_REMODEL, icon: '🍳', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.SMALL_KITCHEN_LAYOUT, icon: '📐', parentId: BOARD_IDS.SMALL_KITCHEN_REMODEL },
    { label: 'By Style', id: BOARD_IDS.SMALL_KITCHEN_STYLE, icon: '✨', parentId: BOARD_IDS.SMALL_KITCHEN_REMODEL },
    { label: 'By Color', id: BOARD_IDS.SMALL_KITCHEN_COLOR, icon: '🎨', parentId: BOARD_IDS.SMALL_KITCHEN_REMODEL },
    { label: 'Small Bathroom Ideas', id: BOARD_IDS.SMALL_BATHROOM_IDEAS, icon: '🚿', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.SMALL_BA_LAYOUT, icon: '📏', parentId: BOARD_IDS.SMALL_BATHROOM_IDEAS },
    { label: 'By Style', id: BOARD_IDS.SMALL_BA_STYLE, icon: '✨', parentId: BOARD_IDS.SMALL_BATHROOM_IDEAS },
    { label: 'By Color', id: BOARD_IDS.SMALL_BA_COLOR, icon: '🎨', parentId: BOARD_IDS.SMALL_BATHROOM_IDEAS },
    { label: 'By Feature', id: BOARD_IDS.SMALL_BA_FEATURES, icon: '🛁', parentId: BOARD_IDS.SMALL_BATHROOM_IDEAS },
    { label: 'By Decor', id: BOARD_IDS.SMALL_BA_DECOR, icon: '🖼️', parentId: BOARD_IDS.SMALL_BATHROOM_IDEAS },
    { label: 'Powder Room Ideas', id: BOARD_IDS.POWDER_ROOM_IDEAS, icon: '🚪', isParent: true },
    { label: 'By Style', id: BOARD_IDS.POWDER_ROOM_STYLE, icon: '✨', parentId: BOARD_IDS.POWDER_ROOM_IDEAS },
    { label: 'By Color', id: BOARD_IDS.POWDER_ROOM_COLOR, icon: '🎨', parentId: BOARD_IDS.POWDER_ROOM_IDEAS },
    { label: 'By Feature', id: BOARD_IDS.POWDER_ROOM_FEATURES, icon: '🛁', parentId: BOARD_IDS.POWDER_ROOM_IDEAS },
    { label: 'By Decor', id: BOARD_IDS.POWDER_ROOM_DECOR, icon: '🖼️', parentId: BOARD_IDS.POWDER_ROOM_IDEAS },
    { label: 'Art Deco Bathroom', id: BOARD_IDS.ART_DECO_BATHROOM, icon: '✨', isParent: true },
    { label: 'By Style', id: BOARD_IDS.ART_DECO_BA_STYLE, icon: '✨', parentId: BOARD_IDS.ART_DECO_BATHROOM },
    { label: 'By Feature', id: BOARD_IDS.ART_DECO_BA_FEATURES, icon: '🛁', parentId: BOARD_IDS.ART_DECO_BATHROOM },
    { label: 'By Color', id: BOARD_IDS.ART_DECO_BA_COLOR, icon: '🎨', parentId: BOARD_IDS.ART_DECO_BATHROOM },
    { label: 'Bedroom Ideas For Teens', id: BOARD_IDS.BEDROOM_IDEAS_FOR_TEENS, icon: '🛌' },
    { label: 'Black and Gold Kitchen', id: BOARD_IDS.BLACK_AND_GOLD_KITCHEN, icon: '🍳', isParent: true },
    { label: 'By Fixtures', id: BOARD_IDS.BG_KITCHEN_FIXTURES, icon: '🚰', parentId: BOARD_IDS.BLACK_AND_GOLD_KITCHEN },
    { label: 'By Style', id: BOARD_IDS.BG_KITCHEN_STYLE, icon: '✨', parentId: BOARD_IDS.BLACK_AND_GOLD_KITCHEN },
    { label: 'By Color', id: BOARD_IDS.BG_KITCHEN_COLOR, icon: '🎨', parentId: BOARD_IDS.BLACK_AND_GOLD_KITCHEN },
    { label: 'Bedroom Ideas With Desk', id: BOARD_IDS.BEDROOM_IDEAS_WITH_DESK, icon: '💻' },
    { label: 'Cottage Bathroom Ideas', id: BOARD_IDS.COTTAGE_BATHROOM_IDEAS, icon: '🏡' },
    { label: 'Dark Hallway Ideas', id: BOARD_IDS.DARK_HALLWAY_IDEAS, icon: '🚪' },
    { label: 'Bedroom Ideas White Furniture', id: BOARD_IDS.BEDROOM_IDEAS_WHITE_FURNITURE, icon: '🛌' },
    { label: 'Foyer Area', id: BOARD_IDS.FOYER_AREA, icon: '🚪' },
    { label: 'Stamped Concrete Patio Ideas', id: BOARD_IDS.STAMPED_CONCRETE_PATIO_IDEAS, icon: '🏗️' },
    { label: 'Shabby Chic Bedrooms', id: BOARD_IDS.SHABBY_CHIC_BEDROOMS, icon: '💐' },
    { label: 'Mudroom Ideas Entryway', id: BOARD_IDS.MUDROOM_IDEAS_ENTRYWAY, icon: '🚪', isParent: true },
    { label: 'Small Mudroom Entryway Layout', id: BOARD_IDS.MUD_ENTRY_LAYOUT, icon: '📐', parentId: BOARD_IDS.MUDROOM_IDEAS_ENTRYWAY },
    { label: 'Mudroom Entryway Storage Ideas', id: BOARD_IDS.MUD_ENTRY_STORAGE, icon: '📦', parentId: BOARD_IDS.MUDROOM_IDEAS_ENTRYWAY },
    { label: 'Mudroom Entryway Style Ideas', id: BOARD_IDS.MUD_ENTRY_STYLE, icon: '✨', parentId: BOARD_IDS.MUDROOM_IDEAS_ENTRYWAY },
    { label: 'Mint Green Bedroom', id: BOARD_IDS.MINT_GREEN_BEDROOM, icon: '💚' },
    { label: 'Small Backyard Landscaping', id: BOARD_IDS.SMALL_BACKYARD_LANDSCAPING, icon: '🌿', isParent: true },
    { label: 'By Feature', id: BOARD_IDS.SMALL_BY_LANDSCAPE_FEAT, icon: '🌻', parentId: BOARD_IDS.SMALL_BACKYARD_LANDSCAPING },
    { label: 'By Style', id: BOARD_IDS.SMALL_BY_LANDSCAPE_STYLE, icon: '✨', parentId: BOARD_IDS.SMALL_BACKYARD_LANDSCAPING },
    { label: 'By Layout', id: BOARD_IDS.SMALL_BY_LANDSCAPE_LAYOUT, icon: '📐', parentId: BOARD_IDS.SMALL_BACKYARD_LANDSCAPING },
    { label: 'Bedroom Ideas Wardrobe', id: BOARD_IDS.BEDROOM_IDEAS_WARDROBE, icon: '🚪', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.BED_WARDROBE_LAYOUT, icon: '📐', parentId: BOARD_IDS.BEDROOM_IDEAS_WARDROBE },
    { label: 'By User', id: BOARD_IDS.BED_WARDROBE_USER, icon: '👤', parentId: BOARD_IDS.BEDROOM_IDEAS_WARDROBE },
    { label: 'By Style', id: BOARD_IDS.BED_WARDROBE_STYLE, icon: '✨', parentId: BOARD_IDS.BEDROOM_IDEAS_WARDROBE },
    { label: 'Limewash Walls', id: BOARD_IDS.LIMEWASH_WALLS, icon: '🎨', isParent: true },
    { label: 'By Color', id: BOARD_IDS.LIMEWASH_COLOR, icon: '🎨', parentId: BOARD_IDS.LIMEWASH_WALLS },
    { label: 'By Room', id: BOARD_IDS.LIMEWASH_ROOM, icon: '🏠', parentId: BOARD_IDS.LIMEWASH_WALLS },
    { label: 'By Style', id: BOARD_IDS.LIMEWASH_STYLE, icon: '✨', parentId: BOARD_IDS.LIMEWASH_WALLS },
    { label: 'Home Decor Ideas Living Room', id: BOARD_IDS.HOME_DECOR_IDEAS_LIVING_ROOM, icon: '🛋️', isParent: true },
    { label: 'By Style', id: BOARD_IDS.HOME_DECOR_LR_STYLE, icon: '✨', parentId: BOARD_IDS.HOME_DECOR_IDEAS_LIVING_ROOM },
    { label: 'By Features', id: BOARD_IDS.HOME_DECOR_LR_FEATURES, icon: '📺', parentId: BOARD_IDS.HOME_DECOR_IDEAS_LIVING_ROOM },
    { label: 'By Budget', id: BOARD_IDS.HOME_DECOR_LR_BUDGET, icon: '💰', parentId: BOARD_IDS.HOME_DECOR_IDEAS_LIVING_ROOM },
    { label: 'Coffee Table Decor Ideas', id: BOARD_IDS.COFFEE_TABLE_DECOR_IDEAS, icon: '☕', isParent: true },
    { label: 'Cozy Coffee Table Vibe', id: BOARD_IDS.COFFEE_TABLE_VIBE, icon: '✨', parentId: BOARD_IDS.COFFEE_TABLE_DECOR_IDEAS },
    { label: 'Seasonal Coffee Table Decor', id: BOARD_IDS.COFFEE_TABLE_SEASON, icon: '🍂', parentId: BOARD_IDS.COFFEE_TABLE_DECOR_IDEAS },
    { label: 'Coffee Table Decor Elements', id: BOARD_IDS.COFFEE_TABLE_ELEMENTS, icon: '🕯️', parentId: BOARD_IDS.COFFEE_TABLE_DECOR_IDEAS },
    { label: 'Bathroom Wallpaper Ideas', id: BOARD_IDS.BATHROOM_WALLPAPER_IDEAS, icon: '🖼️', isParent: true },
    { label: 'Bathroom Wallpaper Styling', id: BOARD_IDS.BA_WALLPAPER_STYLE, icon: '✨', parentId: BOARD_IDS.BATHROOM_WALLPAPER_IDEAS },
    { label: 'Bathroom Wallpaper Color Ideas', id: BOARD_IDS.BA_WALLPAPER_COLOR, icon: '🎨', parentId: BOARD_IDS.BATHROOM_WALLPAPER_IDEAS },
    { label: 'Bathroom Wallpaper By Room', id: BOARD_IDS.BA_WALLPAPER_ROOM, icon: '🏠', parentId: BOARD_IDS.BATHROOM_WALLPAPER_IDEAS },
    { label: 'Dark Cottagecore Kitchen', id: BOARD_IDS.DARK_COTTAGECORE_KITCHEN, icon: '🌙' },
    { label: 'Small Living Room Ideas', id: BOARD_IDS.SMALL_LIVING_ROOM_IDEAS, icon: '🛋️', isParent: true },
    { label: 'Small Living Room Layout', id: BOARD_IDS.SMALL_LR_LAYOUT, icon: '📏', parentId: BOARD_IDS.SMALL_LIVING_ROOM_IDEAS },
    { label: 'Small Living Room Style', id: BOARD_IDS.SMALL_LR_STYLE, icon: '✨', parentId: BOARD_IDS.SMALL_LIVING_ROOM_IDEAS },
    { label: 'Small Living Room Features', id: BOARD_IDS.SMALL_LR_FEATURES, icon: '📺', parentId: BOARD_IDS.SMALL_LIVING_ROOM_IDEAS },
    { label: 'Small Living Room Decor', id: BOARD_IDS.SMALL_LR_DECOR, icon: '🖼️', parentId: BOARD_IDS.SMALL_LIVING_ROOM_IDEAS },
    { label: 'Fireplace Mantle Decor', id: BOARD_IDS.FIREPLACE_MANTLE_DECOR, icon: '🔥', isParent: true },
    { label: 'Fireplace Mantle Style', id: BOARD_IDS.FIREPLACE_MANTLE_STYLE, icon: '✨', parentId: BOARD_IDS.FIREPLACE_MANTLE_DECOR },
    { label: 'Holiday Fireplace Mantle', id: BOARD_IDS.FIREPLACE_MANTLE_HOLIDAY, icon: '🎄', parentId: BOARD_IDS.FIREPLACE_MANTLE_DECOR },
    { label: 'Fireplace Mantle Features', id: BOARD_IDS.FIREPLACE_MANTLE_FEATURE, icon: '📺', parentId: BOARD_IDS.FIREPLACE_MANTLE_DECOR },
    { label: 'Mud Room', id: BOARD_IDS.MUD_ROOM, icon: '🚪', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.MUD_ROOM_LAYOUT, icon: '📐', parentId: BOARD_IDS.MUD_ROOM },
    { label: 'By Storage', id: BOARD_IDS.MUD_ROOM_STORAGE, icon: '📦', parentId: BOARD_IDS.MUD_ROOM },
    { label: 'For Pets', id: BOARD_IDS.MUD_ROOM_PETS, icon: '🐕', parentId: BOARD_IDS.MUD_ROOM },
    { label: 'By Decor', id: BOARD_IDS.MUD_ROOM_DECOR, icon: '🖼️', parentId: BOARD_IDS.MUD_ROOM },
    { label: 'Master Bedrooms Decor', id: BOARD_IDS.MASTER_BEDROOMS_DECOR, icon: '🛏️', isParent: true },
    { label: 'By Vibe', id: BOARD_IDS.MASTER_BED_VIBE, icon: '✨', parentId: BOARD_IDS.MASTER_BEDROOMS_DECOR },
    { label: 'By Style', id: BOARD_IDS.MASTER_BED_STYLE, icon: '🎨', parentId: BOARD_IDS.MASTER_BEDROOMS_DECOR },
    { label: 'By Color', id: BOARD_IDS.MASTER_BED_COLOR, icon: '🌈', parentId: BOARD_IDS.MASTER_BEDROOMS_DECOR },
    { label: 'By Feature', id: BOARD_IDS.MASTER_BED_FEATURES, icon: '🛌', parentId: BOARD_IDS.MASTER_BEDROOMS_DECOR },
    { label: 'Mudroom Idea', id: BOARD_IDS.MUDROOM_IDEA, icon: '👞', isParent: true },
    { label: 'Mudroom Layout Ideas', id: BOARD_IDS.MUDROOM_IDEA_LAYOUT, icon: '📐', parentId: BOARD_IDS.MUDROOM_IDEA },
    { label: 'Mudroom Storage Solutions', id: BOARD_IDS.MUDROOM_IDEA_STORAGE, icon: '📦', parentId: BOARD_IDS.MUDROOM_IDEA },
    { label: 'Mudroom Style Inspiration', id: BOARD_IDS.MUDROOM_IDEA_STYLE, icon: '✨', parentId: BOARD_IDS.MUDROOM_IDEA },
    { label: 'Mudroom Setting Ideas', id: BOARD_IDS.MUDROOM_IDEA_SETTING, icon: '🏠', parentId: BOARD_IDS.MUDROOM_IDEA },
    { label: 'Covered Patio Ideas', id: BOARD_IDS.COVERED_PATIO_IDEAS, icon: '☂️', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.COVERED_PATIO_LAYOUT, icon: '📐', parentId: BOARD_IDS.COVERED_PATIO_IDEAS },
    { label: 'By Feature', id: BOARD_IDS.COVERED_PATIO_FEATURES, icon: '🔥', parentId: BOARD_IDS.COVERED_PATIO_IDEAS },
    { label: 'By Decor', id: BOARD_IDS.COVERED_PATIO_DECOR, icon: '🖼️', parentId: BOARD_IDS.COVERED_PATIO_IDEAS },
    { label: 'By Size', id: BOARD_IDS.COVERED_PATIO_SIZE, icon: '📏', parentId: BOARD_IDS.COVERED_PATIO_IDEAS },
    { label: 'Closet Organization Ideas', id: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS, icon: '🗄️', isParent: true },
    { label: 'Closet By Size', id: BOARD_IDS.CLOSET_ORG_SIZE, icon: '📏', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet By Features', id: BOARD_IDS.CLOSET_ORG_FEATURES, icon: '🚪', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet By Items', id: BOARD_IDS.CLOSET_ORG_ITEMS, icon: '👕', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet By User', id: BOARD_IDS.CLOSET_ORG_USER, icon: '👤', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet By Style', id: BOARD_IDS.CLOSET_ORG_STYLE, icon: '✨', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet By Budget', id: BOARD_IDS.CLOSET_ORG_BUDGET, icon: '💰', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet Special Cat', id: BOARD_IDS.CLOSET_ORG_SPECIAL, icon: '🎖️', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Closet Methods', id: BOARD_IDS.CLOSET_ORG_METHODS, icon: '🗂️', parentId: BOARD_IDS.CLOSET_ORGANIZATION_IDEAS },
    { label: 'Modern Tv Wall Design', id: BOARD_IDS.MODERN_TV_WALL_DESIGN, icon: '📺', isParent: true },
    { label: 'By Style', id: BOARD_IDS.MODERN_TV_WALL_STYLE, icon: '✨', parentId: BOARD_IDS.MODERN_TV_WALL_DESIGN },
    { label: 'By Feature', id: BOARD_IDS.MODERN_TV_WALL_FEATURE, icon: '📺', parentId: BOARD_IDS.MODERN_TV_WALL_DESIGN },
    { label: 'By Room', id: BOARD_IDS.MODERN_TV_WALL_ROOM, icon: '🏠', parentId: BOARD_IDS.MODERN_TV_WALL_DESIGN },
    { label: 'Girls Bedroom Ideas', id: BOARD_IDS.GIRLS_BEDROOM_IDEAS, icon: '🎀', isParent: true },
    { label: 'By Theme', id: BOARD_IDS.GIRLS_BED_THEME, icon: '🌈', parentId: BOARD_IDS.GIRLS_BEDROOM_IDEAS },
    { label: 'By Style', id: BOARD_IDS.GIRLS_BED_STYLE, icon: '✨', parentId: BOARD_IDS.GIRLS_BEDROOM_IDEAS },
    { label: 'By User', id: BOARD_IDS.GIRLS_BED_USER, icon: '👤', parentId: BOARD_IDS.GIRLS_BEDROOM_IDEAS },
    { label: 'By Storage', id: BOARD_IDS.GIRLS_BED_STORAGE, icon: '📦', parentId: BOARD_IDS.GIRLS_BEDROOM_IDEAS },
    { label: 'Farmhouse Decor Living Room', id: BOARD_IDS.FARMHOUSE_DECOR_LIVING_ROOM, icon: '🏡', isParent: true },
    { label: 'By Wall', id: BOARD_IDS.FARMHOUSE_LR_WALL, icon: '🧱', parentId: BOARD_IDS.FARMHOUSE_DECOR_LIVING_ROOM },
    { label: 'By Style', id: BOARD_IDS.FARMHOUSE_LR_STYLE, icon: '✨', parentId: BOARD_IDS.FARMHOUSE_DECOR_LIVING_ROOM },
    { label: 'By Feature', id: BOARD_IDS.FARMHOUSE_LR_FEAT, icon: '📺', parentId: BOARD_IDS.FARMHOUSE_DECOR_LIVING_ROOM },
    { label: 'Coffee Bar Ideas', id: BOARD_IDS.COFFEE_BAR_IDEAS, icon: '☕', isParent: true },
    { label: 'By Style', id: BOARD_IDS.COFFEE_BAR_STYLE, icon: '✨', parentId: BOARD_IDS.COFFEE_BAR_IDEAS },
    { label: 'By Room', id: BOARD_IDS.COFFEE_BAR_ROOM, icon: '🏠', parentId: BOARD_IDS.COFFEE_BAR_IDEAS },
    { label: 'By Setup', id: BOARD_IDS.COFFEE_BAR_SETUP, icon: '🛠️', parentId: BOARD_IDS.COFFEE_BAR_IDEAS },
    { label: 'By Size', id: BOARD_IDS.COFFEE_BAR_SIZE, icon: '📏', parentId: BOARD_IDS.COFFEE_BAR_IDEAS },
    { label: 'Cozy Bedroom Ideas', id: BOARD_IDS.COZY_BEDROOM_IDEAS, icon: '🛌' },
    { label: 'Entryway Ideas', id: BOARD_IDS.ENTRYWAY_IDEAS, icon: '🚪', isParent: true },
    { label: 'By Layout', id: BOARD_IDS.ENTRYWAY_LAYOUT, icon: '📏', parentId: BOARD_IDS.ENTRYWAY_IDEAS },
    { label: 'By Storage', id: BOARD_IDS.ENTRYWAY_STORAGE, icon: '📦', parentId: BOARD_IDS.ENTRYWAY_IDEAS },
    { label: 'By Style', id: BOARD_IDS.ENTRYWAY_STYLE, icon: '✨', parentId: BOARD_IDS.ENTRYWAY_IDEAS },
    { label: 'Outdoor', id: BOARD_IDS.ENTRYWAY_OUTDOOR, icon: '🏡', parentId: BOARD_IDS.ENTRYWAY_IDEAS }
];
