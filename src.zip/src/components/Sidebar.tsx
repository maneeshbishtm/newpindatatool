
import React, { useState } from 'react';
import { BOARD_DISPLAY_INFO } from '../data/boards';

interface SidebarProps {
    activeTab?: string;
    onTabChange?: (tab: string) => void;
    isLoggedIn: boolean;
    userEmail: string;
    userName: string;
    onLoginClick: () => void;
    onLogoutClick: () => void;
    onDapClick: () => void;
    isDarkMode?: boolean;
    width?: number;
}

const Sidebar: React.FC<SidebarProps> = ({
    activeTab = 'explorer',
    onTabChange,
    isLoggedIn,
    userEmail,
    userName,
    onLoginClick,
    onLogoutClick,
    onDapClick,
    isDarkMode,
    width = 224
}) => {
    const [isProfileExpanded, setIsProfileExpanded] = useState(false);
    const [isManageMode, setIsManageMode] = useState(false);
    const [isBoardExpanded, setIsBoardExpanded] = useState(true);
    const [hiddenBoardIds, setHiddenBoardIds] = useState<string[]>(() => {
        const saved = localStorage.getItem('pindata_hidden_boards');
        return saved ? JSON.parse(saved) : [];
    });
    const [expandedParentIds, setExpandedParentIds] = useState<string[]>([]);

    const navItems = [
        { label: 'Explorer', id: 'explorer', icon: '🔍' },
        { label: 'Saved', id: 'saved', icon: '📌' },
        { label: 'List Generator', id: 'mixer', icon: '🪄' },
    ];

    const boardItems = BOARD_DISPLAY_INFO;

    const toggleBoardVisibility = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        const nextHidden = hiddenBoardIds.includes(id)
            ? hiddenBoardIds.filter(bid => bid !== id)
            : [...hiddenBoardIds, id];
        setHiddenBoardIds(nextHidden);
        localStorage.setItem('pindata_hidden_boards', JSON.stringify(nextHidden));
    };

    const visibleBoards = isManageMode
        ? boardItems
        : boardItems.filter(item => !hiddenBoardIds.includes(item.id));

    return (
        <aside
            className={`h-screen border-r flex flex-col fixed left-0 top-0 z-40 transition-colors duration-300 ${isDarkMode ? 'bg-[#1a1a20] border-white/5' : 'bg-white border-gray-100'}`}
            style={{ width: `${width}px` }}
        >
            {/* Brand Header */}
            <div className="px-6 pt-8 pb-6">
                <div className="flex items-center gap-2 mb-1.5">
                    <div className="w-7 h-7 bg-red-600 rounded-md flex items-center justify-center">
                        <span className="text-white text-base font-black italic">P</span>
                    </div>
                    <h1 className={`text-lg font-extrabold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Pin<span className="text-red-600">Data</span>
                    </h1>
                </div>
                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Keyword Intel</p>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-3 overflow-y-auto custom-scrollbar">
                <p className="px-3 text-[8px] font-black text-gray-400 uppercase tracking-widest mb-2">Menu</p>
                <ul className="space-y-1 mb-6">
                    {navItems.map((item) => {
                        const isActive = activeTab === item.id;
                        return (
                            <li key={item.id}>
                                <button
                                    onClick={() => onTabChange?.(item.id)}
                                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-all group relative ${isActive
                                        ? 'bg-red-50 text-red-700'
                                        : isDarkMode ? 'text-white/40 hover:bg-white/5 hover:text-white' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                                        }`}
                                >
                                    {isActive && (
                                        <div className="absolute left-0 w-1 h-5 bg-red-600 rounded-r-full" />
                                    )}
                                    <span className={`w-7 h-7 flex items-center justify-center rounded-md text-sm transition-colors ${isActive ? 'bg-red-100' : isDarkMode ? 'bg-white/5 group-hover:bg-white/10' : 'bg-gray-100 group-hover:bg-gray-200'
                                        }`}>
                                        {item.icon}
                                    </span>
                                    {item.label}
                                </button>
                            </li>
                        );
                    })}
                </ul>

                {/* Board Header Section with Collapse Toggle */}
                <div className="flex items-center justify-between px-3 mb-2">
                    <button
                        onClick={() => setIsBoardExpanded(!isBoardExpanded)}
                        className="flex items-center gap-2 text-[8px] font-black text-gray-400 uppercase tracking-widest hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
                    >
                        <svg
                            className={`w-2.5 h-2.5 transition-transform duration-200 ${isBoardExpanded ? 'rotate-90' : ''}`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M9 5l7 7-7 7" />
                        </svg>
                        Board
                    </button>

                    <button
                        onClick={() => setIsManageMode(!isManageMode)}
                        className={`p-1 rounded-md transition-all ${isManageMode ? 'bg-red-600 text-white shadow-sm' : 'text-gray-300 hover:text-red-600 hover:bg-red-50'}`}
                        title="Manage Board Visibility"
                    >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </button>
                </div>

                {/* Collapsible Board List */}
                {isBoardExpanded && (
                    <div className="space-y-3 animate-in fade-in slide-in-from-top-1 duration-200">
                        {(() => {
                            const displayedBoards = visibleBoards.filter((item: any) => {
                                if (item.parentId && !expandedParentIds.includes(item.parentId)) return false;
                                return true;
                            });

                            const sectionColors = [
                                { light: 'bg-blue-50/40', dark: 'bg-blue-500/5' },
                                { light: 'bg-emerald-50/40', dark: 'bg-emerald-500/5' },
                                { light: 'bg-amber-50/40', dark: 'bg-amber-500/5' },
                                { light: 'bg-purple-50/40', dark: 'bg-purple-500/5' },
                                { light: 'bg-rose-50/40', dark: 'bg-rose-500/5' },
                                { light: 'bg-indigo-50/40', dark: 'bg-indigo-500/5' },
                                { light: 'bg-teal-50/40', dark: 'bg-teal-500/5' },
                                { light: 'bg-cyan-50/40', dark: 'bg-cyan-500/5' },
                                { light: 'bg-violet-50/40', dark: 'bg-violet-500/5' },
                                { light: 'bg-pink-50/40', dark: 'bg-pink-500/5' },
                            ];

                            const chunks = [];
                            for (let i = 0; i < displayedBoards.length; i += 10) {
                                chunks.push(displayedBoards.slice(i, i + 10));
                            }

                            return chunks.map((chunk, chunkIndex) => {
                                const sectionColor = sectionColors[chunkIndex % sectionColors.length];

                                return (
                                    <div
                                        key={chunkIndex}
                                        className={`rounded-xl overflow-hidden transition-all duration-500 ${isDarkMode ? sectionColor.dark : sectionColor.light}`}
                                    >
                                        {chunkIndex > 0 && (
                                            <div className={`h-[1px] ${isDarkMode ? 'bg-white/10' : 'bg-gray-200'}`} />
                                        )}
                                        <ul className="p-1.5 space-y-1">
                                            {chunk.map((item: any) => {
                                                const isChild = !!item.parentId;
                                                const isParent = !!item.isParent;
                                                const isParentExpanded = expandedParentIds.includes(item.id);
                                                const isActive = activeTab === item.id;
                                                const isHidden = hiddenBoardIds.includes(item.id);

                                                return (
                                                    <li key={item.id} className={isChild ? 'ml-3' : ''}>
                                                        <button
                                                            onClick={() => {
                                                                if (isManageMode) return;
                                                                if (isParent) {
                                                                    setExpandedParentIds(prev =>
                                                                        prev.includes(item.id)
                                                                            ? prev.filter(id => id !== item.id)
                                                                            : [...prev, item.id]
                                                                    );
                                                                }
                                                                onTabChange?.(item.id);
                                                            }}
                                                            className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition-all group relative ${isActive && !isManageMode
                                                                ? 'bg-red-50 text-red-700'
                                                                : isDarkMode ? 'text-white/40 hover:bg-white/5 hover:text-white' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                                                                } ${isManageMode ? 'cursor-default' : ''}`}
                                                        >
                                                            {isActive && !isManageMode && (
                                                                <div className="absolute left-0 w-1 h-5 bg-red-600 rounded-r-full" />
                                                            )}
                                                            <span className={`w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-md text-sm transition-colors ${isActive && !isManageMode ? 'bg-red-100' : isDarkMode ? 'bg-white/5 group-hover:bg-white/10' : 'bg-gray-100 group-hover:bg-gray-200'
                                                                }`}>
                                                                {item.icon}
                                                            </span>
                                                            <span className={`flex-1 text-left whitespace-normal leading-tight break-words ${isManageMode && isHidden ? 'opacity-30' : ''}`}>
                                                                {item.label}
                                                            </span>

                                                            {isParent && !isManageMode && (
                                                                <svg
                                                                    className={`w-3 h-3 transition-transform duration-200 ${isParentExpanded ? 'rotate-180' : ''}`}
                                                                    fill="none"
                                                                    stroke="currentColor"
                                                                    viewBox="0 0 24 24"
                                                                >
                                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                                                                </svg>
                                                            )}

                                                            {isManageMode && (
                                                                <button
                                                                    onClick={(e) => toggleBoardVisibility(e, item.id)}
                                                                    className={`ml-auto p-1.5 rounded-md transition-all transform active:scale-90 ${isHidden ? 'text-gray-300 hover:text-red-600' : 'text-red-600 hover:bg-red-50'
                                                                        }`}
                                                                >
                                                                    {isHidden ? (
                                                                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" />
                                                                        </svg>
                                                                    ) : (
                                                                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268-2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                                                        </svg>
                                                                    )}
                                                                </button>
                                                            )}
                                                        </button>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                );
                            });
                        })()}
                    </div>
                )}
            </nav>

            {/* Profile & Auth Section */}
            <div className="p-4 space-y-3 border-t border-gray-100 dark:border-white/5">
                {isLoggedIn ? (
                    <div className="space-y-1.5">
                        <button
                            onClick={() => setIsProfileExpanded(!isProfileExpanded)}
                            className={`w-full flex items-center gap-2.5 p-2 border rounded-xl shadow-sm transition-all text-left ${isDarkMode ? 'bg-[#1a1a20] border-white/5 hover:border-red-600/50' : 'bg-white border-gray-100 hover:border-red-200'} ${isProfileExpanded ? 'ring-2 ring-red-50' : ''}`}
                        >
                            <div className="relative flex-shrink-0">
                                <div className="w-8 h-8 rounded-lg bg-gray-900 flex items-center justify-center text-white font-bold text-[10px] uppercase">
                                    {userName ? userName.substring(0, 2) : userEmail.substring(0, 2)}
                                </div>
                                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border border-white rounded-full"></div>
                            </div>
                            <div className="flex flex-col min-w-0 flex-1">
                                <span className={`text-[10px] font-black truncate uppercase ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{userName || 'GUEST'}</span>
                                <span className="text-[8px] font-bold text-red-600 uppercase tracking-tighter mt-0.5">Premium</span>
                            </div>
                            <svg
                                className={`w-3 h-3 text-gray-300 transition-transform duration-300 ${isProfileExpanded ? 'rotate-180' : ''}`}
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>

                        {isProfileExpanded && (
                            <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                                <button
                                    onClick={onDapClick}
                                    className="w-full py-2 px-3 bg-red-50 text-red-600 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-red-100 transition-all transform active:scale-95"
                                >
                                    DAP
                                </button>
                                <button
                                    onClick={onLogoutClick}
                                    className={`w-full py-2 px-3 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all transform active:scale-95 ${isDarkMode ? 'bg-white/5 text-white/40 hover:bg-red-600 hover:text-white' : 'bg-gray-50 text-gray-500 hover:bg-red-600 hover:text-white'}`}
                                >
                                    Log Out
                                </button>
                            </div>
                        )}
                    </div>
                ) : (
                    <button
                        onClick={onLoginClick}
                        className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-red-600 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-red-100 hover:bg-red-700 transition-all transform active:scale-95"
                    >
                        Log In
                    </button>
                )}

                <div className="text-center">
                    <p className="text-[7px] text-gray-300 font-black uppercase tracking-[0.2em]">
                        (Credit by - A MS Bisht FILM)
                    </p>
                </div>
            </div>

            <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 10px;
        }
        ${isDarkMode ? '.custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.05); }' : ''}
      `}</style>
        </aside>
    );
};

export default Sidebar;
