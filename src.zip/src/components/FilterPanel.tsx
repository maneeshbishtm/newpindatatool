
import React, { useMemo, useState } from 'react';
import { CATEGORIES, MOCK_KEYWORDS } from '../data/mockData';
import { VOLUME_RANGES } from '../constants';

interface FilterPanelProps {
    selectedCategories: string[];
    onToggleCategory: (id: string) => void;
    selectedVolumeRangeIndices: number[];
    onToggleVolumeRange: (index: number) => void;
    isDarkMode?: boolean;
    onReset?: () => void;
}

const categoryColorStyles: Record<string, { bg: string, text: string, border: string, accent: string }> = {
    'bedroom': { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-100', accent: 'bg-rose-600' },
    'bathroom': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-100', accent: 'bg-red-600' },
    'living-room': { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-100', accent: 'bg-orange-600' },
    'kitchen': { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100', accent: 'bg-yellow-600' },
    'lighting': { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-100', accent: 'bg-amber-600' }, // Updated 'light' to 'lighting'
    'seasonal': { bg: 'bg-fuchsia-50', text: 'text-fuchsia-700', border: 'border-fuchsia-100', accent: 'bg-fuchsia-600' },
    'garden': { bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-100', accent: 'bg-teal-600' }, // New
    'deck-patio': { bg: 'bg-stone-50', text: 'text-stone-700', border: 'border-stone-100', accent: 'bg-stone-600' }, // New
    'pool': { bg: 'bg-cyan-50', text: 'text-cyan-700', border: 'border-cyan-100', accent: 'bg-cyan-600' }, // New
    'garage': { bg: 'bg-zinc-50', text: 'text-zinc-700', border: 'border-zinc-100', accent: 'bg-zinc-600' }, // New
    'organization': { bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-100', accent: 'bg-sky-600' },
    'decor': { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-100', accent: 'bg-indigo-600' },
    'other': { bg: 'bg-slate-50', text: 'text-slate-700', border: 'border-slate-100', accent: 'bg-slate-600' }
};

const volumeColorStyles = [
    { bg: 'bg-slate-50', text: 'text-slate-700', border: 'border-slate-100', accent: 'bg-slate-600', gradient: 'from-slate-500 to-slate-600' },
    { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-100', accent: 'bg-rose-600', gradient: 'from-rose-500 to-rose-600' },
    { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-100', accent: 'bg-red-600', gradient: 'from-red-500 to-red-600' },
    { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-100', accent: 'bg-orange-600', gradient: 'from-orange-500 to-orange-600' },
    { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-100', accent: 'bg-amber-600', gradient: 'from-amber-500 to-amber-600' },
    { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100', accent: 'bg-yellow-600', gradient: 'from-yellow-500 to-yellow-600' },
    { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-100', accent: 'bg-emerald-600', gradient: 'from-emerald-500 to-emerald-600' },
];

const FilterPanel: React.FC<FilterPanelProps> = ({
    selectedCategories,
    onToggleCategory,
    selectedVolumeRangeIndices,
    onToggleVolumeRange,
    isDarkMode,
    onReset
}) => {
    const [showVolumeRanges, setShowVolumeRanges] = useState(false);

    const volumeRangeCounts = useMemo(() => {
        return VOLUME_RANGES.map(range => {
            const [min, max] = range.value;
            return MOCK_KEYWORDS.filter(k => {
                const meetsMin = k.volume >= min;
                const meetsMax = max === null ? true : k.volume < max;
                return meetsMin && meetsMax;
            }).length;
        });
    }, []);

    return (
        <div className={`w-52 flex-shrink-0 border rounded-[1.5rem] p-4 h-fit shadow-md transition-all sticky top-24 z-10 ${isDarkMode ? 'bg-[#1a1a20] border-white/5' : 'bg-white border-red-100'}`}>
            <div className={`flex items-center justify-between mb-4 border-b pb-1.5 ${isDarkMode ? 'border-white/5' : 'border-red-50'}`}>
                <h3 className={`text-sm font-black uppercase tracking-widest`}>Filters</h3>
                {onReset && (
                    <button
                        onClick={onReset}
                        className="text-[8px] font-black text-red-600 hover:text-red-700 transition-colors uppercase tracking-widest px-2 py-1 bg-red-50 dark:bg-red-600/10 rounded-md"
                    >
                        Reset
                    </button>
                )}
            </div>

            <div className="space-y-6">
                <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                        <p className="text-[9px] font-black text-red-400 uppercase tracking-widest">Volume</p>
                        <button
                            onClick={() => setShowVolumeRanges(!showVolumeRanges)}
                            className="text-[8px] font-black bg-red-50 dark:bg-red-600/10 text-red-600 px-1.5 py-0.5 rounded hover:bg-red-100 dark:hover:bg-red-600/20 uppercase tracking-widest"
                        >
                            {showVolumeRanges ? 'Hide' : 'Show'}
                        </button>
                    </div>

                    {showVolumeRanges && (
                        <div className="space-y-1.5 max-h-[300px] overflow-y-auto px-0.5 scrollbar-hide">
                            {VOLUME_RANGES.map((range, index) => {
                                const isSelected = selectedVolumeRangeIndices.includes(index);
                                const count = volumeRangeCounts[index];
                                const colors = volumeColorStyles[index % volumeColorStyles.length];

                                return (
                                    <div
                                        key={range.label}
                                        className={`flex items-center justify-between p-2 rounded-xl cursor-pointer border transition-all ${isSelected ? `${colors.bg} ${colors.border} shadow-sm` : isDarkMode ? 'border-transparent hover:bg-white/5' : 'border-transparent hover:bg-red-50/50'
                                            }`}
                                        onClick={() => onToggleVolumeRange(index)}
                                    >
                                        <div className="flex items-center gap-2">
                                            <div className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${isSelected ? `bg-gradient-to-br ${colors.gradient} border-transparent` : 'bg-white border-red-50'
                                                }`}>
                                                {isSelected && <div className="w-1 h-1 bg-white rounded-full" />}
                                            </div>
                                            <span className={`text-xs ${isSelected ? `font-black ${colors.text}` : isDarkMode ? 'text-white/60' : 'text-gray-600 font-bold'}`}>
                                                {range.label}
                                            </span>
                                        </div>
                                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full ${isSelected ? `${colors.bg} brightness-95 text-slate-900` : isDarkMode ? 'bg-white/5 text-white/20' : 'bg-red-50 text-red-300'}`}>
                                            {count}
                                        </span>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                <div className={`pt-4 border-t space-y-2 ${isDarkMode ? 'border-white/5' : 'border-red-50'}`}>
                    <p className="text-[9px] font-black text-red-400 mb-2 uppercase tracking-widest px-1">Categories</p>
                    <div className="space-y-1">
                        {CATEGORIES.map((cat) => {
                            const isSelected = selectedCategories.includes(cat.id);
                            const colors = categoryColorStyles[cat.id] || categoryColorStyles['other'];

                            return (
                                <div
                                    key={cat.id}
                                    className={`flex items-center justify-between p-2 rounded-xl cursor-pointer border transition-all ${isSelected ? `${colors.bg} ${colors.border} shadow-sm` : isDarkMode ? 'border-transparent hover:bg-white/5' : 'border-transparent hover:bg-red-50/50'
                                        }`}
                                    onClick={() => onToggleCategory(cat.id)}
                                >
                                    <div className="flex items-center gap-2">
                                        <div className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${isSelected ? `${colors.accent} border-transparent` : 'border-red-100 bg-white'
                                            }`}>
                                            {isSelected && <div className="w-1 h-1 rounded-full bg-white" />}
                                        </div>
                                        <span className={`text-xs font-black ${isSelected ? colors.text : isDarkMode ? 'text-white/60' : 'text-gray-600'}`}>
                                            {cat.name}
                                        </span>
                                    </div>
                                    <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-full ${isSelected ? `${colors.bg} brightness-95` : isDarkMode ? 'bg-white/5 text-white/20' : 'bg-red-50 text-red-300'}`}>
                                        {cat.count}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FilterPanel;
