
import React, { useState } from 'react';
import { BOARD_DISPLAY_INFO, BOARD_DATA, BOARD_IDS } from '../data/boards';
import type { KeywordData } from '../types';

interface GeneratedMixKeyword {
    id: string;
    name: string;
    volume: number;
    boardLabel: string;
}

interface MixerProps {
    allKeywords: KeywordData[];
    isDarkMode: boolean;
    onSaveHistory: (mix: { boardLabel: string, keywords: { name: string, volume: number, id: string }[] }[]) => void;
    onDeleteHistory: (index: number) => void;
    pickedIds: Set<string>;
    history: {
        date: string,
        userName?: string,
        mix: { boardLabel: string, keywords: { name: string, volume: number, id: string }[] }[]
    }[];
    onAction?: (action: string, data: string) => void;
    onTabChange?: (tab: string) => void;
}


const Mixer: React.FC<MixerProps> = ({ allKeywords, isDarkMode, onSaveHistory, onDeleteHistory, pickedIds, history, onAction, onTabChange }) => {

    const [selectedBoardIds, setSelectedBoardIds] = useState<string[]>([]);
    const [generatedMix, setGeneratedMix] = useState<{ boardLabel: string, parentLabel?: string, keywords: GeneratedMixKeyword[] }[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);
    const [copyStatus, setCopyStatus] = useState<string | null>(null);
    const [showRepeatModal, setShowRepeatModal] = useState(false);
    const [pendingExhaustedBoards, setPendingExhaustedBoards] = useState<string[]>([]);
    const [hideExhausted, setHideExhausted] = useState(false);
    const [exhaustedClickCounts, setExhaustedClickCounts] = useState<Record<string, number>>({});
    const [targetCount, setTargetCount] = useState(10);
    const [expandedHistoryIndex, setExpandedHistoryIndex] = useState<number | null>(null);
    const [showStatsModal, setShowStatsModal] = useState(false);
    const [isShuffling, setIsShuffling] = useState(false);
    const [lockedBoardIds, setLockedBoardIds] = useState<string[]>([]);
    const [unlockClickCounts, setUnlockClickCounts] = useState<Record<string, number>>({});
    const [showLocked, setShowLocked] = useState(false);

    const getBoardFamilyColor = (boardId: string) => {
        const board = BOARD_DISPLAY_INFO.find(b => b.id === boardId);
        if (!board) return '';

        const familyId = board.isParent ? board.id : board.parentId;
        if (!familyId) return '';

        switch (familyId) {
            case BOARD_IDS.SMALL_BATHROOM_IDEAS:
                return isDarkMode ? 'bg-blue-500/20 border-blue-500/30' : 'bg-blue-100/70 border-blue-200';
            case BOARD_IDS.SMALL_LIVING_ROOM_IDEAS:
                return isDarkMode ? 'bg-indigo-500/20 border-indigo-500/30' : 'bg-indigo-100/70 border-indigo-200';
            case BOARD_IDS.COFFEE_BAR_IDEAS:
                return isDarkMode ? 'bg-amber-500/20 border-amber-500/30' : 'bg-amber-100/70 border-amber-200';
            case BOARD_IDS.MUD_ROOM:
                return isDarkMode ? 'bg-emerald-500/20 border-emerald-500/30' : 'bg-emerald-100/70 border-emerald-200';
            case BOARD_IDS.CLOSET_ORGANIZATION_IDEAS:
                return isDarkMode ? 'bg-purple-500/20 border-purple-500/30' : 'bg-purple-100/70 border-purple-200';
            default:
                return '';
        }
    };

    const getInterleavedKeywords = () => {
        if (generatedMix.length === 0) return [];
        const maxLen = Math.max(...generatedMix.map(group => group.keywords.length));
        const interleaved: GeneratedMixKeyword[] = [];
        for (let i = 0; i < maxLen; i++) {
            generatedMix.forEach(group => {
                if (group.keywords[i]) {
                    interleaved.push(group.keywords[i]);
                }
            });
        }
        return interleaved;
    };

    // Persist picked keyword IDs to avoid picking the same ones again
    // Replaced with props.pickedIds

    const getEffectiveBoardKeywordNames = (boardId: string) => {
        let names = BOARD_DATA[boardId] || [];
        const boardInfo = BOARD_DISPLAY_INFO.find(b => b.id === boardId);

        // If it's a parent board, subtract all keywords that exist in any of its children
        if (boardInfo?.isParent) {
            const children = BOARD_DISPLAY_INFO.filter(b => b.parentId === boardId);
            const childKeywordNames = new Set(children.flatMap(child => BOARD_DATA[child.id] || []));
            names = names.filter(name => !childKeywordNames.has(name));
        }
        return names;
    };

    const isBoardExhausted = (boardId: string) => {
        const boardKeywordNames = getEffectiveBoardKeywordNames(boardId);
        const boardKeywords = allKeywords.filter((k: KeywordData) => boardKeywordNames.includes(k.name));
        if (boardKeywords.length === 0) return false;
        return boardKeywords.every((k: KeywordData) => pickedIds.has(k.id));
    };

    const toggleBoardSelection = (id: string) => {
        if (lockedBoardIds.includes(id)) return;
        const isExhausted = isBoardExhausted(id);

        if (isExhausted && !selectedBoardIds.includes(id)) {
            const currentClicks = (exhaustedClickCounts[id] || 0) + 1;
            if (currentClicks < 3) {
                setExhaustedClickCounts(prev => ({ ...prev, [id]: currentClicks }));
                return;
            }
            // If it reaches 3, reset count and allow toggle
            setExhaustedClickCounts(prev => {
                const next = { ...prev };
                delete next[id];
                return next;
            });
        }

        setSelectedBoardIds(prev =>
            prev.includes(id) ? prev.filter(bid => bid !== id) : [...prev, id]
        );
    };

    const handleGenerate = (forceRepeat = false) => {
        if (selectedBoardIds.length === 0) return;

        // Check for exhausted boards
        const exhausted = selectedBoardIds.filter(id => isBoardExhausted(id));
        if (exhausted.length > 0 && !forceRepeat) {
            setPendingExhaustedBoards(exhausted);
            setShowRepeatModal(true);
            return;
        }

        setShowRepeatModal(false);
        setIsGenerating(true);

        // Short delay for effect
        setTimeout(() => {
            const finalMix: { boardLabel: string, parentLabel?: string, keywords: GeneratedMixKeyword[] }[] = [];
            const newPickedIds = new Set(pickedIds);

            const keywordsPerBoard = Math.floor(targetCount / selectedBoardIds.length);
            const extraKeywords = targetCount % selectedBoardIds.length;

            selectedBoardIds.forEach((boardId, index) => {
                const countNeeded = keywordsPerBoard + (index < extraKeywords ? 1 : 0);
                if (countNeeded === 0) return;

                const boardInfo = BOARD_DISPLAY_INFO.find(b => b.id === boardId);
                const boardKeywordNames = getEffectiveBoardKeywordNames(boardId);

                // Get keywords for this board that HAVEN'T been picked before
                let availableKeywords = allKeywords
                    .filter(k => boardKeywordNames.includes(k.name))
                    .filter(k => !newPickedIds.has(k.id));

                // If we ran out of new keywords for this board, wrap around or just take what's left
                if (availableKeywords.length < countNeeded) {
                    // Reset picked IDs for THIS EXACT BOARD if we are forcing repeat or exhausted
                    // Actually, let's just pick from all keywords of this board again
                    const allBoardKeywords = allKeywords.filter(k => boardKeywordNames.includes(k.name));
                    availableKeywords = allBoardKeywords.sort(() => 0.5 - Math.random());
                }

                // Shuffle and pick
                const pickedForThisBoard = availableKeywords
                    .sort(() => 0.5 - Math.random())
                    .slice(0, countNeeded)
                    .map(k => {
                        newPickedIds.add(k.id);
                        return {
                            id: k.id,
                            name: k.name,
                            volume: k.volume,
                            boardLabel: boardInfo?.label || 'Unknown Board'
                        };
                    });

                if (pickedForThisBoard.length > 0) {
                    finalMix.push({
                        boardLabel: boardInfo?.label || 'Unknown Board',
                        keywords: pickedForThisBoard,
                        parentLabel: boardInfo?.parentId ? BOARD_DISPLAY_INFO.find(b => b.id === boardInfo.parentId)?.label : undefined
                    });
                }
            });

            onSaveHistory(finalMix.map(group => ({
                boardLabel: group.parentLabel ? `${group.parentLabel} - ${group.boardLabel}` : group.boardLabel,
                keywords: group.keywords.map(k => ({ name: k.name, volume: k.volume, id: k.id }))
            })));
            setGeneratedMix(finalMix);
            onAction?.('mix', `${selectedBoardIds.length} Boards`);
            setIsGenerating(false);
            setShowRepeatModal(false);

            // Auto reset shuffle when generating new mix if desired, but let's keep it sticky
        }, 800);
    };

    const handleLockToggle = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (lockedBoardIds.includes(id)) {
            const clicks = (unlockClickCounts[id] || 0) + 1;
            if (clicks >= 3) {
                setLockedBoardIds(prev => prev.filter(bid => bid !== id));
                setUnlockClickCounts(prev => {
                    const next = { ...prev };
                    delete next[id];
                    return next;
                });
            } else {
                setUnlockClickCounts(prev => ({ ...prev, [id]: clicks }));
            }
        } else {
            setLockedBoardIds(prev => [...prev, id]);
            // Auto-unselect when locking
            setSelectedBoardIds(prev => prev.filter(bid => bid !== id));
        }
    };

    const copyToClipboard = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopyStatus(id);
        // User requested long timeout (10-30 mins), setting to 10 mins (600,000ms)
        setTimeout(() => setCopyStatus(null), 600000);
    };

    const copyAll = () => {
        let text = '';
        if (isShuffling) {
            text = getInterleavedKeywords().map(k => k.name).join('\n');
        } else {
            text = generatedMix
                .flatMap(group => group.keywords.map(k => k.name))
                .join('\n');
        }
        copyToClipboard(text, 'all');
    };

    const copyAllWithPrompt = () => {
        let keywordsText = '';
        if (isShuffling) {
            keywordsText = getInterleavedKeywords().map(k => k.name).join('\n');
        } else {
            keywordsText = generatedMix
                .flatMap(group => group.keywords.map(k => k.name))
                .join('\n');
        }

        const promptText = `I have a Pinterest board called "XYZ". Based on the following list of keywords, create a table with new article ideas, ideally listicles (for example 14 XYZ ideas ). Give me article title in one column and target keyword in the other column. ( “The title must be created using exactly the given number of target keywords; any deviation is not acceptable.”) HERE IS THE KEYWORD LIST - \n\n${keywordsText}`;

        copyToClipboard(promptText, 'prompt');
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <div className="space-y-4">
                    <h1 className={`text-4xl font-black tracking-tighter ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Keyword List Generator
                    </h1>
                    <div className="flex flex-wrap items-center gap-3">
                        <button
                            onClick={() => setShowStatsModal(true)}
                            className={`px-3 py-1.5 rounded-xl border-2 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-sm transition-all hover:scale-105 active:scale-95 group/stat ${isDarkMode ? 'bg-white/5 border-white/5 text-white/50 hover:border-red-500/30' : 'bg-white border-gray-100 text-gray-500 hover:border-red-500/30 hover:text-red-600'}`}
                            title="View Mixing Activity"
                        >
                            <span className="w-2 h-2 rounded-full bg-red-600 shadow-[0_0_8px_rgba(220,38,38,0.5)] group-hover/stat:animate-pulse" />
                            Generated: {pickedIds.size}
                            <svg className="w-3 h-3 opacity-0 group-hover/stat:opacity-100 transition-opacity ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                        <div className={`px-3 py-1.5 rounded-xl border-2 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-sm ${isDarkMode ? 'bg-white/5 border-white/5 text-white/50' : 'bg-white border-gray-100 text-gray-500'}`}>
                            <span className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                            Boards: {BOARD_DISPLAY_INFO.length}
                        </div>
                        <div className={`px-3 py-1.5 rounded-xl border-2 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-sm ${isDarkMode ? 'bg-white/5 border-white/5 text-white/50' : 'bg-white border-gray-100 text-gray-500'}`}>
                            <span className="w-2 h-2 rounded-full bg-gray-200" />
                            Inventory: {Object.values(BOARD_DATA).flat().length}
                        </div>

                        <div className="h-6 w-[1px] bg-gray-100 dark:bg-white/10 mx-2" />

                        <button
                            onClick={() => setShowLocked(!showLocked)}
                            className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all group/lock ${showLocked
                                ? (isDarkMode ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-red-50 border-red-100 text-red-600 shadow-sm')
                                : (isDarkMode ? 'bg-white/5 border-white/5 text-white/20 hover:text-white/40' : 'bg-white border-gray-100 text-gray-300 hover:text-gray-500 hover:border-gray-200 shadow-sm')
                                }`}
                            title={showLocked ? "Hide Locked Boards List" : "Show Locked Boards List"}
                        >
                            <div className="relative">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                                {lockedBoardIds.length > 0 && (
                                    <span className="absolute -top-2 -right-2 w-4 h-4 bg-red-600 text-white text-[8px] font-black rounded-full flex items-center justify-center ring-2 ring-white dark:ring-gray-900 animate-in zoom-in duration-300">
                                        {lockedBoardIds.length}
                                    </span>
                                )}
                            </div>
                        </button>

                        <button
                            onClick={() => setHideExhausted(!hideExhausted)}
                            className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center transition-all group/filter ${hideExhausted
                                ? (isDarkMode ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-red-50 border-red-100 text-red-600 shadow-sm')
                                : (isDarkMode ? 'bg-white/5 border-white/5 text-white/20 hover:text-white/40' : 'bg-white border-gray-100 text-gray-300 hover:text-gray-500 hover:border-gray-200 shadow-sm')
                                }`}
                            title={hideExhausted ? "Showing Fresh Keywords Only" : "Hide Used Keywords"}
                        >
                            <svg className={`w-4 h-4 transition-transform duration-500 ${hideExhausted ? 'rotate-90' : 'group-hover/filter:rotate-45'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </button>

                        <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Count:</span>
                            <input
                                type="number"
                                min="1"
                                max="100"
                                value={targetCount}
                                onChange={(e) => setTargetCount(Math.max(1, parseInt(e.target.value) || 1))}
                                className={`w-16 px-3 py-1.5 rounded-xl border-2 text-[10px] font-black focus:outline-none focus:border-red-600 transition-all ${isDarkMode ? 'bg-white/5 border-white/5 text-white' : 'bg-white border-gray-100 text-gray-900 shadow-sm'
                                    }`}
                            />
                        </div>
                    </div>
                </div>

                <button
                    onClick={() => handleGenerate(false)}
                    disabled={selectedBoardIds.length === 0 || isGenerating}
                    className={`px-8 py-3 rounded-xl text-sm font-black uppercase tracking-widest transition-all transform active:scale-95 shadow-lg ${selectedBoardIds.length === 0 || isGenerating
                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                        : 'bg-red-600 text-white shadow-red-100 hover:bg-red-700'
                        }`}
                >
                    {isGenerating ? (
                        <div className="flex items-center gap-2">
                            <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            Mixing...
                        </div>
                    ) : `Generate Mix (${targetCount})`}
                </button>
            </div>

            {/* Locked Boards Section */}
            {showLocked && lockedBoardIds.length > 0 && (
                <div className="space-y-4 animate-in slide-in-from-top-4 duration-500">
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                            <svg className="w-4 h-4 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                            <h3 className={`text-xs font-black uppercase tracking-widest ${isDarkMode ? 'text-white/60' : 'text-gray-500'}`}>Locked Boards</h3>
                        </div>
                        <div className="h-[1px] flex-1 bg-gray-100 dark:bg-white/5" />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
                        {BOARD_DISPLAY_INFO.filter(b => lockedBoardIds.includes(b.id) && getEffectiveBoardKeywordNames(b.id).length > 0).map(board => {
                            const boardKeywordNames = getEffectiveBoardKeywordNames(board.id);
                            const keywordsInBoard = allKeywords.filter((k: KeywordData) => boardKeywordNames.includes(k.name));
                            const totalCount = keywordsInBoard.length;
                            const pickedInBoard = keywordsInBoard.filter((k: KeywordData) => pickedIds.has(k.id)).length;
                            const remainingCount = Math.max(0, totalCount - pickedInBoard);

                            return (
                                <div key={board.id} className="relative h-[80px]">
                                    <div
                                        className={`flex items-center gap-2.5 p-3 rounded-2xl border-2 border-dashed transition-all text-left group absolute inset-0 z-10 grayscale opacity-40 duration-500 ${isDarkMode ? 'bg-white/5 border-white/10 text-white/40' : 'bg-gray-50 border-gray-200 text-gray-500 shadow-inner'}`}
                                    >
                                        <span className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-xl text-lg bg-white/5`}>
                                            {board.icon}
                                        </span>
                                        <div className="flex flex-col flex-1 min-w-0">
                                            <span className="text-[10px] font-black uppercase tracking-tight truncate">
                                                {board.label}
                                            </span>
                                            <div className="flex items-center gap-2 mt-1 opacity-60">
                                                <span className="text-[7px] font-extrabold uppercase text-gray-400">
                                                    U:{pickedInBoard}
                                                </span>
                                                <div className="w-[3px] h-[3px] rounded-full bg-gray-200" />
                                                <span className="text-[7px] font-extrabold uppercase text-gray-400">
                                                    L:{remainingCount}
                                                </span>
                                            </div>
                                            {board.parentId && (
                                                <span className="text-[7px] font-black uppercase tracking-tight text-gray-400 mt-1 truncate">
                                                    {BOARD_DISPLAY_INFO.find(b => b.id === board.parentId)?.label}
                                                </span>
                                            )}
                                        </div>

                                        <button
                                            onClick={(e) => handleLockToggle(e, board.id)}
                                            className="absolute top-2 left-2 w-5 h-5 rounded-lg flex items-center justify-center transition-all z-20 bg-red-600 text-white shadow-lg opacity-0 group-hover:opacity-100"
                                            title="Unlock (3 clicks to unlock)"
                                        >
                                            <div className="relative">
                                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                                </svg>
                                                {(unlockClickCounts[board.id] || 0) > 0 && (
                                                    <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-0.5">
                                                        {[...Array(3)].map((_, i) => (
                                                            <div key={i} className={`w-1 h-1 rounded-full ${i < unlockClickCounts[board.id] ? 'bg-white' : 'bg-white/30'}`} />
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Board Selection Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
                {BOARD_DISPLAY_INFO.filter(b => (!hideExhausted || !isBoardExhausted(b.id)) && !lockedBoardIds.includes(b.id) && getEffectiveBoardKeywordNames(b.id).length > 0).map(board => {
                    const isSelected = selectedBoardIds.includes(board.id);
                    const boardKeywordNames = getEffectiveBoardKeywordNames(board.id);
                    const keywordsInBoard = allKeywords.filter((k: KeywordData) => boardKeywordNames.includes(k.name));
                    const totalCount = keywordsInBoard.length;
                    const pickedInBoard = keywordsInBoard.filter((k: KeywordData) => pickedIds.has(k.id)).length;
                    const remainingCount = Math.max(0, totalCount - pickedInBoard);

                    const familyColorClass = getBoardFamilyColor(board.id);
                    const isExhausted = isBoardExhausted(board.id);
                    const clickCount = exhaustedClickCounts[board.id] || 0;

                    return (
                        <div key={board.id} className="relative h-[80px]"> {/* Fixed height container to prevent layout bounce */}
                            <button
                                onClick={() => toggleBoardSelection(board.id)}
                                onDoubleClick={() => onTabChange?.(board.id)}
                                className={`flex items-center gap-2.5 p-3 rounded-2xl border-2 transition-all text-left group absolute inset-0 z-10 duration-500 active:scale-95 ${lockedBoardIds.includes(board.id)
                                    ? 'grayscale opacity-30 cursor-not-allowed border-dashed bg-gray-50/10'
                                    : `hover:scale-[1.6] hover:z-50 hover:shadow-[0_20px_50px_rgba(220,38,38,0.2)] dark:hover:shadow-[0_20px_50px_rgba(0,0,0,0.5)] ${isSelected
                                        ? 'bg-red-50 border-red-200 text-red-700 shadow-md ring-1 ring-red-100'
                                        : familyColorClass || (isDarkMode
                                            ? 'bg-white/5 border-white/5 text-white/40 hover:border-red-500/50 hover:text-white hover:bg-[#1a1a20]'
                                            : 'bg-white border-gray-100 text-gray-500 hover:border-red-400 hover:text-gray-900 shadow-sm')
                                    }`
                                    } ${isExhausted && !isSelected ? 'grayscale opacity-40 shadow-inner scale-90' : ''}`}
                                title={`${board.label}${onTabChange ? ' (Double-click to view board)' : ''}`}
                            >
                                <span className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-xl text-lg transition-all group-hover:scale-110 ${isSelected ? 'bg-red-100' : isDarkMode ? 'bg-white/5' : 'bg-gray-50'
                                    }`}>
                                    {board.icon}
                                </span>
                                <div className="flex flex-col flex-1 min-w-0 transition-all">
                                    <span className="text-[10px] font-black uppercase tracking-tight leading-loose truncate group-hover:whitespace-normal group-hover:overflow-visible group-hover:leading-tight transition-all">
                                        {board.label}
                                    </span>
                                    <div className="flex items-center gap-2 mt-1 opacity-60 group-hover:opacity-100 transition-opacity">
                                        <span className={`text-[7px] font-extrabold uppercase ${isSelected ? 'text-red-600/80' : 'text-gray-400 group-hover:text-red-600/80'}`}>
                                            U:{pickedInBoard}
                                        </span>
                                        <div className="w-[3px] h-[3px] rounded-full bg-gray-200 group-hover:bg-red-200" />
                                        <span className={`text-[7px] font-extrabold uppercase ${isSelected ? 'text-red-600/80' : 'text-gray-400 group-hover:text-red-600/80'}`}>
                                            L:{remainingCount}
                                        </span>
                                    </div>
                                    {board.parentId && (
                                        <span className={`text-[7px] font-black uppercase tracking-tight mt-1 truncate group-hover:whitespace-normal transition-all ${isSelected ? 'text-red-600/40' : 'text-gray-400 group-hover:text-red-600/80'}`}>
                                            {BOARD_DISPLAY_INFO.find(b => b.id === board.parentId)?.label}
                                        </span>
                                    )}
                                </div>

                                {isSelected && (
                                    <button
                                        onClick={(e) => handleLockToggle(e, board.id)}
                                        className={`absolute top-2 left-2 w-5 h-5 rounded-lg flex items-center justify-center transition-all z-20 opacity-0 group-hover:opacity-100 ${lockedBoardIds.includes(board.id)
                                            ? 'bg-red-600 text-white shadow-lg'
                                            : isDarkMode ? 'bg-white/5 text-white/20 hover:text-white' : 'bg-gray-100 text-gray-400 hover:text-red-600'
                                            }`}
                                        title={lockedBoardIds.includes(board.id) ? "Locked (3 clicks to unlock)" : "Lock Board"}
                                    >
                                        {lockedBoardIds.includes(board.id) ? (
                                            <div className="relative">
                                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                                </svg>
                                                {(unlockClickCounts[board.id] || 0) > 0 && (
                                                    <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-0.5">
                                                        {[...Array(3)].map((_, i) => (
                                                            <div key={i} className={`w-1 h-1 rounded-full ${i < unlockClickCounts[board.id] ? 'bg-white' : 'bg-white/30'}`} />
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        ) : (
                                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M8 11V7a4 4 0 118 0v4m0 0a2 2 0 100 4m0-4v4m-8-4a2 2 0 110 4m0-4v4m4 0v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" />
                                            </svg>
                                        )}
                                    </button>
                                )}

                                {/* Exhausted Click Feedback */}
                                {isExhausted && !isSelected && clickCount > 0 && (
                                    <div className="absolute inset-0 bg-gray-900/10 flex items-center justify-center backdrop-blur-[1px] rounded-2xl">
                                        <div className="flex gap-0.5">
                                            {[...Array(3)].map((_, i) => (
                                                <div key={i} className={`w-1.5 h-1.5 rounded-full ${i < clickCount ? 'bg-red-600' : 'bg-white/50'}`} />
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {isSelected && (
                                    <div className="absolute top-1 right-1 w-3 h-3 rounded-full bg-red-600 flex items-center justify-center shadow-sm">
                                        <svg className="w-1.5 h-1.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={5} d="M5 13l4 4L19 7" />
                                        </svg>
                                    </div>
                                )}
                            </button>
                        </div>
                    );
                })}
            </div>

            {/* Mix Results */}
            {generatedMix.length > 0 && (
                <div className="mt-12 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                            <h2 className={`text-xl font-extrabold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Latest Generation</h2>
                            <div className="h-0.5 flex-1 bg-gray-100 dark:bg-white/5 rounded-full" />
                        </div>
                        <div className="flex items-center gap-2">
                            <button
                                onClick={() => setIsShuffling(!isShuffling)}
                                className={`p-2 rounded-lg transition-all ${isShuffling
                                    ? 'bg-red-500 text-white shadow-lg animate-spin-slow'
                                    : isDarkMode ? 'bg-white/5 text-white/40 hover:text-white' : 'bg-white border border-gray-100 text-gray-400 hover:text-red-600'
                                    }`}
                                title={isShuffling ? "Shuffle ON (Interleaved)" : "Shuffle OFF (Grouped by Board)"}
                            >
                                <svg className={`w-4 h-4 ${isShuffling ? 'animate-[spin_4s_linear_infinite]' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                            </button>
                            <button
                                onClick={copyAll}
                                className="flex items-center gap-2 px-3 py-1.5 bg-gray-900 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-gray-800 transition-all active:scale-95 shadow-lg scale-90"
                            >
                                {copyStatus === 'all' ? 'Copied!' : (
                                    <>
                                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                                        </svg>
                                        Copy All
                                    </>
                                )}
                            </button>
                            <button
                                onClick={copyAllWithPrompt}
                                className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all active:scale-95 shadow-lg"
                            >
                                {copyStatus === 'prompt' ? 'Copied Prompt!' : (
                                    <>
                                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                        Copy with Prompt
                                    </>
                                )}
                            </button>
                        </div>
                    </div>

                    <div className={`rounded-[2.5rem] border overflow-hidden ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white border-gray-200 shadow-2xl'}`}>
                        <div className="p-8">
                            {isShuffling ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-2">
                                    {getInterleavedKeywords().map((kw) => (
                                        <div
                                            key={kw.id}
                                            className={`flex items-center justify-between p-3 rounded-2xl transition-all group/item ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-red-50/30'}`}
                                        >
                                            <div className="flex items-center gap-3">
                                                <div className="w-6 h-6 rounded-full bg-green-500/10 flex items-center justify-center text-green-600">
                                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                                                    </svg>
                                                </div>
                                                <span className={`text-xs font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{kw.name}</span>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <span className="text-[10px] font-black text-red-600/30 uppercase tracking-widest">{kw.volume.toLocaleString()}</span>
                                                <button
                                                    onClick={() => copyToClipboard(kw.name, kw.id)}
                                                    className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover/item:opacity-100"
                                                    title="Copy Keyword"
                                                >
                                                    {copyStatus === kw.id ? (
                                                        <span className="text-[9px] font-black text-red-600">Copied</span>
                                                    ) : (
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                        </svg>
                                                    )}
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                    {generatedMix.map((group, gIdx) => (
                                        <div key={gIdx} className="space-y-4">
                                            <div className={`text-[10px] font-black uppercase tracking-[0.2em] pb-2 border-b-2 flex flex-col gap-1 ${isDarkMode ? 'border-red-500/30 text-red-400' : 'border-red-100 text-red-600'}`}>
                                                {group.parentLabel && <span className="opacity-40 text-[8px]">{group.parentLabel}</span>}
                                                <span>{group.boardLabel}</span>
                                            </div>
                                            <div className="space-y-2">
                                                {group.keywords.map((kw, _) => (
                                                    <div
                                                        key={kw.id}
                                                        className={`flex items-center justify-between p-3 rounded-2xl transition-all group/item ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-red-50/30'}`}
                                                    >
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-6 h-6 rounded-full bg-green-500/10 flex items-center justify-center text-green-600">
                                                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                                                                </svg>
                                                            </div>
                                                            <span className={`text-xs font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{kw.name}</span>
                                                        </div>
                                                        <div className="flex items-center gap-4">
                                                            <span className="text-[10px] font-black text-red-600/30 uppercase tracking-widest">{kw.volume.toLocaleString()}</span>
                                                            <button
                                                                onClick={() => copyToClipboard(kw.name, kw.id)}
                                                                className="p-2 text-gray-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover/item:opacity-100"
                                                                title="Copy Keyword"
                                                            >
                                                                {copyStatus === kw.id ? (
                                                                    <span className="text-[9px] font-black text-red-600">Copied</span>
                                                                ) : (
                                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                                    </svg>
                                                                )}
                                                            </button>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* History Section */}
            {history.length > 0 && (
                <div className="mt-16 space-y-6">
                    <div className="flex items-center gap-4">
                        <h2 className={`text-xl font-extrabold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>History</h2>
                        <div className="h-0.5 flex-1 bg-gray-100 dark:bg-white/5 rounded-full" />
                    </div>
                    <div className="space-y-6">
                        {history.map((entry, idx) => {
                            const isExpanded = expandedHistoryIndex === idx;
                            return (
                                <div
                                    key={idx}
                                    className={`overflow-hidden rounded-3xl border transition-all ${isDarkMode ? 'bg-[#1a1a20] border-white/5' : 'bg-white border-gray-100 shadow-sm'
                                        } ${isExpanded ? 'ring-2 ring-red-600/20' : ''}`}
                                >
                                    <button
                                        onClick={() => setExpandedHistoryIndex(isExpanded ? null : idx)}
                                        className={`w-full px-6 py-4 flex items-center justify-between transition-colors ${isExpanded ? (isDarkMode ? 'bg-white/5' : 'bg-red-50/50') : (isDarkMode ? 'hover:bg-white/5' : 'hover:bg-gray-50/50')}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className={`w-2 h-2 rounded-full bg-red-600 ${isExpanded ? 'animate-pulse' : 'opacity-40'}`} />
                                            <span className="text-[11px] font-black text-gray-900 dark:text-white uppercase tracking-[0.1em]">
                                                {entry.date} {entry.userName ? <span className="text-red-600 ml-1">By {entry.userName}</span> : ''}
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const allText = entry.mix.flatMap(g => g.keywords.map(k => k.name)).join('\n');
                                                    copyToClipboard(allText, `hist-all-${idx}`);
                                                }}
                                                className={`p-2 rounded-xl transition-all ${isDarkMode ? 'hover:bg-white/10 text-white/40' : 'hover:bg-red-100 text-red-600'}`}
                                                title="Copy All Keywords"
                                            >
                                                {copyStatus === `hist-all-${idx}` ? <span className="text-[8px] font-black">Copied</span> : (
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                    </svg>
                                                )}
                                            </button>
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const keywordsText = entry.mix.flatMap(g => g.keywords.map(k => k.name)).join('\n');
                                                    const promptText = `I have a Pinterest board called "XYZ". Based on the following list of keywords, create a table with new article ideas, ideally listicles (for example 14 XYZ ideas ). Give me article title in one column and target keyword in the other column. ( “The title must be created using exactly the given number of target keywords; any deviation is not acceptable.”) HERE IS THE KEYWORD LIST - \n\n${keywordsText}`;
                                                    copyToClipboard(promptText, `hist-prompt-${idx}`);
                                                }}
                                                className={`p-2 rounded-xl transition-all ${isDarkMode ? 'hover:bg-emerald-500/20 text-emerald-400' : 'hover:bg-emerald-50 text-emerald-600'}`}
                                                title="Copy with Prompt"
                                            >
                                                {copyStatus === `hist-prompt-${idx}` ? <span className="text-[8px] font-black">Copied!</span> : (
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                    </svg>
                                                )}
                                            </button>
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    if (window.confirm('Delete this mix history?')) {
                                                        onDeleteHistory(idx);
                                                    }
                                                }}
                                                className={`p-2 rounded-xl transition-all ${isDarkMode ? 'hover:bg-red-500/20 text-red-400' : 'hover:bg-red-100 text-red-600'}`}
                                                title="Delete History"
                                            >
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </button>
                                            <div className="w-[1px] h-4 bg-gray-100 dark:bg-white/10 mx-1" />
                                            <span className="text-[10px] font-black text-red-600 uppercase tracking-widest bg-red-50 dark:bg-red-900/20 px-3 py-1 rounded-full mr-2">
                                                {entry.mix.reduce((acc, curr) => acc + curr.keywords.length, 0)} Keywords Total
                                            </span>
                                            <svg
                                                className={`w-4 h-4 text-gray-400 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                            >
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" />
                                            </svg>
                                        </div>
                                    </button>

                                    {isExpanded && (
                                        <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 border-t border-gray-100 dark:border-white/5 animate-in slide-in-from-top-2 duration-300">
                                            {entry.mix.map((group, gIdx) => (
                                                <div key={gIdx} className="space-y-3">
                                                    <h4 className="text-[11px] font-black text-red-800 dark:text-red-500 uppercase tracking-[0.15em] flex items-center gap-2">
                                                        <span className="w-1 h-1 rounded-full bg-red-800 dark:bg-red-500" />
                                                        {group.boardLabel}
                                                    </h4>
                                                    <ul className="space-y-2">
                                                        {group.keywords.map((kw, kIdx) => (
                                                            <li key={kIdx} className="flex items-center justify-between group/hist">
                                                                <div className="flex items-center gap-2 min-w-0">
                                                                    <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                                                                    <span className={`text-[10px] font-bold truncate ${isDarkMode ? 'text-white/60' : 'text-gray-600'}`}>{kw.name}</span>
                                                                </div>
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        copyToClipboard(kw.name, `hist-${idx}-${gIdx}-${kIdx}`);
                                                                    }}
                                                                    className="text-gray-300 hover:text-red-600 opacity-0 group-hover/hist:opacity-100 transition-all p-1"
                                                                >
                                                                    {copyStatus === `hist-${idx}-${gIdx}-${kIdx}` ? (
                                                                        <span className="text-[7px] font-black">✓</span>
                                                                    ) : (
                                                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2" />
                                                                        </svg>
                                                                    )}
                                                                </button>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Repeat Confirmation Modal */}
            {showRepeatModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
                    <div className="bg-white dark:bg-gray-900 w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/10 p-8 text-center space-y-6">
                        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto text-3xl">
                            ♻️
                        </div>
                        <div className="space-y-2">
                            <h3 className="text-xl font-black text-gray-900 dark:text-white">Repeat Keywords?</h3>
                            <div className="text-xs font-bold text-gray-500 uppercase tracking-widest leading-relaxed">
                                You've already used all keywords from:
                                <div className="flex flex-wrap justify-center gap-1 mt-2">
                                    {pendingExhaustedBoards.map(id => (
                                        <span key={id} className="bg-red-50 text-red-600 px-2 py-1 rounded-md text-[8px]">
                                            {BOARD_DISPLAY_INFO.find(b => b.id === id)?.label}
                                        </span>
                                    ))}
                                </div>
                                <p className="mt-4">Do you want to repeat them?</p>
                            </div>
                        </div>
                        <div className="flex gap-3 pt-2">
                            <button
                                onClick={() => setShowRepeatModal(false)}
                                className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-gray-200 transition-all active:scale-95"
                            >
                                No
                            </button>
                            <button
                                onDoubleClick={() => handleGenerate(true)}
                                className="flex-1 py-4 bg-red-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-red-700 transition-all active:scale-95 shadow-lg shadow-red-100"
                            >
                                <div className="opacity-40 text-[7px] mb-1 font-black">Double Click To Pick</div>
                                Yes, Repeat
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Activity Stats Modal */}
            {showStatsModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-white dark:bg-[#0f0f13] w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-white/10 flex flex-col h-[80vh] animate-in slide-in-from-bottom-8 duration-500 focus:outline-none">
                        {/* Modal Header */}
                        <div className="p-6 border-b border-gray-100 dark:border-white/5 flex items-center justify-between bg-white dark:bg-[#0f0f13]">
                            <div>
                                <h3 className="text-lg font-black text-gray-900 dark:text-white uppercase tracking-tighter">Mixing Activity</h3>
                                <div className="flex items-center gap-2 mt-0.5">
                                    <span className="w-1 h-1 rounded-full bg-red-600" />
                                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-[0.2em]">Session logs & data</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <button
                                    onClick={() => setShowStatsModal(false)}
                                    className="w-8 h-8 rounded-lg bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400 hover:text-gray-900 transition-colors"
                                >
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        {/* Modal Content */}
                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                            {/* Summary Cards */}
                            <div className="grid grid-cols-2 gap-3">
                                <div className="p-4 rounded-xl border border-gray-100 dark:border-white/5 bg-gray-50/30 dark:bg-white/5">
                                    <div className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Unique Keywords</div>
                                    <div className="text-xl font-black text-gray-900 dark:text-white">{pickedIds.size}</div>
                                </div>
                                <div className="p-4 rounded-xl border border-gray-100 dark:border-white/5 bg-gray-50/30 dark:bg-white/5">
                                    <div className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Total Records</div>
                                    <div className="text-xl font-black text-gray-900 dark:text-white">{history.length}</div>
                                </div>
                            </div>

                            {/* Daily Log */}
                            <div className="space-y-1">
                                <div className="flex items-center justify-between px-1 mb-2">
                                    <h4 className="text-[8px] font-black text-gray-400 uppercase tracking-[0.2em]">Activity Log</h4>
                                    <div className="h-[1px] flex-1 bg-gray-100 dark:bg-white/5 mx-3" />
                                </div>

                                {Object.entries(
                                    history.reduce((acc, entry) => {
                                        const dateKey = entry.date.split(',')[0].trim();
                                        const count = entry.mix.reduce((sum, g) => sum + g.keywords.length, 0);
                                        acc[dateKey] = (acc[dateKey] || 0) + count;
                                        return acc;
                                    }, {} as Record<string, number>)
                                )
                                    .sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime())
                                    .map(([date, count]) => (
                                        <div
                                            key={date}
                                            className="flex items-center justify-between p-4 bg-white dark:bg-[#1a1a20] border-b border-gray-50 dark:border-white/5 hover:bg-gray-50 dark:hover:bg-white/5 transition-all group/row"
                                        >
                                            <div className="flex flex-col">
                                                <div className="text-[10px] font-black text-gray-900 dark:text-white uppercase tracking-tight">{date}</div>
                                                <div className="text-[7px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">Keywords processed</div>
                                            </div>
                                            <div className="text-[10px] font-black text-red-600 bg-red-50 dark:bg-red-500/10 px-2 py-1 rounded-md">
                                                +{count}
                                            </div>
                                        </div>
                                    ))}

                                {history.length === 0 && (
                                    <div className="py-20 text-center space-y-4">
                                        <div className="text-4xl opacity-20">📊</div>
                                        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">No activity recorded yet</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Modal Footer */}
                        <div className="p-6 border-t border-gray-100 dark:border-white/5 bg-gray-50/30 dark:bg-[#0f0f13] text-center">
                            <p className="text-[7px] font-black text-gray-400 tracking-[0.3em] uppercase">
                                PIN DATA • LOCAL ENCRYPTED STORAGE
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Mixer;
