
import React, { useState } from 'react';
import { SESSION_KEY } from '../constants';

interface LoginModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLoginSuccess: (user: { name: string; email: string }) => void;
    isDarkMode?: boolean;
}

const LoginModal: React.FC<LoginModalProps> = ({
    isOpen,
    onClose,
    onLoginSuccess,
    isDarkMode
}) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        // Mock authentication
        setTimeout(() => {


            if (email && password) {
                const user = {
                    name: email.split('@')[0],
                    email: email,
                    password: password
                };
                localStorage.setItem(SESSION_KEY, JSON.stringify(user));
                onLoginSuccess(user);
                onClose();
                setIsLoading(false);
            } else {

                setError('Please enter valid credentials.');
                setIsLoading(false);
            }
        }, 1000);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
            <div
                className={`w-full max-w-md p-8 rounded-[2rem] shadow-2xl transform transition-all scale-100 ${isDarkMode ? 'bg-[#1a1a20] border border-white/10' : 'bg-white'
                    }`}
                onClick={(e) => e.stopPropagation()}
            >
                <div className="text-center mb-8 relative">
                    <button
                        onClick={onClose}
                        className={`absolute -right-4 -top-4 p-2 rounded-full transition-colors ${isDarkMode ? 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white' : 'bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-600'
                            }`}
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>

                    <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-red-200">
                        <span className="text-white text-xl font-black italic">P</span>
                    </div>
                    <h2 className={`text-2xl font-black tracking-tight mb-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Welcome Back
                    </h2>
                    <p className={`text-xs font-bold uppercase tracking-widest ${isDarkMode ? 'text-white/40' : 'text-gray-400'}`}>
                        Sign in to access your saved keywords
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className={`block text-[10px] font-black uppercase tracking-widest mb-1.5 ${isDarkMode ? 'text-white/60' : 'text-gray-500'}`}>
                            Email
                        </label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className={`w-full px-4 py-3 rounded-xl text-sm font-bold border-2 outline-none transition-all ${isDarkMode
                                ? 'bg-black/20 border-white/5 text-white focus:border-red-600/50'
                                : 'bg-gray-50 border-gray-100 text-gray-900 focus:border-red-200 focus:bg-white'
                                }`}
                            placeholder="name@example.com"
                            required
                        />
                    </div>

                    <div>
                        <label className={`block text-[10px] font-black uppercase tracking-widest mb-1.5 ${isDarkMode ? 'text-white/60' : 'text-gray-500'}`}>
                            Password
                        </label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className={`w-full px-4 py-3 rounded-xl text-sm font-bold border-2 outline-none transition-all ${isDarkMode
                                ? 'bg-black/20 border-white/5 text-white focus:border-red-600/50'
                                : 'bg-gray-50 border-gray-100 text-gray-900 focus:border-red-200 focus:bg-white'
                                }`}
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && (
                        <p className="text-xs font-bold text-red-500 bg-red-50 p-3 rounded-lg text-center animate-in fade-in slide-in-from-top-1">
                            {error}
                        </p>
                    )}

                    <button
                        type="submit"
                        disabled={isLoading}
                        className={`w-full py-3.5 rounded-xl text-xs font-black uppercase tracking-widest text-white shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2 ${isLoading ? 'opacity-70 cursor-not-allowed bg-gray-400' : 'bg-red-600 shadow-red-200 hover:bg-red-700 hover:shadow-red-300'
                            }`}
                    >
                        {isLoading && (
                            <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        )}
                        {isLoading ? 'Signing In...' : 'Sign In'}
                    </button>
                </form>

                <p className={`text-center text-[10px] font-bold mt-6 ${isDarkMode ? 'text-white/40' : 'text-gray-400'}`}>
                    Don't have an account? <span className="text-red-500 cursor-pointer hover:underline">Sign up</span>
                </p>
            </div>
        </div>
    );
};

export default LoginModal;
