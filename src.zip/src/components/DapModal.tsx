
import React from 'react';

interface DapModalProps {
    isOpen: boolean;
    onClose: () => void;
    isDarkMode?: boolean;
}

const DapModal: React.FC<DapModalProps> = ({ isOpen, onClose, isDarkMode }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200 p-4">
            <div
                className={`w-full max-w-2xl rounded-[2rem] shadow-2xl transform transition-all scale-100 overflow-hidden relative ${isDarkMode ? 'bg-[#1a1a20] border border-white/10' : 'bg-white'
                    }`}
                onClick={(e) => e.stopPropagation()}
            >
                <button
                    onClick={onClose}
                    className={`absolute top-4 right-4 p-2 rounded-full transition-colors z-10 ${isDarkMode ? 'bg-white/5 text-white/40 hover:bg-white/10 hover:text-white' : 'bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-600'
                        }`}
                >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>

                <div className="flex flex-col md:flex-row h-full">
                    {/* Left Side: Illustration / Brand */}
                    <div className="w-full md:w-1/3 bg-gradient-to-br from-red-600 via-red-700 to-rose-800 p-8 flex flex-col justify-between text-white relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-repeat" />

                        <div className="relative z-10">
                            <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center mb-6 border border-white/30 shadow-lg">
                                <span className="text-white text-xl font-black italic">D</span>
                            </div>
                            <h2 className="text-3xl font-black tracking-tighter leading-none mb-2">
                                Join the <br />Inner Circle
                            </h2>
                            <p className="text-xs font-bold text-red-100 uppercase tracking-widest opacity-80 leading-relaxed">
                                Unlock advanced data points, trend forecasting, and unlimited exports.
                            </p>
                        </div>

                        <div className="relative z-10 mt-12 space-y-3">
                            <div className="flex items-center gap-3 text-sm font-bold opacity-90">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                                <span>Live Trend Data</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm font-bold opacity-90">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                                <span>Bulk Export CSV</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm font-bold opacity-90">
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                                <span>API Access</span>
                            </div>
                        </div>
                    </div>

                    {/* Right Side: Content */}
                    <div className="w-full md:w-2/3 p-8 flex flex-col justify-center">

                        <div className="text-center space-y-6 max-w-sm mx-auto">
                            <div className={`p-4 rounded-xl border ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-red-50 border-red-100'}`}>
                                <h3 className={`text-sm font-black uppercase tracking-widest mb-1 ${isDarkMode ? 'text-white' : 'text-red-800'}`}>
                                    Early Access
                                </h3>
                                <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-red-400'}`}>
                                    We are currently in private beta.
                                </p>
                            </div>

                            <div className="space-y-3">
                                <input
                                    type="email"
                                    placeholder="Enter your email to join waitlist"
                                    className={`w-full px-4 py-3 rounded-xl text-sm font-bold border-2 outline-none transition-all ${isDarkMode
                                            ? 'bg-black/20 border-white/5 text-white focus:border-red-600/50'
                                            : 'bg-gray-50 border-gray-100 text-gray-900 focus:border-red-200 focus:bg-white'
                                        }`}
                                />
                                <button className="w-full py-3.5 bg-gray-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-gray-800 transition-all shadow-lg transform active:scale-95">
                                    Request Access
                                </button>
                            </div>

                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                                Limited spots available for Q1 2026
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DapModal;
