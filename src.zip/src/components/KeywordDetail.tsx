
import React, { useState } from 'react';
import type { KeywordData } from '../types';

interface KeywordDetailProps {
    keyword: KeywordData;
    onBack: () => void;
    isSaved?: boolean;
    onToggleSave?: (id: string) => void;
    isDarkMode?: boolean;
    boardName?: string;
    subBoardName?: string;
    onAction?: (action: string, data: string) => void;
    savedBy?: string;
}


const TAG_COLORS = [
    { bg: 'bg-rose-100', text: 'text-rose-800', border: 'border-rose-200' },
    { bg: 'bg-emerald-100', text: 'text-emerald-800', border: 'border-emerald-200' },
    { bg: 'bg-sky-100', text: 'text-sky-800', border: 'border-sky-200' },
    { bg: 'bg-amber-100', text: 'text-amber-800', border: 'border-amber-200' },
    { bg: 'bg-violet-100', text: 'text-violet-800', border: 'border-violet-200' },
    { bg: 'bg-orange-100', text: 'text-orange-800', border: 'border-orange-200' },
    { bg: 'bg-cyan-100', text: 'text-cyan-800', border: 'border-cyan-200' },
    { bg: 'bg-fuchsia-100', text: 'text-fuchsia-800', border: 'border-fuchsia-200' },
    { bg: 'bg-lime-100', text: 'text-lime-800', border: 'border-lime-200' },
    { bg: 'bg-indigo-100', text: 'text-indigo-800', border: 'border-indigo-200' },
    { bg: 'bg-teal-100', text: 'text-teal-800', border: 'border-teal-200' },
    { bg: 'bg-pink-100', text: 'text-pink-800', border: 'border-pink-200' },
];

const KeywordDetail: React.FC<KeywordDetailProps> = ({
    keyword,
    onBack,
    isSaved = false,
    onToggleSave,
    isDarkMode,
    boardName,
    subBoardName,
    onAction,
    savedBy
}) => {

    const [copyFeedback, setCopyFeedback] = useState<'none' | 'keyword' | 'interests'>('none');

    const formatNumber = (num: number) => new Intl.NumberFormat().format(num);

    const handleCopy = async (text: string, type: 'keyword' | 'interests') => {
        try {
            await navigator.clipboard.writeText(text);
            setCopyFeedback(type);
            onAction?.('copy', type === 'keyword' ? text : 'Related Keywords');
            setTimeout(() => setCopyFeedback('none'), 2000);
        } catch (err) {
            console.error('Failed to copy text: ', err);
        }
    };


    const getVolumeTextColor = (volume: number) => {
        if (volume < 5000) return 'text-green-600';
        if (volume <= 10000) return 'text-amber-600';
        return 'text-gray-900';
    };

    return (
        <div className={`p-1 transition-colors duration-300 ${isDarkMode ? 'bg-[#1a1a20]' : 'bg-white'}`}>
            <style>{`
        @keyframes redPulse {
          0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); transform: scale(1); }
          50% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); transform: scale(1.02); }
          100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); transform: scale(1); }
        }
        .animate-red-pulse { animation: redPulse 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94); }
        .copy-main-gradient {
          background: linear-gradient(135deg, #6b7280 0%, #374151 100%);
          background-size: 200% 200%;
          animation: gradientShift 3s ease infinite;
        }
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

            {/* Navigation */}
            <div className="flex items-center justify-between mb-6">
                <button
                    onClick={onBack}
                    className={`flex items-center gap-1.5 px-4 py-2 text-xs font-black rounded-lg transition-all ${isDarkMode ? 'bg-white/5 hover:bg-white/10 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-900'}`}
                >
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M15 19l-7-7 7-7" />
                    </svg>
                    Back
                </button>

                <div className="flex flex-col items-end gap-1">
                    <button
                        onClick={() => {
                            onToggleSave?.(keyword.id);
                            if (!isSaved) onAction?.('pin', keyword.name);
                        }}
                        title={isSaved ? 'Keyword is pinned' : `${keyword.relatedInterests.length} Related interests found`}
                        className={`inline-flex items-center justify-center gap-2 ${isSaved ? 'px-4' : 'w-10'} h-10 text-xs font-black rounded-lg transition-all shadow-sm border ${isSaved
                            ? 'bg-red-600 text-white border-red-700'
                            : keyword.relatedInterests.length <= 5
                                ? (isDarkMode ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-red-100 text-red-700 border-red-200')
                                : (isDarkMode ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-emerald-100 text-emerald-700 border-emerald-200')
                            }`}
                    >
                        {isSaved ? (
                            <>✨ Pinned</>
                        ) : (
                            <div className={`w-3.5 h-3.5 rounded-[4px] flex items-center justify-center transition-all ${keyword.relatedInterests.length <= 5
                                ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)] animate-pulse'
                                : 'bg-emerald-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]'
                                }`}>
                                {keyword.relatedInterests.length > 5 && (
                                    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                                    </svg>
                                )}
                            </div>
                        )}
                    </button>
                    {isSaved && savedBy && (
                        <span className="text-[10px] font-black text-red-600/60 uppercase tracking-widest">
                            By {savedBy}
                        </span>
                    )}
                </div>

            </div>

            <div className="space-y-6">
                <div className="flex items-center gap-4 flex-wrap">
                    <h1 className={`text-4xl font-black tracking-tighter leading-tight ${isDarkMode ? 'text-white' : 'text-black'}`}>
                        {keyword.name}
                    </h1>

                    <button
                        onClick={() => handleCopy(keyword.name, 'keyword')}
                        className={`group flex items-center gap-2 px-4 py-2 rounded-md transition-all shadow-md transform active:scale-95 ${copyFeedback === 'keyword'
                            ? 'bg-indigo-600 text-white animate-red-pulse'
                            : isDarkMode ? 'bg-indigo-900/30 border border-indigo-500/30 text-indigo-300 hover:bg-indigo-900/50' : 'bg-indigo-50 border border-indigo-100 text-indigo-700 hover:bg-indigo-100'
                            }`}
                    >
                        <span className="text-xs font-black uppercase tracking-widest flex items-center">
                            {copyFeedback === 'keyword' ? 'Copied!' : 'Copy'}
                            <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap opacity-0 group-hover:opacity-100">
                                &nbsp;Keyword
                            </span>
                        </span>
                    </button>
                </div>

                {/* Updated Stat Strip - Gray Background Bar */}
                <div className={`flex flex-wrap items-center gap-6 py-4 border rounded-xl px-6 ${isDarkMode ? 'bg-white/5 border-white/5' : 'border-transparent bg-gray-100'}`}>
                    <div className="flex gap-12 items-center">
                        <div>
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Volume</p>
                            <p className={`text-3xl font-black tracking-tighter tabular-nums ${getVolumeTextColor(keyword.volume)}`}>{formatNumber(keyword.volume)}</p>
                        </div>
                        <div className={`w-px h-10 self-center ${isDarkMode ? 'bg-white/10' : 'bg-gray-300'}`} />
                        <div>
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Reach</p>
                            <p className="text-3xl font-black text-gray-700 tracking-tighter tabular-nums">{formatNumber(keyword.followers)}</p>
                        </div>
                        {boardName && (
                            <>
                                <div className={`w-px h-10 self-center ${isDarkMode ? 'bg-white/10' : 'bg-gray-300'}`} />
                                <div className="flex flex-col">
                                    <div className="flex items-center gap-2">
                                        <div>
                                            <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-1">Board</p>
                                            <p className="text-lg font-bold text-red-600 tracking-normal leading-tight whitespace-nowrap">{boardName}</p>
                                        </div>
                                        {subBoardName && (
                                            <div className="pl-4 border-l border-gray-300 dark:border-white/10">
                                                <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Sub Board</p>
                                                <p className="text-sm font-bold text-blue-600 tracking-normal leading-tight whitespace-nowrap">{subBoardName}</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </>
                        )}
                    </div>

                    {/* Category Badge - replacing Breadcrumbs */}
                    <div className="ml-auto">
                        <span className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest ${isDarkMode ? 'bg-black/40 text-gray-400' : 'bg-white text-gray-500 shadow-sm border border-gray-200'}`}>
                            {keyword.category === 'deck-patio' ? 'Deck & Patio' :
                                keyword.category === 'living-room' ? 'Living Room' :
                                    keyword.category.charAt(0).toUpperCase() + keyword.category.slice(1)} / Trends
                        </span>
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="flex flex-col gap-4">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h3 className={`inline-flex items-center px-3 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-widest ${isDarkMode ? 'bg-white/10 text-gray-300' : 'bg-slate-100 text-slate-600'}`}>
                                    Related Interests
                                </h3>

                                <button
                                    onClick={() => handleCopy(keyword.relatedInterests.join(', '), 'interests')}
                                    className={`group flex items-center gap-2 px-4 py-2 rounded-md transition-all shadow-md text-xs font-black uppercase tracking-widest transform active:scale-95 ${copyFeedback === 'interests'
                                        ? 'bg-emerald-600 text-white border-emerald-600'
                                        : isDarkMode ? 'bg-emerald-900/30 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/50' : 'bg-emerald-50 border border-emerald-100 text-emerald-700 hover:bg-emerald-100'
                                        }`}
                                >
                                    <span className="flex items-center">
                                        {copyFeedback === 'interests' ? 'Copied!' : 'Copy'}
                                        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap opacity-0 group-hover:opacity-100">
                                            &nbsp;Related Keywords
                                        </span>
                                    </span>
                                </button>
                            </div>

                            <div className="flex flex-wrap gap-3 items-center">
                                {keyword.relatedInterests.map((interest, idx) => {
                                    const colors = TAG_COLORS[idx % TAG_COLORS.length];
                                    return (
                                        <span
                                            key={interest}
                                            className={`px-3 py-1.5 ${colors.bg} ${colors.text} text-xs font-bold rounded-md border ${colors.border} transition-all hover:brightness-95 cursor-default select-text`}
                                        >
                                            {interest}
                                        </span>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        </div >
    );
};

export default KeywordDetail;
