
import React from 'react';
import type { KeywordData, SortField, SortOrder } from '../types';

interface KeywordTableProps {
    data: KeywordData[];
    sortField: SortField;
    sortOrder: SortOrder;
    onSort: (field: SortField) => void;
    onSelect: (keyword: KeywordData) => void;
    savedKeywords?: Record<string, string>; // Maps ID to pinnedAt date
    pinnedStates?: Record<string, boolean>; // Maps ID to current visual pinned status
    onToggleSave?: (id: string) => void;
    isDarkMode?: boolean;
    showPinnedDate?: boolean;
    searchQuery?: string;
}

const KeywordTable: React.FC<KeywordTableProps> = ({
    data,
    sortField,
    sortOrder,
    onSort,
    onSelect,
    savedKeywords = {},
    pinnedStates = {},
    onToggleSave,
    isDarkMode,
    showPinnedDate = false,
    searchQuery = ''
}) => {
    const formatNumber = (num: number) => {
        return new Intl.NumberFormat().format(num);
    };

    const SortIcon = ({ field }: { field: SortField }) => {
        if (sortField !== field) return <span className="text-red-200 ml-1.5">↕</span>;
        return <span className="text-red-600 ml-1.5 font-black">{sortOrder === 'asc' ? '↑' : '↓'}</span>;
    };

    const getVolumeStyles = (volume: number) => {
        if (volume < 5000) return 'text-green-600 bg-green-50 border-green-100';
        if (volume <= 10000) return 'text-amber-600 bg-amber-50 border-amber-100';
        return 'text-red-600 bg-red-50 border-red-100';
    };

    const renderHighlightedText = (text: string, query: string) => {
        if (!query) return text;

        const parts = text.split(new RegExp(`(${query})`, 'gi'));
        return (
            <span>
                {parts.map((part, i) => (
                    part.toLowerCase() === query.toLowerCase() ? (
                        <span key={i} className="bg-green-100 text-green-800 px-0.5 rounded-sm font-bold">{part}</span>
                    ) : (
                        <span key={i}>{part}</span>
                    )
                ))}
            </span>
        );
    };

    return (
        <div className={`border rounded-[1.5rem] overflow-hidden mt-4 shadow-lg transition-colors duration-300 ${isDarkMode ? 'bg-[#1a1a20] border-white/5' : 'bg-white border-red-50'}`}>
            <table className="w-full text-left border-collapse">
                <thead className={isDarkMode ? 'bg-white/5' : 'bg-red-50/30'}>
                    <tr>
                        <th className="py-3 px-4 w-12">
                            <input type="checkbox" className="w-4 h-4 rounded border-red-200 text-red-600 bg-transparent" />
                        </th>
                        <th
                            className="py-3 px-3 text-[10px] font-black text-red-400 uppercase tracking-widest cursor-pointer hover:opacity-80 transition-all group"
                            onClick={() => onSort('name')}
                        >
                            <div className="flex items-center group-hover:text-red-600">
                                Keyword
                                <SortIcon field="name" />
                            </div>
                        </th>
                        <th
                            className="py-3 px-4 text-[10px] font-black text-red-400 uppercase tracking-widest cursor-pointer hover:opacity-80 transition-all group"
                            onClick={() => onSort('volume')}
                        >
                            <div className="flex items-center group-hover:text-rose-600">
                                Volume
                                <SortIcon field="volume" />
                            </div>
                        </th>
                        {showPinnedDate && (
                            <th className="py-3 px-4 text-[10px] font-black text-red-400 uppercase tracking-widest">
                                Pinned On
                            </th>
                        )}
                        <th className="py-3 px-4 text-[10px] font-black text-red-400 uppercase tracking-widest text-right">
                            Related Keywords
                        </th>
                    </tr>
                </thead>
                <tbody className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-red-50/50'}`}>
                    {data.map((row) => {
                        const isPinned = !!pinnedStates[row.id];
                        const pinnedAt = savedKeywords[row.id];
                        return (
                            <tr key={row.id} className={`transition-all group ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-red-50/30'}`}>
                                <td className="py-3 px-4">
                                    <input type="checkbox" className="w-4 h-4 rounded border-red-200 text-red-600 bg-transparent" />
                                </td>
                                <td className="py-3 px-3">
                                    <div className="flex items-center gap-3">
                                        <button
                                            onClick={(e) => { e.stopPropagation(); onToggleSave?.(row.id); }}
                                            className={`${isPinned ? 'text-red-600 scale-110' : 'text-red-200 group-hover:opacity-100 opacity-0'} hover:text-red-600 transition-all transform active:scale-90`}
                                        >
                                            <svg className="w-5 h-5" fill={isPinned ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                            </svg>
                                        </button>
                                        <span
                                            onClick={() => onSelect(row)}
                                            className={`text-sm font-bold cursor-pointer hover:text-red-600 decoration-red-200 decoration-2 hover:underline underline-offset-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
                                        >
                                            {renderHighlightedText(row.name, searchQuery)}
                                        </span>
                                    </div>
                                </td>
                                <td className="py-3 px-4">
                                    <span className={`text-xs font-black px-2 py-1 rounded-lg border tabular-nums ${getVolumeStyles(row.volume)}`}>
                                        {formatNumber(row.volume)}
                                    </span>
                                </td>
                                {showPinnedDate && (
                                    <td className="py-3 px-4">
                                        <span className={`text-[10px] font-bold ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                            {pinnedAt}
                                        </span>
                                    </td>
                                )}
                                <td className="py-3 px-4 text-right">
                                    <button
                                        onClick={(e) => { e.stopPropagation(); onToggleSave?.(row.id); }}
                                        title={`${row.relatedInterests.length} Related interests found`}
                                        className={`inline-flex items-center justify-center w-8 h-8 rounded-lg transition-all transform active:scale-95 shadow-sm border ${row.relatedInterests.length <= 5
                                            ? (isDarkMode ? 'bg-red-500/20 border-red-500/30' : 'bg-red-100/80 border-red-200')
                                            : (isDarkMode ? 'bg-emerald-500/20 border-emerald-500/30' : 'bg-emerald-100/80 border-emerald-200')
                                            } ${isPinned ? 'ring-2 ring-offset-2 ' + (isDarkMode ? 'ring-red-500 ring-offset-[#1a1a20]' : 'ring-red-600 ring-offset-white') : ''}`}
                                    >
                                        <div className={`w-3.5 h-3.5 rounded-[4px] flex items-center justify-center transition-all ${row.relatedInterests.length <= 5
                                            ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)] animate-pulse'
                                            : 'bg-emerald-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]'
                                            }`}>
                                            {row.relatedInterests.length > 5 && (
                                                <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                                                </svg>
                                            )}
                                        </div>
                                    </button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};

export default KeywordTable;
