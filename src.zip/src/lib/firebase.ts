

import { initializeApp } from 'firebase/app';
import {
    getFirestore,
    collection,
    addDoc,
    serverTimestamp,
    query,
    orderBy,
    limit,
    onSnapshot,
    where,
    deleteDoc,
    doc
} from 'firebase/firestore';


// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCbqy0lN3nmmKQpsAKw-SJBWsdpEeUxeYw",
    authDomain: "pindata.firebaseapp.com",
    projectId: "pindata",
    storageBucket: "pindata.firebasestorage.app",
    messagingSenderId: "472813221931",
    appId: "1:472813221931:web:3ea1cf1c680ca48590526e",
    measurementId: "G-H1WLY9G4ZP"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// Function to log an activity (keeping for general logging)
export const logActivity = async (userName: string, action: string, data: string) => {
    try {
        await addDoc(collection(db, 'activities'), {
            userName,
            action,
            data,
            timestamp: serverTimestamp(),
        });
    } catch (e) {
        console.error("Error adding document: ", e);
    }
};

// Hook for live activities (keeping for reference, but will be removed from UI)
export const subscribeToActivities = (callback: (activities: any[]) => void) => {
    const q = query(collection(db, 'activities'), orderBy('timestamp', 'desc'), limit(50));
    return onSnapshot(q, (snapshot) => {
        const activities = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        callback(activities);
    });
};

// --- SHARED HISTORY FUNCTIONS ---

// Save an item to history shared by a password
export const saveSharedHistory = async (password: string, userName: string, mix: any, date: string) => {
    try {
        await addDoc(collection(db, 'shared_history'), {
            passwordKey: password,
            userName,
            mix,
            date,
            timestamp: serverTimestamp(),
        });
    } catch (e) {
        console.error("Error saving shared history: ", e);
    }
};

// ... (subscribeToSharedHistory remains same but will now see userName in docs)

// --- SHARED SAVED KEYWORDS FUNCTIONS ---

// Save a pinned keyword
export const saveSharedPin = async (password: string, userName: string, keywordId: string, pinnedAt: string) => {
    try {
        // We use a specific ID to avoid duplicates: password_keywordId
        const docId = `${password}_${keywordId}`;
        const { setDoc, doc } = await import('firebase/firestore');
        await setDoc(doc(db, 'shared_pins', docId), {
            passwordKey: password,
            userName,
            keywordId,
            pinnedAt,
            timestamp: serverTimestamp(),
        });
    } catch (e) {
        console.error("Error saving shared pin: ", e);
    }
};

// Delete a pinned keyword
export const deleteSharedPin = async (password: string, keywordId: string) => {
    try {
        const docId = `${password}_${keywordId}`;
        const { deleteDoc, doc } = await import('firebase/firestore');
        await deleteDoc(doc(db, 'shared_pins', docId));
    } catch (e) {
        console.error("Error deleting shared pin: ", e);
    }
};

// Subscribe to pinned keywords
export const subscribeToSharedPins = (password: string, callback: (pins: any[]) => void) => {
    const q = query(
        collection(db, 'shared_pins'),
        where('passwordKey', '==', password)
    );

    return onSnapshot(q, (snapshot) => {
        const pins = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        callback(pins);
    });
};

// Subscribe to history shared by a password
export const subscribeToSharedHistory = (password: string, callback: (history: any[]) => void) => {
    const q = query(
        collection(db, 'shared_history'),
        where('passwordKey', '==', password),
        orderBy('timestamp', 'desc'),
        limit(100)
    );

    return onSnapshot(q, (snapshot) => {
        const history = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        callback(history);
    });
};

// Delete a shared history item
export const deleteSharedHistoryItem = async (itemId: string) => {
    try {
        await deleteDoc(doc(db, 'shared_history', itemId));
    } catch (e) {
        console.error("Error deleting history item: ", e);
    }
};

